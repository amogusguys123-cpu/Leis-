import { Router, type IRouter } from "express";
import healthRouter from "./health.js";
import scriptsRouter from "./scripts.js";
import keysRouter from "./keys.js";
import adminRouter from "./admin.js";
import aiRouter from "./ai.js";
import referralsRouter from "./referrals.js";
import botRouter from "./bot.js";

const router: IRouter = Router();

router.use(adminRouter);
router.use(healthRouter);
router.use(keysRouter);
router.use(scriptsRouter);
router.use(aiRouter);
router.use(referralsRouter);
router.use(botRouter);

export default router;
