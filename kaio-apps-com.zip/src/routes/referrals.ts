import { Router, type IRouter, type Request, type Response } from "express";
import pg from "pg";
import crypto from "crypto";

const { Pool } = pg;
const pool = new Pool({ connectionString: process.env["DATABASE_URL"] });
const router: IRouter = Router();

// ============================================================
//  SCHEMA
// ============================================================
async function ensureReferralSchema() {
  await pool.query(`
    CREATE TABLE IF NOT EXISTS kaio_referral_codes (
      code                 TEXT PRIMARY KEY,
      hwid                 TEXT NOT NULL,
      uses                 INTEGER NOT NULL DEFAULT 0,
      time_earned_minutes  INTEGER NOT NULL DEFAULT 0,
      created_at           TIMESTAMPTZ NOT NULL DEFAULT NOW()
    )
  `);

  await pool.query(`
    CREATE TABLE IF NOT EXISTS kaio_referral_benefits (
      id                   SERIAL PRIMARY KEY,
      name                 TEXT NOT NULL,
      description          TEXT NOT NULL,
      type                 TEXT NOT NULL DEFAULT 'time',
      value_referrer       INTEGER NOT NULL DEFAULT 120,
      value_referred_pct   INTEGER NOT NULL DEFAULT 25,
      active               BOOLEAN NOT NULL DEFAULT TRUE,
      applies_to_tier      INTEGER,
      created_at           TIMESTAMPTZ NOT NULL DEFAULT NOW()
    )
  `);

  await pool.query(`
    CREATE TABLE IF NOT EXISTS kaio_referral_uses (
      id                    SERIAL PRIMARY KEY,
      code                  TEXT NOT NULL,
      referred_hwid         TEXT NOT NULL,
      referred_key          TEXT,
      referrer_time_minutes INTEGER NOT NULL DEFAULT 0,
      referred_time_minutes INTEGER NOT NULL DEFAULT 0,
      benefit_id            INTEGER,
      created_at            TIMESTAMPTZ NOT NULL DEFAULT NOW(),
      UNIQUE(code, referred_hwid)
    )
  `);

  const count = await pool.query(`SELECT COUNT(*) FROM kaio_referral_benefits`);
  if (parseInt(count.rows[0].count, 10) === 0) {
    await pool.query(`
      INSERT INTO kaio_referral_benefits (name, description, type, value_referrer, value_referred_pct, active)
      VALUES ('Bônus de Indicação', '+2h para quem indicou, +30min para o indicado', 'time', 120, 25, TRUE)
    `);
  }
}
ensureReferralSchema().catch(e => console.error("[referrals] schema error:", e?.message ?? e));

// ============================================================
//  HELPERS
// ============================================================
function generateRefCode(): string {
  const chars = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
  let code = "REF";
  for (let i = 0; i < 6; i++) code += chars[Math.floor(Math.random() * chars.length)];
  return code;
}

async function getOrCreateRefCode(hwid: string): Promise<string> {
  const existing = await pool.query(`SELECT code FROM kaio_referral_codes WHERE hwid = $1`, [hwid]);
  if (existing.rows.length > 0) return existing.rows[0].code as string;

  let code = generateRefCode();
  let attempts = 0;
  while (attempts < 10) {
    try {
      await pool.query(`INSERT INTO kaio_referral_codes (code, hwid) VALUES ($1, $2)`, [code, hwid]);
      return code;
    } catch {
      code = generateRefCode();
      attempts++;
    }
  }
  throw new Error("Não foi possível gerar código único");
}

// ============================================================
//  GET /api/referrals/my?hwid=...
//  Retorna (ou cria) o código de referência do usuário
// ============================================================
router.get("/referrals/my", async (req: Request, res: Response) => {
  const hwid = (req.query["hwid"] as string | undefined)?.trim();
  if (!hwid) { res.status(400).json({ error: "hwid obrigatório" }); return; }

  try {
    const code = await getOrCreateRefCode(hwid);
    const row = await pool.query(`SELECT * FROM kaio_referral_codes WHERE code = $1`, [code]);
    const r = row.rows[0];

    res.json({
      code: r.code,
      uses: r.uses,
      timeEarnedMinutes: r.time_earned_minutes,
    });
  } catch (e: any) {
    res.status(500).json({ error: e.message ?? "Erro de servidor" });
  }
});

// ============================================================
//  GET /api/referrals/info?code=...
//  Info pública sobre um código de referência (preview de benefícios)
// ============================================================
router.get("/referrals/info", async (req: Request, res: Response) => {
  const code = (req.query["code"] as string | undefined)?.trim().toUpperCase();
  if (!code) { res.status(400).json({ error: "code obrigatório" }); return; }

  try {
    const codeRow = await pool.query(`SELECT * FROM kaio_referral_codes WHERE code = $1`, [code]);
    if (codeRow.rows.length === 0) {
      res.status(404).json({ valid: false, error: "Código de indicação não encontrado" });
      return;
    }

    const benefits = await pool.query(
      `SELECT * FROM kaio_referral_benefits WHERE active = TRUE ORDER BY id`
    );

    res.json({
      valid: true,
      code,
      benefits: benefits.rows.map(b => ({
        id: b.id,
        name: b.name,
        description: b.description,
        type: b.type,
        valueReferrer: b.value_referrer,
        valueReferredPct: b.value_referred_pct,
        appliesToTier: b.applies_to_tier,
      })),
    });
  } catch {
    res.status(500).json({ error: "Erro de servidor" });
  }
});

// ============================================================
//  POST /api/referrals/apply
//  Aplica código de indicação após a key ser gerada
//  Body: { code, referredHwid, referredKey }
// ============================================================
router.post("/referrals/apply", async (req: Request, res: Response) => {
  const code         = (req.body?.code as string | undefined)?.trim().toUpperCase();
  const referredHwid = (req.body?.referredHwid as string | undefined)?.trim();
  const referredKey  = (req.body?.referredKey  as string | undefined)?.trim();

  if (!code || !referredHwid || !referredKey) {
    res.status(400).json({ error: "code, referredHwid e referredKey são obrigatórios" });
    return;
  }

  try {
    const codeRow = await pool.query(`SELECT * FROM kaio_referral_codes WHERE code = $1`, [code]);
    if (codeRow.rows.length === 0) {
      res.status(404).json({ error: "Código de indicação inválido" });
      return;
    }
    const refCode = codeRow.rows[0];

    if (refCode.hwid === referredHwid) {
      res.status(400).json({ error: "Você não pode usar seu próprio código de indicação" });
      return;
    }

    const alreadyUsed = await pool.query(
      `SELECT id FROM kaio_referral_uses WHERE code = $1 AND referred_hwid = $2`,
      [code, referredHwid]
    );
    if (alreadyUsed.rows.length > 0) {
      res.status(409).json({ error: "Você já usou este código de indicação anteriormente" });
      return;
    }

    const keyRow = await pool.query(
      `SELECT * FROM kaio_keys WHERE key = $1 AND (is_permanent = TRUE OR expires_at > NOW())`,
      [referredKey]
    );
    if (keyRow.rows.length === 0) {
      res.status(404).json({ error: "Key não encontrada ou expirada" });
      return;
    }
    const keyTier = keyRow.rows[0].tier as number;

    const benefits = await pool.query(
      `SELECT * FROM kaio_referral_benefits
        WHERE active = TRUE
          AND (applies_to_tier IS NULL OR applies_to_tier = $1)
        ORDER BY id LIMIT 1`,
      [keyTier]
    );

    let referrerMinutes = 0;
    let referredMinutes = 0;
    let benefitId: number | null = null;
    let benefitDesc = "";

    if (benefits.rows.length > 0) {
      const b = benefits.rows[0];
      referrerMinutes = b.value_referrer as number;
      referredMinutes = Math.floor(referrerMinutes * (b.value_referred_pct as number) / 100);
      benefitId = b.id as number;
      benefitDesc = b.description as string;
    }

    await pool.query(
      `INSERT INTO kaio_referral_uses
         (code, referred_hwid, referred_key, referrer_time_minutes, referred_time_minutes, benefit_id)
       VALUES ($1, $2, $3, $4, $5, $6)`,
      [code, referredHwid, referredKey, referrerMinutes, referredMinutes, benefitId]
    );

    if (referredMinutes > 0) {
      await pool.query(
        `UPDATE kaio_keys
            SET expires_at = expires_at + ($1 || ' minutes')::INTERVAL
          WHERE key = $2 AND is_permanent = FALSE`,
        [referredMinutes, referredKey]
      );
    }

    if (referrerMinutes > 0) {
      const referrerKey = await pool.query(
        `SELECT key FROM kaio_keys
          WHERE hwid = $1
            AND (is_permanent = TRUE OR expires_at > NOW())
          ORDER BY tier DESC, created_at DESC LIMIT 1`,
        [refCode.hwid]
      );
      if (referrerKey.rows.length > 0) {
        await pool.query(
          `UPDATE kaio_keys
              SET expires_at = expires_at + ($1 || ' minutes')::INTERVAL
            WHERE key = $2 AND is_permanent = FALSE`,
          [referrerMinutes, referrerKey.rows[0].key]
        );
      }
    }

    await pool.query(
      `UPDATE kaio_referral_codes
          SET uses = uses + 1,
              time_earned_minutes = time_earned_minutes + $1
        WHERE code = $2`,
      [referrerMinutes, code]
    );

    res.json({
      success: true,
      referrerMinutesAdded: referrerMinutes,
      referredMinutesAdded: referredMinutes,
      benefitDescription: benefitDesc,
    });
  } catch (e: any) {
    if (e?.code === "23505") {
      res.status(409).json({ error: "Código já utilizado por este usuário" });
    } else {
      console.error("[referrals] apply error:", e);
      res.status(500).json({ error: "Erro de servidor" });
    }
  }
});

// ============================================================
//  ADMIN — GET /api/admin/referrals/benefits
// ============================================================
router.get("/admin/referrals/benefits", async (req: Request, res: Response) => {
  const token = req.headers["x-admin-token"] as string | undefined;
  if (!token) { res.status(401).json({ error: "Não autorizado" }); return; }

  try {
    const r = await pool.query(`SELECT * FROM kaio_referral_benefits ORDER BY id`);
    res.json({ benefits: r.rows });
  } catch {
    res.status(500).json({ error: "Erro de servidor" });
  }
});

// ============================================================
//  ADMIN — POST /api/admin/referrals/benefits
// ============================================================
router.post("/admin/referrals/benefits", async (req: Request, res: Response) => {
  const token = req.headers["x-admin-token"] as string | undefined;
  if (!token) { res.status(401).json({ error: "Não autorizado" }); return; }

  const { name, description, type, value_referrer, value_referred_pct, applies_to_tier } = req.body as {
    name?: string; description?: string; type?: string;
    value_referrer?: number; value_referred_pct?: number; applies_to_tier?: number | null;
  };

  if (!name?.trim() || !description?.trim()) {
    res.status(400).json({ error: "Nome e descrição são obrigatórios" });
    return;
  }

  try {
    const r = await pool.query(
      `INSERT INTO kaio_referral_benefits
         (name, description, type, value_referrer, value_referred_pct, applies_to_tier)
       VALUES ($1, $2, $3, $4, $5, $6)
       RETURNING *`,
      [
        name.trim(), description.trim(), type ?? "time",
        value_referrer ?? 120, value_referred_pct ?? 25,
        applies_to_tier ?? null,
      ]
    );
    res.status(201).json({ benefit: r.rows[0] });
  } catch {
    res.status(500).json({ error: "Erro de servidor" });
  }
});

// ============================================================
//  ADMIN — PATCH /api/admin/referrals/benefits/:id/toggle
// ============================================================
router.patch("/admin/referrals/benefits/:id/toggle", async (req: Request, res: Response) => {
  const token = req.headers["x-admin-token"] as string | undefined;
  if (!token) { res.status(401).json({ error: "Não autorizado" }); return; }

  const { id } = req.params;
  try {
    await pool.query(`UPDATE kaio_referral_benefits SET active = NOT active WHERE id = $1`, [id]);
    res.json({ ok: true });
  } catch {
    res.status(500).json({ error: "Erro de servidor" });
  }
});

// ============================================================
//  ADMIN — DELETE /api/admin/referrals/benefits/:id
// ============================================================
router.delete("/admin/referrals/benefits/:id", async (req: Request, res: Response) => {
  const token = req.headers["x-admin-token"] as string | undefined;
  if (!token) { res.status(401).json({ error: "Não autorizado" }); return; }

  const { id } = req.params;
  try {
    await pool.query(`DELETE FROM kaio_referral_benefits WHERE id = $1`, [id]);
    res.json({ ok: true });
  } catch {
    res.status(500).json({ error: "Erro de servidor" });
  }
});

// ============================================================
//  ADMIN — GET /api/admin/referrals/stats
// ============================================================
router.get("/admin/referrals/stats", async (req: Request, res: Response) => {
  const token = req.headers["x-admin-token"] as string | undefined;
  if (!token) { res.status(401).json({ error: "Não autorizado" }); return; }

  try {
    const [codes, uses, topReferrers] = await Promise.all([
      pool.query(`SELECT COUNT(*) FROM kaio_referral_codes`),
      pool.query(`SELECT COUNT(*) FROM kaio_referral_uses`),
      pool.query(`
        SELECT rc.code, rc.hwid, rc.uses, rc.time_earned_minutes
          FROM kaio_referral_codes rc
         ORDER BY rc.uses DESC
         LIMIT 10
      `),
    ]);
    res.json({
      totalCodes: parseInt(codes.rows[0].count, 10),
      totalUses: parseInt(uses.rows[0].count, 10),
      topReferrers: topReferrers.rows,
    });
  } catch {
    res.status(500).json({ error: "Erro de servidor" });
  }
});

export default router;
