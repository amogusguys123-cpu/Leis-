import { Router, type IRouter, type Request, type Response } from "express";
import { readFileSync } from "fs";
import { join, dirname } from "path";
import { fileURLToPath } from "url";

const __dirname = dirname(fileURLToPath(import.meta.url));
const scriptsDir = join(__dirname, "../scripts");
const pagesDir = join(__dirname, "../pages");

const router: IRouter = Router();

const XOR_KEY = [0x4b, 0x41, 0x49, 0x4f, 0x41, 0x50, 0x50, 0x53];

function obfuscate(source: string): string {
  const bytes = Buffer.from(source, "utf-8");
  const encoded: number[] = [];
  for (let i = 0; i < bytes.length; i++) {
    encoded.push(bytes[i]! ^ XOR_KEY[i % XOR_KEY.length]!);
  }

  const chunks: string[] = [];
  for (let i = 0; i < encoded.length; i += 60) {
    chunks.push(encoded.slice(i, i + 60).join(","));
  }
  const tableBody = chunks.join(",\n    ");

  return `-- KAIO APPS | Protected Module
local _K={${XOR_KEY.join(",")}}
local _D={
    ${tableBody}
}
local _S=""
for _i=1,#_D do
  _S=_S..string.char(bit32.bxor(_D[_i],_K[((_i-1)%#_K)+1]))
end
loadstring(_S)()
`;
}

function getServerUrl(req: Request): string {
  // Prioridade 1: URL explícita (Shardcloud, VPS, etc.)
  const explicit = process.env["SERVER_SITE_URL"];
  if (explicit) return explicit.replace(/\/$/, "") + "/api";

  // Prioridade 2: Replit automático
  const domains = process.env["REPLIT_DOMAINS"];
  if (domains) {
    const primaryDomain = domains.split(",")[0]!.trim();
    return `https://${primaryDomain}/api`;
  }

  // Prioridade 3: host da requisição (fallback genérico)
  const host = req.get("host") ?? "localhost:80";
  const protocol = req.secure || req.get("x-forwarded-proto") === "https" ? "https" : "http";
  return `${protocol}://${host}/api`;
}

// URL da página GetKey — pode ser externa (shardcloud, netlify, etc.)
function getGetkeyUrl(req: Request): string {
  const external = process.env["GETKEY_SITE_URL"];
  if (external) return external.replace(/\/$/, "");
  return getServerUrl(req) + "/getkey";
}

const PROTECTED = new Set(["flee-facility.lua", "loader.lua"]);

// Landing page acessível via /api/ (para o preview do Replit)
router.get("/", (_req: Request, res: Response) => {
  try {
    const content = readFileSync(join(pagesDir, "home.html"), "utf-8");
    res.setHeader("Content-Type", "text/html; charset=utf-8");
    res.setHeader("Cache-Control", "no-cache");
    res.send(content);
  } catch {
    res.redirect("/api/getkey");
  }
});

router.get("/admin", (_req: Request, res: Response) => {
  try {
    const filePath = join(pagesDir, "admin.html");
    const content = readFileSync(filePath, "utf-8");
    res.setHeader("Content-Type", "text/html; charset=utf-8");
    res.setHeader("Cache-Control", "no-cache");
    res.send(content);
  } catch {
    res.status(404).send("Page not found");
  }
});

router.get("/getkey", (_req: Request, res: Response) => {
  try {
    const filePath = join(pagesDir, "getkey.html");
    const content = readFileSync(filePath, "utf-8");
    res.setHeader("Content-Type", "text/html; charset=utf-8");
    res.setHeader("Cache-Control", "no-cache");
    res.send(content);
  } catch {
    res.status(404).send("Page not found");
  }
});

router.get("/key-flow", (_req: Request, res: Response) => {
  try {
    const filePath = join(pagesDir, "key-flow.html");
    const content = readFileSync(filePath, "utf-8");
    res.setHeader("Content-Type", "text/html; charset=utf-8");
    res.setHeader("Cache-Control", "no-cache");
    res.send(content);
  } catch {
    res.status(404).send("Page not found");
  }
});

router.get("/dashboard", (_req: Request, res: Response) => {
  try {
    const filePath = join(pagesDir, "dashboard.html");
    const content = readFileSync(filePath, "utf-8");
    res.setHeader("Content-Type", "text/html; charset=utf-8");
    res.setHeader("Cache-Control", "no-cache");
    res.send(content);
  } catch {
    res.status(404).send("Page not found");
  }
});

router.get("/scripts/:filename", (req: Request, res: Response) => {
  const { filename } = req.params;

  if (!filename || !/^[\w\- ]+\.lua$/.test(filename)) {
    res.status(400).send("-- Invalid script name");
    return;
  }

  try {
    const filePath = join(scriptsDir, filename);
    let content = readFileSync(filePath, "utf-8");

    const serverUrl = getServerUrl(req);
    content = content.replace(/__SERVER_URL__/g, serverUrl);
    content = content.replace(/__GETKEY_URL__/g, getGetkeyUrl(req));
    content = content.replace(/__KAIO_KEY__/g, process.env["KAIO_KEY"] ?? "KAIO2108");

    res.setHeader("Content-Type", "text/plain; charset=utf-8");
    res.setHeader("Cache-Control", "no-cache");

    if (PROTECTED.has(filename)) {
      res.send(obfuscate(content));
    } else {
      res.send(content);
    }
  } catch {
    res.status(404).send(`-- Script not found: ${filename}`);
  }
});

export default router;
