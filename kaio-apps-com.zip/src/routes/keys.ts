import { Router, type IRouter, type Request, type Response } from "express";
import pg from "pg";
import crypto from "crypto";
import { getWorkCheckpoints, getTierDurationHours } from "./admin.js";

const { Pool } = pg;
const pool = new Pool({ connectionString: process.env["DATABASE_URL"] });
const router: IRouter = Router();

// ============================================================
//  SETUP — cria/atualiza tabelas necessárias
// ============================================================
async function ensureSchema() {
  await pool.query(`
    CREATE TABLE IF NOT EXISTS kaio_keys (
      id SERIAL PRIMARY KEY,
      key TEXT UNIQUE NOT NULL,
      tier INTEGER NOT NULL DEFAULT 1,
      tier_name TEXT NOT NULL DEFAULT 'Bronze',
      level TEXT NOT NULL DEFAULT 'standard',
      is_permanent BOOLEAN NOT NULL DEFAULT FALSE,
      expires_at TIMESTAMPTZ,
      hwid TEXT,
      failed_attempts INTEGER NOT NULL DEFAULT 0,
      last_failed_at TIMESTAMPTZ,
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    )
  `);

  await pool.query(`
    ALTER TABLE kaio_keys
      ADD COLUMN IF NOT EXISTS level TEXT NOT NULL DEFAULT 'standard',
      ADD COLUMN IF NOT EXISTS is_permanent BOOLEAN NOT NULL DEFAULT FALSE
  `).catch(() => {});

  await pool.query(`
    CREATE TABLE IF NOT EXISTS kaio_sessions (
      id TEXT PRIMARY KEY,
      hwid TEXT NOT NULL,
      tier INTEGER NOT NULL DEFAULT 1,
      type TEXT NOT NULL DEFAULT 'getkey',
      step INTEGER NOT NULL DEFAULT 0,
      key TEXT,
      extend_key TEXT,
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
      expires_at TIMESTAMPTZ NOT NULL DEFAULT (NOW() + INTERVAL '2 hours')
    )
  `);
}
ensureSchema().catch((err) => {
  console.error("[kaio] ensureSchema failed (server stays up):", err?.message ?? err);
});

// ============================================================
//  HELPERS
// ============================================================
const TIER_NAMES: Record<number, string> = {
  1: "Bronze", 2: "Prata", 3: "Ouro", 4: "Custom",
};

function generateKey(): string {
  const chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
  let rand = "";
  for (let i = 0; i < 5; i++) {
    rand += chars[Math.floor(Math.random() * chars.length)];
  }
  const now = new Date();
  const dd = String(now.getDate()).padStart(2, "0");
  const mm = String(now.getMonth() + 1).padStart(2, "0");
  const yy = String(now.getFullYear()).slice(2);
  return `KAIO_${rand}${dd}${mm}${yy}`;
}

function sessionId(): string {
  return crypto.randomBytes(16).toString("hex");
}

// ============================================================
//  SESSION — POST /api/keys/session
//  Body: { hwid, tier }
// ============================================================
router.post("/keys/session", async (req: Request, res: Response) => {
  const hwid = (req.body?.hwid as string | undefined)?.trim();
  const tierNum = parseInt((req.body?.tier ?? "1") as string, 10);
  const tier = TIER_NAMES[tierNum] ? tierNum : 1;

  if (!hwid) {
    res.status(400).json({ error: "HWID não informado" });
    return;
  }

  const id = sessionId();
  try {
    await pool.query(
      `INSERT INTO kaio_sessions (id, hwid, tier, type, step)
       VALUES ($1, $2, $3, 'getkey', 0)`,
      [id, hwid, tier]
    );
    const checkpoints = await getWorkCheckpoints();
    res.json({ sessionId: id, checkpoints });
  } catch {
    res.status(500).json({ error: "Erro ao criar sessão" });
  }
});

// ============================================================
//  SESSION STATUS — GET /api/keys/session/:id
// ============================================================
router.get("/keys/session/:id", async (req: Request, res: Response) => {
  const { id } = req.params;
  try {
    const r = await pool.query(
      `SELECT * FROM kaio_sessions WHERE id = $1 AND expires_at > NOW()`,
      [id]
    );
    if (r.rows.length === 0) {
      res.status(404).json({ error: "Sessão não encontrada ou expirada" });
      return;
    }
    const s = r.rows[0];

    let keyInfo = null;
    if (s.key) {
      const kr = await pool.query(`SELECT * FROM kaio_keys WHERE key = $1`, [s.key]);
      if (kr.rows.length > 0) {
        const k = kr.rows[0];
        keyInfo = {
          key: k.key,
          tier: k.tier,
          tierName: k.tier_name,
          expiresAt: k.expires_at,
          isPermanent: k.is_permanent,
        };
      }
    }

    const checkpoints = await getWorkCheckpoints();
    res.json({
      sessionId: id,
      hwid: s.hwid,
      tier: s.tier,
      type: s.type,
      step: s.step,
      checkpoints,
      keyInfo,
    });
  } catch {
    res.status(500).json({ error: "Erro ao buscar sessão" });
  }
});

// ============================================================
//  HELPERS — server URL
// ============================================================
function getServerUrl(req: Request): string {
  const explicit = process.env["SERVER_SITE_URL"];
  if (explicit) return explicit.replace(/\/$/, "") + "/api";
  const domains = process.env["REPLIT_DOMAINS"];
  if (domains) {
    const primaryDomain = domains.split(",")[0]!.trim();
    return `https://${primaryDomain}/api`;
  }
  const host = req.get("host") ?? "localhost:80";
  const protocol = req.secure || req.get("x-forwarded-proto") === "https" ? "https" : "http";
  return `${protocol}://${host}/api`;
}

// ============================================================
//  WORK.INK — Override API
// ============================================================
async function buildWorkInkUrl(baseLink: string, destination: string): Promise<string> {
  const overrideUrl = `https://work.ink/_api/v2/override?destination=${encodeURIComponent(destination)}`;
  const resp = await fetch(overrideUrl);
  const rawText = await resp.text();
  console.log("[work.ink override] status:", resp.status, "body:", rawText);

  let data: { sr?: string } = {};
  try { data = JSON.parse(rawText); } catch { }

  if (!data.sr) throw new Error(`Override API falhou (${resp.status}): ${rawText.slice(0, 200)}`);

  const sep = baseLink.includes("?") ? "&" : "?";
  return `${baseLink}${sep}sr=${encodeURIComponent(data.sr)}`;
}

// ============================================================
//  WI REDIRECT — GET /api/wi-redirect
//  Params: ?session=ID&step=N
// ============================================================
router.get("/wi-redirect", async (req: Request, res: Response) => {
  const sid = (req.query["session"] as string | undefined)?.trim();
  const step = (req.query["step"] as string | undefined)?.trim();

  if (!sid || !step) {
    res.status(400).send("Parâmetros inválidos");
    return;
  }

  const stepNum = parseInt(step, 10);
  const linkKey = `WI_LINK_STEP${stepNum}`;
  let baseLink = process.env[linkKey];

  if (!baseLink) {
    baseLink = process.env["WI_LINK_STEP1"] ?? undefined;
  }

  if (!baseLink) {
    res.status(500).send(`Links do work.ink não configurados. Defina WI_LINK_STEP1 (e WI_LINK_STEP2...${stepNum} para múltiplos checkpoints).`);
    return;
  }

  try {
    const serverUrl = getServerUrl(req);
    const callbackUrl = `${serverUrl}/wi-callback?session=${encodeURIComponent(sid)}&step=${encodeURIComponent(step)}&hash={TOKEN}`;
    const finalUrl = await buildWorkInkUrl(baseLink, callbackUrl);
    res.redirect(finalUrl);
  } catch (err) {
    const msg = err instanceof Error ? err.message : "Erro desconhecido";
    res.status(500).send(`Erro ao criar link work.ink: ${msg}`);
  }
});

// ============================================================
//  WORK.INK TOKEN VERIFY
// ============================================================
async function verifyWorkInk(token: string): Promise<boolean> {
  if (!token || token.length < 8) return false;
  try {
    const url = `https://work.ink/_api/v2/token/isValid/${encodeURIComponent(token)}?deleteToken=1`;
    const resp = await fetch(url);
    const data = await resp.json() as { valid?: boolean };
    return data.valid === true;
  } catch {
    return false;
  }
}

// ============================================================
//  WI CALLBACK — GET /api/wi-callback
// ============================================================
router.get("/wi-callback", async (req: Request, res: Response) => {
  const sid = (req.query["session"] as string | undefined)?.trim();
  const stepStr = (req.query["step"] as string | undefined)?.trim();
  const token = (req.query["hash"] as string | undefined)?.trim();

  if (!sid || !stepStr) {
    res.redirect("/api/key-flow?error=session");
    return;
  }

  const step = parseInt(stepStr, 10);

  if (!token || token.length < 8) {
    res.redirect(`/api/key-flow?session=${sid}&error=bypass`);
    return;
  }

  const verified = await verifyWorkInk(token);
  if (!verified) {
    res.redirect(`/api/key-flow?session=${sid}&error=bypass`);
    return;
  }

  try {
    const r = await pool.query(
      `SELECT * FROM kaio_sessions WHERE id = $1 AND expires_at > NOW()`,
      [sid]
    );

    if (r.rows.length === 0) {
      res.redirect("/api/getkey?error=expired");
      return;
    }

    const session = r.rows[0];
    const totalCheckpoints = await getWorkCheckpoints();

    if (session.type === "getkey") {
      const currentStep = session.step as number;

      if (step === currentStep + 1 && step < totalCheckpoints) {
        await pool.query(`UPDATE kaio_sessions SET step = $1 WHERE id = $2`, [step, sid]);
      } else if (step === currentStep + 1 && step >= totalCheckpoints) {
        const tierNum = session.tier as number;
        const tierName = TIER_NAMES[tierNum] ?? "Bronze";

        // Check if HWID already has an active key for this tier
        let key: string;
        const existing = await pool.query(
          `SELECT key FROM kaio_keys WHERE hwid = $1 AND tier = $2
           AND (is_permanent = TRUE OR expires_at > NOW()) LIMIT 1`,
          [session.hwid, tierNum]
        );
        if (existing.rows.length > 0) {
          key = existing.rows[0].key as string;
        } else {
          key = generateKey();
          const durationHours = await getTierDurationHours(tierNum);
          // Discord bonus: se o HWID já tem discord_id vinculado, +2h extra
          const discordLinked = await pool.query(
            `SELECT discord_id FROM kaio_keys WHERE hwid = $1 AND discord_id IS NOT NULL LIMIT 1`,
            [session.hwid]
          );
          const bonusHours = discordLinked.rows.length > 0
            ? parseFloat(await getSetting("discord_bonus_hours", "2"))
            : 0;
          const expiresAt = new Date(Date.now() + (durationHours + bonusHours) * 3600 * 1000);
          await pool.query(
            `INSERT INTO kaio_keys (key, tier, tier_name, level, is_permanent, expires_at, hwid)
             VALUES ($1, $2, $3, 'standard', FALSE, $4, $5)
             ON CONFLICT (key) DO NOTHING`,
            [key, tierNum, tierName, expiresAt, session.hwid]
          );
        }
        await pool.query(
          `UPDATE kaio_sessions SET step = $1, key = $2 WHERE id = $3`,
          [step, key, sid]
        );
      }
    } else if (session.type === "extend") {
      if (step === 1 && session.step === 0) {
        const extKey = session.extend_key as string;
        await pool.query(
          `UPDATE kaio_keys SET expires_at = expires_at + INTERVAL '3 hours' WHERE key = $1 AND is_permanent = FALSE`,
          [extKey]
        );
        await pool.query(`UPDATE kaio_sessions SET step = 1 WHERE id = $1`, [sid]);
      }
    }

    const hwid = (session.hwid as string | null) ?? "";
    const hwidParam = hwid ? `&hwid=${encodeURIComponent(hwid)}` : "";
    res.redirect(`/api/key-flow?session=${sid}${hwidParam}`);
  } catch {
    res.redirect("/api/key-flow?error=server");
  }
});

// ============================================================
//  LV ADVANCE — POST /api/keys/lv-advance
//  Body: { session, step }
// ============================================================
router.post("/keys/lv-advance", async (req: Request, res: Response) => {
  const sid = (req.body?.session as string | undefined)?.trim();
  const stepNum = parseInt((req.body?.step ?? "0") as string, 10);

  if (!sid || !stepNum) {
    res.status(400).json({ ok: false, error: "Parâmetros inválidos" });
    return;
  }

  try {
    const r = await pool.query(
      `SELECT * FROM kaio_sessions WHERE id = $1 AND expires_at > NOW()`,
      [sid]
    );

    if (r.rows.length === 0) {
      res.status(404).json({ ok: false, error: "Sessão não encontrada ou expirada" });
      return;
    }

    const session = r.rows[0];
    const totalCheckpoints = await getWorkCheckpoints();

    if (session.type === "getkey") {
      const currentStep = session.step as number;

      if (stepNum === currentStep + 1 && stepNum < totalCheckpoints) {
        await pool.query(`UPDATE kaio_sessions SET step = $1 WHERE id = $2`, [stepNum, sid]);
        res.json({ ok: true });
      } else if (stepNum === currentStep + 1 && stepNum >= totalCheckpoints) {
        const tierNum = session.tier as number;
        const tierName = TIER_NAMES[tierNum] ?? "Bronze";

        // Check if HWID already has an active key for this tier
        let key: string;
        const existing = await pool.query(
          `SELECT key FROM kaio_keys WHERE hwid = $1 AND tier = $2
           AND (is_permanent = TRUE OR expires_at > NOW()) LIMIT 1`,
          [session.hwid, tierNum]
        );
        if (existing.rows.length > 0) {
          key = existing.rows[0].key as string;
        } else {
          key = generateKey();
          const durationHours = await getTierDurationHours(tierNum);
          // Discord bonus: se o HWID já tem discord_id vinculado, +2h extra
          const discordLinked = await pool.query(
            `SELECT discord_id FROM kaio_keys WHERE hwid = $1 AND discord_id IS NOT NULL LIMIT 1`,
            [session.hwid]
          );
          const bonusHours = discordLinked.rows.length > 0
            ? parseFloat(await getSetting("discord_bonus_hours", "2"))
            : 0;
          const expiresAt = new Date(Date.now() + (durationHours + bonusHours) * 3600 * 1000);
          await pool.query(
            `INSERT INTO kaio_keys (key, tier, tier_name, level, is_permanent, expires_at, hwid)
             VALUES ($1, $2, $3, 'standard', FALSE, $4, $5)
             ON CONFLICT (key) DO NOTHING`,
            [key, tierNum, tierName, expiresAt, session.hwid]
          );
        }
        await pool.query(
          `UPDATE kaio_sessions SET step = $1, key = $2 WHERE id = $3`,
          [stepNum, key, sid]
        );
        res.json({ ok: true });
      } else {
        res.json({ ok: false, error: "Passo já concluído ou inválido" });
      }
    } else if (session.type === "extend") {
      if (stepNum === 1 && session.step === 0) {
        const extKey = session.extend_key as string;
        await pool.query(
          `UPDATE kaio_keys SET expires_at = expires_at + INTERVAL '3 hours' WHERE key = $1 AND is_permanent = FALSE`,
          [extKey]
        );
        await pool.query(`UPDATE kaio_sessions SET step = 1 WHERE id = $1`, [sid]);
        res.json({ ok: true });
      } else {
        res.json({ ok: false, error: "Passo já concluído ou inválido" });
      }
    } else {
      res.json({ ok: false, error: "Tipo de sessão inválido" });
    }
  } catch {
    res.status(500).json({ ok: false, error: "Erro de servidor" });
  }
});

// ============================================================
//  EXTEND SESSION — POST /api/keys/extend
//  Body: { key, hwid }
// ============================================================
router.post("/keys/extend", async (req: Request, res: Response) => {
  const key = (req.body?.key as string | undefined)?.trim();
  const hwid = (req.body?.hwid as string | undefined)?.trim();

  if (!key || !hwid) {
    res.status(400).json({ error: "Key e HWID são obrigatórios" });
    return;
  }

  try {
    const kr = await pool.query(
      `SELECT * FROM kaio_keys WHERE key = $1 AND (expires_at > NOW() OR is_permanent = TRUE)`,
      [key]
    );
    if (kr.rows.length === 0) {
      res.status(404).json({ error: "Key não encontrada ou expirada" });
      return;
    }
    const k = kr.rows[0];
    if (k.hwid && k.hwid !== hwid) {
      res.status(403).json({ error: "HWID não corresponde a esta key" });
      return;
    }
    if (k.is_permanent) {
      res.status(400).json({ error: "Key permanente não pode ser estendida" });
      return;
    }

    const id = sessionId();
    await pool.query(
      `INSERT INTO kaio_sessions (id, hwid, tier, type, step, extend_key)
       VALUES ($1, $2, $3, 'extend', 0, $4)`,
      [id, hwid, k.tier, key]
    );
    res.json({ sessionId: id });
  } catch {
    res.status(500).json({ error: "Erro ao iniciar extensão" });
  }
});

// ============================================================
//  VALIDATE — GET /api/keys/validate
// ============================================================
router.get("/keys/validate", async (req: Request, res: Response) => {
  const key  = (req.query["key"]  as string | undefined)?.trim();
  const hwid = (req.query["hwid"] as string | undefined)?.trim();

  if (!key) {
    res.status(400).json({ valid: false, message: "Key não informada" });
    return;
  }

  try {
    const result = await pool.query(
      `SELECT * FROM kaio_keys WHERE key = $1`,
      [key]
    );

    if (result.rows.length === 0) {
      res.json({ valid: false, message: "Key inválida" });
      return;
    }

    const row = result.rows[0];

    if (!row.is_permanent && row.expires_at && new Date(row.expires_at) <= new Date()) {
      res.json({ valid: false, message: "Key expirada" });
      return;
    }

    const MAX_FAILS = 10;
    const BLOCK_MS = 30 * 60 * 1000;
    if (
      row.failed_attempts >= MAX_FAILS &&
      row.last_failed_at &&
      Date.now() - new Date(row.last_failed_at).getTime() < BLOCK_MS
    ) {
      res.status(429).json({ valid: false, message: "Muitas tentativas. Tente em 30 minutos." });
      return;
    }

    if (hwid) {
      if (!row.hwid) {
        await pool.query(
          `UPDATE kaio_keys SET hwid = $1, failed_attempts = 0, last_failed_at = NULL WHERE id = $2`,
          [hwid, row.id]
        );
      } else if (row.hwid !== hwid) {
        await pool.query(
          `UPDATE kaio_keys SET failed_attempts = failed_attempts + 1, last_failed_at = NOW() WHERE id = $1`,
          [row.id]
        );
        res.status(403).json({ valid: false, message: "Key vinculada a outro dispositivo (HWID Lock)." });
        return;
      }
    }

    if (row.failed_attempts > 0) {
      await pool.query(
        `UPDATE kaio_keys SET failed_attempts = 0, last_failed_at = NULL WHERE id = $1`,
        [row.id]
      );
    }

    res.json({
      valid: true,
      tier: row.tier,
      name: row.tier_name,
      level: row.level,
      isPermanent: row.is_permanent,
      expireDate: row.is_permanent ? "Permanente" : new Date(row.expires_at).toLocaleDateString("pt-BR"),
      hwidLocked: !!row.hwid,
      isAdmin: row.level === "admin",
    });
  } catch {
    res.status(500).json({ valid: false, message: "Erro de servidor" });
  }
});

// ============================================================
//  KEY INFO — GET /api/keys/info?key=...
// ============================================================
router.get("/keys/info", async (req: Request, res: Response) => {
  const key = (req.query["key"] as string | undefined)?.trim();
  if (!key) {
    res.status(400).json({ error: "Key não informada" });
    return;
  }
  try {
    const r = await pool.query(`SELECT * FROM kaio_keys WHERE key = $1`, [key]);
    if (r.rows.length === 0) {
      res.status(404).json({ error: "Key não encontrada" });
      return;
    }
    const k = r.rows[0];
    res.json({
      key: k.key,
      tier: k.tier,
      tierName: k.tier_name,
      level: k.level,
      isPermanent: k.is_permanent,
      expiresAt: k.expires_at,
      hwid: k.hwid ? k.hwid.slice(0, 8) + "..." : null,
    });
  } catch {
    res.status(500).json({ error: "Erro de servidor" });
  }
});

// ============================================================
//  REDIRECT /api/keys → /api/getkey
// ============================================================
router.get("/keys", (_req: Request, res: Response) => {
  res.redirect("/api/getkey");
});

// ============================================================
//  GET /api/stats — estatísticas públicas do sistema
// ============================================================
router.get("/stats", async (_req: Request, res: Response) => {
  try {
    const [keysRow, activeRow, sessionsRow] = await Promise.all([
      pool.query(`SELECT COUNT(*) AS total FROM kaio_keys`),
      pool.query(`
        SELECT COUNT(DISTINCT hwid) AS dau FROM kaio_keys
        WHERE hwid IS NOT NULL
          AND (is_permanent = TRUE OR expires_at > NOW())
      `),
      pool.query(`SELECT COUNT(*) AS total FROM kaio_sessions WHERE created_at > NOW() - INTERVAL '24 hours'`)
    ]);
    res.json({
      totalKeys:   parseInt(keysRow.rows[0].total, 10),
      activeUsers: parseInt(activeRow.rows[0].dau,  10),
      sessions24h: parseInt(sessionsRow.rows[0].total, 10),
    });
  } catch {
    res.status(500).json({ error: "Erro de servidor" });
  }
});

// ============================================================
//  GET /api/keys/my-key?hwid=... — busca key ativa por HWID
// ============================================================
router.get("/keys/my-key", async (req: Request, res: Response) => {
  const hwid = (req.query["hwid"] as string | undefined)?.trim();
  if (!hwid) { res.status(400).json({ error: "hwid obrigatório" }); return; }
  try {
    const r = await pool.query(
      `SELECT key, tier, tier_name, level, is_permanent, expires_at, created_at
         FROM kaio_keys
        WHERE hwid = $1
          AND (is_permanent = TRUE OR expires_at > NOW())
        ORDER BY tier DESC, created_at DESC
        LIMIT 1`,
      [hwid]
    );
    if (r.rows.length === 0) { res.status(404).json({ exists: false }); return; }
    const k = r.rows[0];
    res.json({
      exists:      true,
      key:         k.key,
      tier:        k.tier,
      tierName:    k.tier_name,
      level:       k.level,
      isPermanent: k.is_permanent,
      expiresAt:   k.expires_at,
      createdAt:   k.created_at,
    });
  } catch {
    res.status(500).json({ error: "Erro de servidor" });
  }
});

export default router;
