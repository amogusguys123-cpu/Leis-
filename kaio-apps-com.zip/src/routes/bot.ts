import { Router, type IRouter, type Request, type Response } from "express";
import pg from "pg";
import crypto from "crypto";

const { Pool } = pg;
const pool = new Pool({ connectionString: process.env["DATABASE_URL"] });
const router: IRouter = Router();

const BOT_SECRET = process.env["BOT_SECRET"] ?? "";
const BOT_CALLBACK_URL = process.env["BOT_CALLBACK_URL"] ?? "";

// ============================================================
//  SCHEMA
// ============================================================
async function ensureBotSchema() {
  await pool.query(`
    ALTER TABLE kaio_keys
      ADD COLUMN IF NOT EXISTS discord_id TEXT,
      ADD COLUMN IF NOT EXISTS roblox_username TEXT
  `).catch(() => {});

  await pool.query(`
    CREATE TABLE IF NOT EXISTS kaio_bot_verify (
      token       TEXT PRIMARY KEY,
      discord_id  TEXT NOT NULL,
      discord_username TEXT NOT NULL,
      key         TEXT,
      confirmed   BOOLEAN NOT NULL DEFAULT FALSE,
      created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW(),
      expires_at  TIMESTAMPTZ NOT NULL DEFAULT (NOW() + INTERVAL '10 minutes')
    )
  `);

  await pool.query(`
    CREATE TABLE IF NOT EXISTS kaio_templates (
      id          SERIAL PRIMARY KEY,
      discord_id  TEXT NOT NULL,
      discord_username TEXT NOT NULL,
      code        TEXT NOT NULL,
      config      JSONB,
      description TEXT,
      image_url   TEXT,
      system_desc TEXT,
      created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW()
    )
  `);

  await pool.query(`
    CREATE TABLE IF NOT EXISTS kaio_pending_templates (
      key         TEXT PRIMARY KEY,
      template_id INTEGER NOT NULL,
      config      JSONB,
      created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW()
    )
  `);

  await pool.query(`
    CREATE TABLE IF NOT EXISTS kaio_user_templates (
      id          SERIAL PRIMARY KEY,
      key         TEXT NOT NULL,
      template_id INTEGER NOT NULL,
      is_active   BOOLEAN NOT NULL DEFAULT FALSE,
      saved_at    TIMESTAMPTZ NOT NULL DEFAULT NOW(),
      UNIQUE(key, template_id)
    )
  `);
}

ensureBotSchema().catch((err) => {
  console.error("[kaio-bot] ensureBotSchema failed:", err?.message ?? err);
});

// ============================================================
//  MIDDLEWARE — valida BOT_SECRET
// ============================================================
function botAuth(req: Request, res: Response, next: () => void) {
  if (!BOT_SECRET) { next(); return; }
  const secret = req.headers["x-bot-secret"] as string | undefined;
  if (secret !== BOT_SECRET) {
    res.status(401).json({ error: "Não autorizado" });
    return;
  }
  next();
}

// ============================================================
//  HELPERS
// ============================================================
function getServerUrl(req: Request): string {
  const explicit = process.env["SERVER_SITE_URL"];
  if (explicit) return explicit.replace(/\/$/, "") + "/api";
  const domains = process.env["REPLIT_DOMAINS"];
  if (domains) return `https://${domains.split(",")[0]!.trim()}/api`;
  const host = req.get("host") ?? "localhost:80";
  const protocol = req.secure || req.get("x-forwarded-proto") === "https" ? "https" : "http";
  return `${protocol}://${host}/api`;
}

async function getRobloxAvatar(username: string): Promise<{ avatarUrl: string | null; userId: number | null }> {
  try {
    const searchRes = await fetch("https://users.roblox.com/v1/usernames/users", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ usernames: [username], excludeBannedUsers: false }),
    });
    const searchData = await searchRes.json() as { data?: { id: number }[] };
    const userId = searchData.data?.[0]?.id ?? null;
    if (!userId) return { avatarUrl: null, userId: null };

    const thumbRes = await fetch(
      `https://thumbnails.roblox.com/v1/users/avatar-headshot?userIds=${userId}&size=150x150&format=Png&isCircular=false`
    );
    const thumbData = await thumbRes.json() as { data?: { imageUrl?: string }[] };
    const avatarUrl = thumbData.data?.[0]?.imageUrl ?? null;
    return { avatarUrl, userId };
  } catch {
    return { avatarUrl: null, userId: null };
  }
}

function parseTemplateCode(code: string): { config: Record<string, unknown>; systemDesc: string } {
  const featureNames: Record<string, string> = {
    autoFarm: "Auto Farm", aimAssist: "Aim Assist", autoEscape: "Auto Escape",
    espEnabled: "ESP", wallhack: "Wallhack", speedBoost: "Speed Boost",
    autoPc: "Auto PC Hack", noclip: "Noclip", infiniteStamina: "Stamina Infinita",
    antiKick: "Anti-Kick", theme: "Tema", speed: "Velocidade",
    PlayerESP: "Player ESP", ComputerESP: "Computer ESP", ExitESP: "Exit ESP",
    AutoHack: "Auto Hack", AutoEscape: "Auto Escape", NeverFail: "Never Fail",
    SpeedBoost: "Speed Boost", Noclip: "Noclip", AutoHide: "Auto Hide",
    AntiSlow: "Anti Slow", HitAura: "Hit Aura", AutoTie: "Auto Tie",
    BreakRope: "Break Rope", SlowBeast: "Slow Beast", ForceAbility: "Force Ability",
    AlertUse: "Alert Ability", AutoBeastHide: "Auto Hide (Fera)", AutoCollect: "Auto Collect",
    AutoAction: "Auto Action", AutoInteract: "Auto Interact", AIPredict: "IA Predict",
    NuncaDePego: "Nunca de Pego", StalkerArmario: "Stalker Armário", ESPFreezer: "Freezer ESP",
    BeastAlert: "Beast Alert", Camera3D: "Camera 3D", AntiSlowSurvivor: "Anti Slow Survivor",
    Fullbright: "Fullbright", TeleportSurvivor: "Teleport Survivor",
    DimGraphics: "Dim Graphics", AgacharForce: "Agachar Force", WallHop: "Wall Hop",
    BeastCheck: "Beast Check",
  };

  function processConfig(config: Record<string, unknown>): { config: Record<string, unknown>; systemDesc: string } {
    const parts: string[] = [];
    if (config["game"]) parts.push(`Jogo: ${config["game"]}`);
    const cfg = config["config"] as Record<string, unknown> | undefined;
    if (cfg) {
      const active: string[] = [];
      for (const [k, v] of Object.entries(cfg)) {
        if (v === true) active.push(featureNames[k] ?? k);
        else if (k === "speed" && typeof v === "number" && v !== 1) active.push(`Velocidade x${v}`);
        else if (k === "theme" && typeof v === "string") active.push(`Tema: ${v}`);
      }
      if (active.length > 0) parts.push(`Ativo: ${active.join(", ")}`);
    }
    return { config, systemDesc: parts.length > 0 ? parts.join(" | ") : "Configuração padrão" };
  }

  const MORSE_TO_CHAR: Record<string, string> = {
    ".-":"A","-...":"B","-.-.":"C","-..":"D",".":"E","..-.":"F",".--.":"P",
    "--.":"G","....":"H","..":"I",".---":"J","-.-":"K",".-..":"L","--":"M",
    "-.":"N","---":"O","--.-":"Q",".-.":"R","...":"S","-":"T","..-":"U",
    "...-":"V",".--":"W","-..-":"X","-.--":"Y","--..":"Z",
    "-----":"0",".----":"1","..---":"2","...--":"3","....-":"4",
    ".....":"5","-....":"6","--...":"7","---..":"8","----.":"9",
    ".-.-.-":".", "--..--":",", "---...":":", "-....-":"-", ".-.-.":" +", "-..-.":"/", "...-.-":"=",
  };

  function decodeMorse(morse: string): string {
    return morse.trim().split(" ").map(s => s === "/" ? " " : (MORSE_TO_CHAR[s] ?? "")).join("");
  }

  function isMorse(s: string): boolean {
    return /^[.\- /]+$/.test(s.trim()) && s.includes(".");
  }

  // Formato compacto Kaio: NOME:VELOCIDADE:FEAT1,FEAT2,...
  function parseKaioCompact(text: string): { config: Record<string, unknown>; systemDesc: string } | null {
    const parts = text.split(":");
    if (parts.length < 2) return null;
    const name = parts[0]?.trim() || "Anônimo";
    const speedRaw = parts.length >= 3 ? parseFloat(parts[1] ?? "16") : 16;
    const speed = isNaN(speedRaw) ? 16 : Math.min(Math.max(speedRaw, 16), 100);
    const featStr = parts.length >= 3 ? (parts[2] ?? "") : (parts[1] ?? "");
    const features = featStr.split(",").map(f => f.trim()).filter(f => f.length > 0);
    if (features.length === 0) return null;
    const cfg: Record<string, unknown> = { speed };
    for (const feat of features) cfg[feat] = true;
    const activeNames = features.map(f => featureNames[f] ?? f);
    return {
      config: { game: "Flee The Facility", author: name, config: cfg },
      systemDesc: `Por: ${name} | Speed: ${speed} | Ativo: ${activeNames.slice(0, 5).join(", ")}${activeNames.length > 5 ? ` +${activeNames.length - 5}` : ""}`,
    };
  }

  // Tenta base64 → JSON
  try {
    const decoded = Buffer.from(code, "base64").toString("utf-8");
    const config = JSON.parse(decoded) as Record<string, unknown>;
    if (typeof config === "object" && config !== null) return processConfig(config);
  } catch { /* continua */ }

  // Tenta JSON direto
  try {
    const config = JSON.parse(code) as Record<string, unknown>;
    if (typeof config === "object" && config !== null) return processConfig(config);
  } catch { /* continua */ }

  // Tenta Morse → decode → parse
  if (isMorse(code)) {
    const decoded = decodeMorse(code);
    const compact = parseKaioCompact(decoded);
    if (compact) return compact;
    try {
      const config = JSON.parse(decoded) as Record<string, unknown>;
      if (typeof config === "object" && config !== null) return processConfig(config);
    } catch { /* continua */ }
  }

  // Tenta formato compacto direto (sem Morse)
  const compact = parseKaioCompact(code);
  if (compact) return compact;

  return {
    config: { raw: code },
    systemDesc: "Código personalizado (formato livre)",
  };
}

// ============================================================
//  POST /api/bot/verify-start
//  Body: { discordUserId, discordUsername }
// ============================================================
router.post("/bot/verify-start", botAuth, async (req: Request, res: Response) => {
  const discordUserId = (req.body?.discordUserId as string | undefined)?.trim();
  const discordUsername = (req.body?.discordUsername as string | undefined)?.trim();

  if (!discordUserId || !discordUsername) {
    res.status(400).json({ error: "discordUserId e discordUsername são obrigatórios" });
    return;
  }

  const token = crypto.randomBytes(24).toString("hex");
  const serverUrl = getServerUrl(req);
  const url = `${serverUrl}/bot/verify/${token}`;

  try {
    await pool.query(`DELETE FROM kaio_bot_verify WHERE expires_at < NOW()`);
    await pool.query(
      `INSERT INTO kaio_bot_verify (token, discord_id, discord_username) VALUES ($1, $2, $3)`,
      [token, discordUserId, discordUsername]
    );
    res.json({ token, url });
  } catch {
    res.status(500).json({ error: "Erro ao criar sessão de verificação" });
  }
});

// ============================================================
//  GET /api/bot/verify/:token  — página HTML de verificação
// ============================================================
router.get("/bot/verify/:token", async (req: Request, res: Response) => {
  const { token } = req.params;
  const r = await pool.query(
    `SELECT * FROM kaio_bot_verify WHERE token = $1 AND expires_at > NOW()`,
    [token]
  ).catch(() => null);

  if (!r || r.rows.length === 0) {
    res.status(410).send(verifyPageHtml("", "", true, false, null));
    return;
  }

  const session = r.rows[0];
  if (session.confirmed) {
    res.send(verifyPageHtml(session.discord_username, "", false, true, null));
    return;
  }

  res.send(verifyPageHtml(session.discord_username, token, false, false, null));
});

// ============================================================
//  POST /api/bot/verify/:token/submit  — submete a key
// ============================================================
router.post("/bot/verify/:token/submit", async (req: Request, res: Response) => {
  const { token } = req.params;
  const key = (req.body?.key as string | undefined)?.trim();

  if (!key) {
    res.status(400).json({ error: "Key não informada" });
    return;
  }

  try {
    const sv = await pool.query(
      `SELECT * FROM kaio_bot_verify WHERE token = $1 AND expires_at > NOW() AND confirmed = FALSE`,
      [token]
    );
    if (sv.rows.length === 0) {
      res.status(404).json({ error: "Sessão inválida ou expirada" });
      return;
    }
    const session = sv.rows[0];

    const kr = await pool.query(
      `SELECT * FROM kaio_keys WHERE key = $1 AND (is_permanent = TRUE OR expires_at > NOW())`,
      [key]
    );
    if (kr.rows.length === 0) {
      res.status(404).json({ error: "Key inválida ou expirada" });
      return;
    }
    const keyRow = kr.rows[0];

    let robloxUsername: string | null = keyRow.roblox_username ?? null;
    let avatarUrl: string | null = null;

    if (!robloxUsername) {
      const hbRes = await pool.query(
        `SELECT username FROM kaio_heartbeats WHERE key = $1 AND username IS NOT NULL LIMIT 1`,
        [key]
      );
      robloxUsername = hbRes.rows[0]?.username ?? null;
    }

    if (robloxUsername) {
      const roblox = await getRobloxAvatar(robloxUsername);
      avatarUrl = roblox.avatarUrl;
    }

    res.json({
      robloxUsername: robloxUsername ?? "Desconhecido",
      avatarUrl,
      keyInfo: {
        tier: keyRow.tier,
        tierName: keyRow.tier_name,
        isPermanent: keyRow.is_permanent,
        expiresAt: keyRow.expires_at,
      },
      discordUsername: session.discord_username,
      token,
      key,
    });
  } catch {
    res.status(500).json({ error: "Erro de servidor" });
  }
});

// ============================================================
//  POST /api/bot/verify/:token/confirm  — confirma autorização
// ============================================================
router.post("/bot/verify/:token/confirm", async (req: Request, res: Response) => {
  const { token } = req.params;
  const key = (req.body?.key as string | undefined)?.trim();
  const guildId = (req.body?.guildId as string | undefined)?.trim();

  if (!key) {
    res.status(400).json({ error: "Key não informada" });
    return;
  }

  try {
    const sv = await pool.query(
      `SELECT * FROM kaio_bot_verify WHERE token = $1 AND expires_at > NOW() AND confirmed = FALSE`,
      [token]
    );
    if (sv.rows.length === 0) {
      res.status(404).json({ error: "Sessão inválida, expirada ou já confirmada" });
      return;
    }
    const session = sv.rows[0];

    const kr = await pool.query(
      `SELECT * FROM kaio_keys WHERE key = $1 AND (is_permanent = TRUE OR expires_at > NOW())`,
      [key]
    );
    if (kr.rows.length === 0) {
      res.status(404).json({ error: "Key inválida ou expirada" });
      return;
    }
    const keyRow = kr.rows[0];

    await pool.query(
      `UPDATE kaio_keys SET discord_id = $1 WHERE key = $2`,
      [session.discord_id, key]
    );
    await pool.query(
      `UPDATE kaio_bot_verify SET confirmed = TRUE, key = $1 WHERE token = $2`,
      [key, token]
    );

    let robloxUsername: string | null = keyRow.roblox_username ?? null;
    let avatarUrl: string | null = null;

    if (!robloxUsername) {
      const hbRes = await pool.query(
        `SELECT username FROM kaio_heartbeats WHERE key = $1 AND username IS NOT NULL LIMIT 1`,
        [key]
      );
      robloxUsername = hbRes.rows[0]?.username ?? null;
    }

    if (robloxUsername) {
      const roblox = await getRobloxAvatar(robloxUsername);
      avatarUrl = roblox.avatarUrl;
    }

    if (BOT_CALLBACK_URL) {
      fetch(`${BOT_CALLBACK_URL}/bot/verified`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "x-bot-secret": BOT_SECRET,
        },
        body: JSON.stringify({
          discordUserId: session.discord_id,
          robloxUsername: robloxUsername ?? "Desconhecido",
          robloxAvatarUrl: avatarUrl,
          keyInfo: {
            tier: keyRow.tier,
            tierName: keyRow.tier_name,
            isPermanent: keyRow.is_permanent,
            expiresAt: keyRow.expires_at,
          },
          guildId: guildId ?? null,
        }),
      }).catch(() => {});
    }

    res.json({ ok: true });
  } catch {
    res.status(500).json({ error: "Erro de servidor" });
  }
});

// ============================================================
//  POST /api/bot/addtemp  — adiciona/remove tempo de uma key
//  Header: x-bot-secret
// ============================================================
router.post("/bot/addtemp", botAuth, async (req: Request, res: Response) => {
  const key = (req.body?.key as string | undefined)?.trim();
  const hours = parseFloat((req.body?.hours ?? "0") as string);
  const action = (req.body?.action as string | undefined) ?? "add";

  if (!key || isNaN(hours) || hours <= 0) {
    res.status(400).json({ error: "key e hours são obrigatórios e válidos" });
    return;
  }

  try {
    const kr = await pool.query(
      `SELECT * FROM kaio_keys WHERE key = $1 AND (is_permanent = TRUE OR expires_at > NOW())`,
      [key]
    );
    if (kr.rows.length === 0) {
      res.status(404).json({ error: "Key não encontrada ou expirada" });
      return;
    }
    const k = kr.rows[0];

    if (k.is_permanent) {
      res.status(400).json({ error: "Key permanente não pode ter tempo modificado" });
      return;
    }

    let newExpires: Date;
    const currentExpires = new Date(k.expires_at);

    if (action === "subtract") {
      newExpires = new Date(currentExpires.getTime() - hours * 3600 * 1000);
      if (newExpires <= new Date()) {
        newExpires = new Date(Date.now() + 60 * 1000);
      }
    } else {
      newExpires = new Date(currentExpires.getTime() + hours * 3600 * 1000);
    }

    await pool.query(`UPDATE kaio_keys SET expires_at = $1 WHERE key = $2`, [newExpires, key]);
    res.json({ ok: true, newExpiresAt: newExpires.toISOString() });
  } catch {
    res.status(500).json({ error: "Erro de servidor" });
  }
});

// ============================================================
//  POST /api/bot/reset-hwid
// ============================================================
router.post("/bot/reset-hwid", botAuth, async (req: Request, res: Response) => {
  const key = (req.body?.key as string | undefined)?.trim();
  if (!key) { res.status(400).json({ error: "key é obrigatório" }); return; }

  try {
    const r = await pool.query(
      `UPDATE kaio_keys SET hwid = NULL, failed_attempts = 0, last_failed_at = NULL WHERE key = $1 RETURNING id`,
      [key]
    );
    if (r.rowCount === 0) { res.status(404).json({ error: "Key não encontrada" }); return; }
    res.json({ ok: true });
  } catch {
    res.status(500).json({ error: "Erro de servidor" });
  }
});

// ============================================================
//  POST /api/bot/create-key
// ============================================================
router.post("/bot/create-key", botAuth, async (req: Request, res: Response) => {
  const tier = parseInt((req.body?.tier ?? "1") as string, 10);
  const level = (req.body?.level as string | undefined) ?? "standard";
  const isPermanent = req.body?.isPermanent === true || req.body?.isPermanent === "true";
  const TIER_NAMES: Record<number, string> = { 1: "Bronze", 2: "Prata", 3: "Ouro", 4: "Custom" };
  const tierName = TIER_NAMES[tier] ?? "Custom";

  let durationHours = parseFloat((req.body?.durationHours ?? "") as string);
  if (isNaN(durationHours)) {
    const defaults: Record<number, number> = { 1: 24, 2: 168, 3: 720, 4: 24 };
    durationHours = defaults[tier] ?? 24;
  }

  const chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
  let rand = "";
  for (let i = 0; i < 5; i++) rand += chars[Math.floor(Math.random() * chars.length)];
  const now = new Date();
  const key = `KAIO_${rand}${String(now.getDate()).padStart(2, "0")}${String(now.getMonth() + 1).padStart(2, "0")}${String(now.getFullYear()).slice(2)}`;
  const expiresAt = isPermanent ? null : new Date(Date.now() + durationHours * 3600 * 1000);

  try {
    await pool.query(
      `INSERT INTO kaio_keys (key, tier, tier_name, level, is_permanent, expires_at) VALUES ($1, $2, $3, $4, $5, $6)`,
      [key, tier, tierName, level, isPermanent, expiresAt]
    );
    res.json({ key, tier, tierName, level, isPermanent, expiresAt: expiresAt?.toISOString() ?? null });
  } catch {
    res.status(500).json({ error: "Erro ao criar key" });
  }
});

// ============================================================
//  POST /api/bot/announce
// ============================================================
router.post("/bot/announce", botAuth, async (req: Request, res: Response) => {
  const message = (req.body?.message as string | undefined)?.trim();
  const prefix = (req.body?.prefix as string | undefined)?.trim() ?? "CEO";

  if (!message) { res.status(400).json({ error: "message é obrigatório" }); return; }

  try {
    await pool.query(
      `INSERT INTO kaio_announce (message, prefix, active) VALUES ($1, $2, TRUE)`,
      [message, prefix]
    );
    res.json({ ok: true });
  } catch {
    res.status(500).json({ error: "Erro ao criar anúncio" });
  }
});

// ============================================================
//  GET /api/bot/active-users
// ============================================================
router.get("/bot/active-users", botAuth, async (_req: Request, res: Response) => {
  try {
    const r = await pool.query(
      `SELECT username, game_id, updated_at FROM kaio_heartbeats WHERE updated_at > NOW() - INTERVAL '5 minutes' ORDER BY updated_at DESC LIMIT 50`
    );
    res.json({ users: r.rows });
  } catch {
    res.json({ users: [] });
  }
});

// ============================================================
//  POST /api/bot/templates  — cria template
// ============================================================
router.post("/bot/templates", botAuth, async (req: Request, res: Response) => {
  const code = (req.body?.code as string | undefined)?.trim();
  const discordId = (req.body?.discordUserId as string | undefined)?.trim();
  const discordUsername = (req.body?.discordUsername as string | undefined)?.trim() ?? "Desconhecido";
  const description = (req.body?.description as string | undefined)?.trim() ?? "";
  const imageUrl = (req.body?.imageUrl as string | undefined)?.trim() ?? null;

  if (!code || !discordId) {
    res.status(400).json({ error: "code e discordUserId são obrigatórios" });
    return;
  }

  const { config, systemDesc } = parseTemplateCode(code);

  try {
    const r = await pool.query(
      `INSERT INTO kaio_templates (discord_id, discord_username, code, config, description, image_url, system_desc)
       VALUES ($1, $2, $3, $4, $5, $6, $7) RETURNING id`,
      [discordId, discordUsername, code, JSON.stringify(config), description, imageUrl, systemDesc]
    );
    res.json({ id: r.rows[0].id, systemDescription: systemDesc, config });
  } catch {
    res.status(500).json({ error: "Erro ao criar template" });
  }
});

// ============================================================
//  POST /api/bot/templates/:id/use  — aplica template a uma key
// ============================================================
router.post("/bot/templates/:id/use", botAuth, async (req: Request, res: Response) => {
  const templateId = parseInt(req.params.id, 10);
  const key = (req.body?.key as string | undefined)?.trim();

  if (!key) { res.status(400).json({ error: "key é obrigatório" }); return; }

  try {
    const tr = await pool.query(`SELECT * FROM kaio_templates WHERE id = $1`, [templateId]);
    if (tr.rows.length === 0) { res.status(404).json({ error: "Template não encontrado" }); return; }

    const kr = await pool.query(
      `SELECT id FROM kaio_keys WHERE key = $1 AND (is_permanent = TRUE OR expires_at > NOW())`,
      [key]
    );
    if (kr.rows.length === 0) { res.status(404).json({ error: "Key inválida ou expirada" }); return; }

    await pool.query(
      `INSERT INTO kaio_pending_templates (key, template_id, config) VALUES ($1, $2, $3)
       ON CONFLICT (key) DO UPDATE SET template_id = $2, config = $3, created_at = NOW()`,
      [key, templateId, JSON.stringify(tr.rows[0].config)]
    );

    // Salva na coleção do usuário (kaio_user_templates) — is_active = true
    await pool.query(
      `INSERT INTO kaio_user_templates (key, template_id, is_active) VALUES ($1, $2, TRUE)
       ON CONFLICT (key, template_id) DO UPDATE SET is_active = TRUE, saved_at = NOW()`,
      [key, templateId]
    );
    // Desativa outros templates do mesmo usuário
    await pool.query(
      `UPDATE kaio_user_templates SET is_active = FALSE WHERE key = $1 AND template_id <> $2`,
      [key, templateId]
    );

    res.json({ ok: true });
  } catch {
    res.status(500).json({ error: "Erro de servidor" });
  }
});

// ============================================================
//  GET /api/bot/pending-template?key=...  — script Roblox consome
// ============================================================
router.get("/bot/pending-template", async (req: Request, res: Response) => {
  const key = (req.query["key"] as string | undefined)?.trim();
  if (!key) { res.status(400).json({ error: "key obrigatório" }); return; }

  try {
    const r = await pool.query(
      `SELECT config FROM kaio_pending_templates WHERE key = $1`,
      [key]
    );
    if (r.rows.length === 0) { res.json({ hasPending: false }); return; }
    res.json({ hasPending: true, config: r.rows[0].config });
  } catch {
    res.status(500).json({ error: "Erro de servidor" });
  }
});

// ============================================================
//  DELETE /api/bot/active-template?key=...  — limpa template ativo
// ============================================================
router.delete("/bot/active-template", async (req: Request, res: Response) => {
  const key = (req.query["key"] as string | undefined)?.trim();
  if (!key) { res.status(400).json({ error: "key obrigatório" }); return; }
  try {
    await pool.query(`DELETE FROM kaio_pending_templates WHERE key = $1`, [key]);
    res.json({ ok: true });
  } catch {
    res.status(500).json({ error: "Erro de servidor" });
  }
});

// ============================================================
//  HTML DA PÁGINA DE VERIFICAÇÃO
// ============================================================
function verifyPageHtml(discordUsername: string, token: string, expired: boolean, alreadyConfirmed: boolean, _extra: null): string {
  if (expired) {
    return `<!DOCTYPE html><html lang="pt-BR"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Verificação - Kaio Studio</title><style>*{box-sizing:border-box;margin:0;padding:0}body{background:#0d1117;color:#e6edf3;font-family:'Segoe UI',sans-serif;display:flex;align-items:center;justify-content:center;min-height:100vh}.card{background:#161b22;border:1px solid #30363d;border-radius:12px;padding:2rem;max-width:420px;width:90%;text-align:center}.icon{font-size:3rem;margin-bottom:1rem}.title{font-size:1.4rem;font-weight:700;margin-bottom:.5rem;color:#f85149}.desc{color:#8b949e;font-size:.9rem}</style></head><body><div class="card"><div class="icon">⏰</div><div class="title">Link Expirado</div><div class="desc">Este link de verificação expirou ou é inválido.<br>Use /verify novamente no Discord para gerar um novo link.</div></div></body></html>`;
  }

  if (alreadyConfirmed) {
    return `<!DOCTYPE html><html lang="pt-BR"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Verificação - Kaio Studio</title><style>*{box-sizing:border-box;margin:0;padding:0}body{background:#0d1117;color:#e6edf3;font-family:'Segoe UI',sans-serif;display:flex;align-items:center;justify-content:center;min-height:100vh}.card{background:#161b22;border:1px solid #30363d;border-radius:12px;padding:2rem;max-width:420px;width:90%;text-align:center}.icon{font-size:3rem;margin-bottom:1rem}.title{font-size:1.4rem;font-weight:700;margin-bottom:.5rem;color:#3fb950}.desc{color:#8b949e;font-size:.9rem}</style></head><body><div class="card"><div class="icon">✅</div><div class="title">Já Verificado!</div><div class="desc">Sua conta já foi verificada com sucesso.<br>Volte ao Discord para ver a confirmação.</div></div></body></html>`;
  }

  return `<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Verificação - Kaio Studio</title>
  <style>
    *{box-sizing:border-box;margin:0;padding:0}
    body{background:#0d1117;color:#e6edf3;font-family:'Segoe UI',Tahoma,sans-serif;display:flex;align-items:center;justify-content:center;min-height:100vh;padding:1rem}
    .card{background:#161b22;border:1px solid #30363d;border-radius:16px;padding:2rem;max-width:440px;width:100%}
    .logo{text-align:center;font-size:2rem;margin-bottom:.5rem}
    h1{text-align:center;font-size:1.3rem;margin-bottom:.25rem;color:#e6edf3}
    .subtitle{text-align:center;color:#8b949e;font-size:.85rem;margin-bottom:1.5rem}
    .step{background:#0d1117;border:1px solid #21262d;border-radius:10px;padding:1rem;margin-bottom:1rem}
    .step-title{font-size:.75rem;text-transform:uppercase;letter-spacing:.08em;color:#8b949e;margin-bottom:.5rem}
    label{display:block;font-size:.85rem;color:#cdd9e5;margin-bottom:.4rem}
    input{width:100%;background:#010409;border:1px solid #30363d;border-radius:8px;color:#e6edf3;padding:.65rem .9rem;font-size:.95rem;outline:none;transition:border .2s}
    input:focus{border-color:#5865F2}
    button{width:100%;background:#5865F2;color:#fff;border:none;border-radius:8px;padding:.75rem;font-size:1rem;font-weight:600;cursor:pointer;margin-top:1rem;transition:background .2s}
    button:hover{background:#4752c4}
    button:disabled{background:#3d3d3d;cursor:not-allowed}
    .avatar-section{display:none;text-align:center;margin-bottom:1rem}
    .avatar-section img{width:80px;height:80px;border-radius:50%;border:3px solid #5865F2;margin-bottom:.5rem}
    .avatar-section .username{font-size:1rem;font-weight:600}
    .avatar-section .tier{font-size:.8rem;color:#8b949e;margin-top:.2rem}
    .perms{background:#0d1117;border:1px solid #21262d;border-radius:8px;padding:.9rem;margin-top:1rem;font-size:.82rem;color:#cdd9e5;display:none}
    .perms ul{list-style:none;padding:0}
    .perms ul li::before{content:"✓ ";color:#3fb950}
    .perms ul li{margin-bottom:.3rem}
    .error{color:#f85149;font-size:.82rem;margin-top:.5rem;display:none}
    .success-screen{display:none;text-align:center}
    .success-screen .icon{font-size:3rem;margin-bottom:.75rem}
    .success-screen h2{margin-bottom:.5rem;color:#3fb950}
    .success-screen p{color:#8b949e;font-size:.9rem}
    .tag{display:inline-block;background:#21262d;border-radius:4px;padding:.1rem .4rem;font-size:.75rem;margin-left:.3rem;font-family:monospace}
  </style>
</head>
<body>
<div class="card">
  <div id="mainFlow">
    <div class="logo">🔐</div>
    <h1>Autenticação no Kaio Studio</h1>
    <p class="subtitle">Olá, <strong>${discordUsername}</strong>! Insira sua key para verificar sua conta.</p>

    <div class="step">
      <div class="step-title">Passo 1 — Sua Key</div>
      <label for="keyInput">Key do Kaio Studio</label>
      <input type="text" id="keyInput" placeholder="KAIO_XXXXX000000" autocomplete="off" spellcheck="false">
      <p class="error" id="errorMsg"></p>
      <button id="checkBtn" onclick="checkKey()">Verificar Key</button>
    </div>

    <div class="avatar-section" id="avatarSection">
      <img id="avatarImg" src="" alt="Avatar Roblox">
      <div class="username" id="robloxName">—</div>
      <div class="tier" id="tierInfo">—</div>
    </div>

    <div class="perms" id="permsSection">
      <strong>Você autoriza o Kaio Studio a ter acesso a:</strong>
      <ul style="margin-top:.5rem">
        <li>Seu nome de usuário Roblox</li>
        <li>Tier e status da sua key</li>
        <li>Data de expiração da key</li>
        <li>HWID vinculado ao seu dispositivo</li>
        <li>Histórico de uso no jogo</li>
      </ul>
      <button id="confirmBtn" onclick="confirm()" style="margin-top:.75rem;background:#3fb950">Autorizar e Vincular</button>
    </div>
  </div>

  <div class="success-screen" id="successScreen">
    <div class="icon">🎉</div>
    <h2>Verificação Concluída!</h2>
    <p>Sua conta foi vinculada com sucesso.<br>Volte ao Discord para ver a confirmação!</p>
  </div>
</div>

<script>
let verifiedKey = null;
const token = '${token}';

async function checkKey() {
  const key = document.getElementById('keyInput').value.trim();
  const errorEl = document.getElementById('errorMsg');
  const btn = document.getElementById('checkBtn');
  errorEl.style.display = 'none';

  if (!key) { errorEl.textContent = 'Digite sua key.'; errorEl.style.display = 'block'; return; }

  btn.disabled = true;
  btn.textContent = 'Verificando...';

  try {
    const res = await fetch('/api/bot/verify/' + token + '/submit', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ key })
    });
    const data = await res.json();

    if (!res.ok) {
      errorEl.textContent = data.error || 'Key inválida. Verifique e tente novamente.';
      errorEl.style.display = 'block';
      btn.disabled = false;
      btn.textContent = 'Verificar Key';
      return;
    }

    verifiedKey = key;

    const avatarSection = document.getElementById('avatarSection');
    const permsSection = document.getElementById('permsSection');
    const avatarImg = document.getElementById('avatarImg');
    const robloxName = document.getElementById('robloxName');
    const tierInfo = document.getElementById('tierInfo');

    if (data.avatarUrl) {
      avatarImg.src = data.avatarUrl;
      avatarSection.style.display = 'block';
    }
    robloxName.textContent = data.robloxUsername || 'Desconhecido';
    tierInfo.textContent = data.keyInfo?.tierName || '';
    permsSection.style.display = 'block';

    btn.textContent = 'Key Válida ✓';
    document.getElementById('keyInput').disabled = true;
  } catch {
    errorEl.textContent = 'Erro de conexão. Tente novamente.';
    errorEl.style.display = 'block';
    btn.disabled = false;
    btn.textContent = 'Verificar Key';
  }
}

async function confirm() {
  if (!verifiedKey) return;
  const btn = document.getElementById('confirmBtn');
  btn.disabled = true;
  btn.textContent = 'Vinculando...';

  try {
    const res = await fetch('/api/bot/verify/' + token + '/confirm', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ key: verifiedKey })
    });

    if (res.ok) {
      document.getElementById('mainFlow').style.display = 'none';
      document.getElementById('successScreen').style.display = 'block';
    } else {
      btn.disabled = false;
      btn.textContent = 'Autorizar e Vincular';
    }
  } catch {
    btn.disabled = false;
    btn.textContent = 'Autorizar e Vincular';
  }
}

document.getElementById('keyInput').addEventListener('keydown', (e) => {
  if (e.key === 'Enter') checkKey();
});
</script>
</body>
</html>`;
}

// ============================================================
//  GET /api/bot/my-key?discordId=...  — key vinculada ao Discord
// ============================================================
router.get("/bot/my-key", async (req: Request, res: Response) => {
  const discordId = (req.query["discordId"] as string | undefined)?.trim();
  if (!discordId) { res.status(400).json({ error: "discordId obrigatório" }); return; }

  try {
    const r = await pool.query(
      `SELECT k.key, k.tier, k.tier_name, k.level, k.is_permanent, k.expires_at, k.discord_id, k.roblox_username,
              h.username AS heartbeat_username
       FROM kaio_keys k
       LEFT JOIN kaio_heartbeats h ON h.key = k.key
       WHERE k.discord_id = $1 AND (k.is_permanent = TRUE OR k.expires_at > NOW())
       ORDER BY k.tier DESC, k.created_at DESC LIMIT 1`,
      [discordId]
    );

    if (r.rows.length === 0) { res.json({ exists: false }); return; }
    const k = r.rows[0];
    res.json({
      exists: true,
      key: k.key,
      tier: k.tier,
      tierName: k.tier_name,
      level: k.level,
      isPermanent: k.is_permanent,
      expiresAt: k.expires_at,
      robloxUsername: k.roblox_username ?? k.heartbeat_username ?? null,
    });
  } catch {
    res.status(500).json({ error: "Erro de servidor" });
  }
});

// ============================================================
//  GET /api/bot/verified-users  — lista Discord IDs verificados
// ============================================================
router.get("/bot/verified-users", botAuth, async (_req: Request, res: Response) => {
  try {
    const r = await pool.query(
      `SELECT DISTINCT discord_id FROM kaio_keys WHERE discord_id IS NOT NULL AND (is_permanent = TRUE OR expires_at > NOW())`
    );
    res.json({ users: r.rows.map((row: { discord_id: string }) => row.discord_id) });
  } catch {
    res.json({ users: [] });
  }
});

// ============================================================
//  GET /api/bot/list-keys?limit=10&filter=all
// ============================================================
router.get("/bot/list-keys", botAuth, async (req: Request, res: Response) => {
  const limit = Math.min(parseInt((req.query["limit"] as string | undefined) ?? "10", 10), 25);
  const filter = (req.query["filter"] as string | undefined) ?? "all";

  let whereClause = "";
  if (filter === "active") whereClause = "WHERE is_permanent = TRUE OR expires_at > NOW()";
  else if (filter === "expired") whereClause = "WHERE is_permanent = FALSE AND expires_at <= NOW()";

  try {
    const r = await pool.query(
      `SELECT key, tier, tier_name, level, is_permanent, expires_at, hwid, created_at
       FROM kaio_keys ${whereClause}
       ORDER BY created_at DESC LIMIT $1`,
      [limit]
    );
    res.json({ keys: r.rows });
  } catch {
    res.json({ keys: [] });
  }
});

// ============================================================
//  POST /api/bot/expire-key  — expira uma key imediatamente
// ============================================================
router.post("/bot/expire-key", botAuth, async (req: Request, res: Response) => {
  const key = (req.body?.key as string | undefined)?.trim();
  if (!key) { res.status(400).json({ error: "key é obrigatório" }); return; }

  try {
    const r = await pool.query(
      `UPDATE kaio_keys SET expires_at = NOW() - INTERVAL '1 second', is_permanent = FALSE WHERE key = $1 RETURNING id`,
      [key]
    );
    if (r.rowCount === 0) { res.status(404).json({ error: "Key não encontrada" }); return; }
    res.json({ ok: true });
  } catch {
    res.status(500).json({ error: "Erro de servidor" });
  }
});

// ============================================================
//  GET /api/config  — configurações públicas (Discord invite, etc.)
// ============================================================
router.get("/config", async (_req: Request, res: Response) => {
  try {
    const r = await pool.query(
      `SELECT key, value FROM kaio_settings WHERE key IN ('discord_invite', 'discord_bonus_hours')`
    );
    const cfg: Record<string, string> = {};
    for (const row of r.rows) cfg[row.key as string] = row.value as string;
    res.json({
      discordInvite: cfg["discord_invite"] ?? "",
      discordBonusHours: parseFloat(cfg["discord_bonus_hours"] ?? "2"),
    });
  } catch {
    res.json({ discordInvite: "", discordBonusHours: 2 });
  }
});

// ============================================================
//  GET /api/bot/discord-status?hwid=...  — verifica se HWID tem Discord vinculado
// ============================================================
router.get("/bot/discord-status", async (req: Request, res: Response) => {
  const hwid = (req.query["hwid"] as string | undefined)?.trim();
  if (!hwid) { res.json({ linked: false }); return; }
  try {
    const r = await pool.query(
      `SELECT discord_id FROM kaio_keys WHERE hwid = $1 AND discord_id IS NOT NULL LIMIT 1`,
      [hwid]
    );
    res.json({ linked: r.rows.length > 0 });
  } catch {
    res.json({ linked: false });
  }
});

// ============================================================
//  GET /api/bot/user-templates?key=...  — templates salvos do usuário
// ============================================================
router.get("/bot/user-templates", async (req: Request, res: Response) => {
  const key = (req.query["key"] as string | undefined)?.trim();
  if (!key) { res.status(400).json({ error: "key obrigatório" }); return; }
  try {
    const r = await pool.query(
      `SELECT ut.template_id, ut.is_active, ut.saved_at,
              t.description, t.system_desc, t.image_url, t.discord_username
       FROM kaio_user_templates ut
       JOIN kaio_templates t ON t.id = ut.template_id
       WHERE ut.key = $1
       ORDER BY ut.is_active DESC, ut.saved_at DESC`,
      [key]
    );
    res.json({ templates: r.rows });
  } catch {
    res.status(500).json({ error: "Erro de servidor" });
  }
});

// ============================================================
//  POST /api/bot/templates/:id/activate  — ativa template na coleção
// ============================================================
router.post("/bot/templates/:id/activate", async (req: Request, res: Response) => {
  const templateId = parseInt(req.params.id, 10);
  const key = (req.body?.key as string | undefined)?.trim();
  if (!key) { res.status(400).json({ error: "key é obrigatório" }); return; }
  try {
    const kr = await pool.query(
      `SELECT id FROM kaio_keys WHERE key = $1 AND (is_permanent = TRUE OR expires_at > NOW())`,
      [key]
    );
    if (kr.rows.length === 0) { res.status(404).json({ error: "Key inválida ou expirada" }); return; }

    const tr = await pool.query(`SELECT config, system_desc, description FROM kaio_templates WHERE id = $1`, [templateId]);
    if (tr.rows.length === 0) { res.status(404).json({ error: "Template não encontrado" }); return; }

    // Garante que o template está na coleção do usuário
    await pool.query(
      `INSERT INTO kaio_user_templates (key, template_id, is_active) VALUES ($1, $2, TRUE)
       ON CONFLICT (key, template_id) DO UPDATE SET is_active = TRUE, saved_at = NOW()`,
      [key, templateId]
    );
    // Desativa todos os outros
    await pool.query(
      `UPDATE kaio_user_templates SET is_active = FALSE WHERE key = $1 AND template_id <> $2`,
      [key, templateId]
    );
    // Coloca na fila para o script Roblox aplicar
    await pool.query(
      `INSERT INTO kaio_pending_templates (key, template_id, config) VALUES ($1, $2, $3)
       ON CONFLICT (key) DO UPDATE SET template_id = $2, config = $3, created_at = NOW()`,
      [key, templateId, JSON.stringify(tr.rows[0].config)]
    );

    res.json({ ok: true });
  } catch {
    res.status(500).json({ error: "Erro de servidor" });
  }
});

export default router;
