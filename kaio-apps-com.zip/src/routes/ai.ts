import { Router, type IRouter, type Request, type Response } from "express";

const router: IRouter = Router();

const GEMINI_KEY = process.env["GEMINI_API_KEY"] ?? "";
const GEMINI_URL = `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=${GEMINI_KEY}`;

// Cache simples pra não spammar a API
const cache = new Map<string, { ts: number; data: object }>();
const CACHE_TTL = 6000; // 6 segundos

async function callGemini(prompt: string): Promise<object> {
  const body = {
    contents: [{ parts: [{ text: prompt }] }],
    generationConfig: {
      responseMimeType: "application/json",
      temperature: 0.2,
      maxOutputTokens: 256,
    },
  };

  const res = await fetch(GEMINI_URL, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body),
    signal: AbortSignal.timeout(8000),
  });

  if (!res.ok) {
    const err = await res.text().catch(() => "");
    throw new Error(`Gemini ${res.status}: ${err.slice(0, 200)}`);
  }

  const raw = await res.json() as any;
  const text: string = raw?.candidates?.[0]?.content?.parts?.[0]?.text ?? "{}";
  return JSON.parse(text.replace(/```json\n?|\n?```/g, "").trim());
}

// ============================================================
//  POST /ai/predict
//  Recebe contexto do jogo e retorna previsão da fera via Gemini
// ============================================================
router.post("/ai/predict", async (req: Request, res: Response) => {
  try {
    const {
      beast_positions,    // [{x,y,z}] últimas 5 posições da fera
      player_pos,         // {x,y,z}
      pcs_total,          // number — total de PCs no mapa
      pcs_done,           // number — PCs já hackeados
      my_pc_elapsed,      // number — segundos no PC atual (0 se não está em nenhum)
      my_pc_hackers,      // number — qtd de pessoas no PC atual
      is_frozen,          // bool
      survivors_count,    // number
    } = req.body ?? {};

    // Valida entrada mínima
    if (!player_pos || typeof player_pos.x !== "number") {
      res.status(400).json({ error: "player_pos obrigatório" });
      return;
    }

    // Calcula vetor de movimento da fera localmente (sem IA)
    let beastVelX = 0, beastVelZ = 0;
    let beastDist = 999;
    if (Array.isArray(beast_positions) && beast_positions.length >= 2) {
      const last = beast_positions[beast_positions.length - 1];
      const prev = beast_positions[beast_positions.length - 2];
      if (last && prev) {
        beastVelX = last.x - prev.x;
        beastVelZ = last.z - prev.z;
        const predX = last.x + beastVelX * 6;
        const predZ = last.z + beastVelZ * 6;
        beastDist = Math.sqrt(
          (predX - player_pos.x) ** 2 + (predZ - player_pos.z) ** 2
        );
      }
    }

    // Estimativa de tempo restante de hack
    const hackTimePer: Record<number, number> = { 0: 60, 1: 60, 2: 40, 3: 32 };
    const hackTime = hackTimePer[Math.min(my_pc_hackers ?? 1, 3)] ?? 28;
    const hackRemain = Math.max(0, hackTime - (my_pc_elapsed ?? 0));

    // Danger level local (sem IA) — resposta rápida
    let danger = 0;
    if (beastDist < 15) danger = 10;
    else if (beastDist < 30) danger = 8;
    else if (beastDist < 50) danger = 5;
    else if (beastDist < 80) danger = 3;
    else danger = 1;

    // Cache key pra não spammar Gemini
    const cacheKey = `${Math.round(player_pos.x / 10)}_${Math.round(player_pos.z / 10)}_${danger}`;
    const cached = cache.get(cacheKey);
    if (cached && Date.now() - cached.ts < CACHE_TTL) {
      res.json({ ...cached.data, danger_level: danger, hack_remain: hackRemain });
      return;
    }

    // Monta prompt compacto para Gemini
    const beastDesc = Array.isArray(beast_positions) && beast_positions.length > 0
      ? `últimas ${beast_positions.length} posições da fera registradas`
      : "fera não visível";

    const prompt = `Você é o sistema de IA do script KAIO APPS para o jogo Flee the Facility (Roblox).
Analise a situação e responda SOMENTE em JSON válido no formato:
{"message":"<aviso curto em português, máx 80 chars>","leave_pc":<true|false>,"recommendation":"<ação recomendada curta>","danger_word":"<Safe|Atenção|Perigo|FUJA>"}

Contexto atual:
- Fera: ${beastDesc}, velocidade estimada (vx=${beastVelX.toFixed(1)}, vz=${beastVelZ.toFixed(1)}), dist prevista em 6s = ${beastDist.toFixed(0)} studs
- Jogador: x=${player_pos.x?.toFixed(0)}, z=${player_pos.z?.toFixed(0)}
- PCs: ${pcs_done ?? 0}/${pcs_total ?? 5} concluídos | PC atual: ${hackRemain.toFixed(0)}s restantes com ${my_pc_hackers ?? 1} hackers
- Sobreviventes: ${survivors_count ?? 1} | Congelado: ${is_frozen ? "SIM" : "NÃO"}

Regra: leave_pc=true se a fera está a menos de 40 studs prevista E o hack leva mais de 8s ainda.`;

    let aiResult: any = {};
    try {
      aiResult = await callGemini(prompt);
      cache.set(cacheKey, { ts: Date.now(), data: aiResult });
    } catch (e) {
      // Fallback sem IA
      aiResult = {
        message: danger >= 8 ? "Fera muito perto! Fuja!" : danger >= 5 ? "Fera se aproximando, cuidado!" : "Situação segura.",
        leave_pc: danger >= 8 && hackRemain > 8,
        recommendation: danger >= 8 ? "Esconda-se imediatamente" : "Continue hackeando",
        danger_word: danger >= 8 ? "FUJA" : danger >= 5 ? "Perigo" : danger >= 3 ? "Atenção" : "Safe",
      };
    }

    res.json({
      danger_level: danger,
      hack_remain: hackRemain,
      beast_dist_predicted: Math.round(beastDist),
      ...aiResult,
    });
  } catch (err: any) {
    console.error("[ai/predict]", err?.message ?? err);
    res.status(500).json({ error: "Erro interno" });
  }
});

export default router;
