import { Router, type IRouter, type Request, type Response } from "express";
import pg from "pg";
import crypto from "crypto";
import { execSync } from "child_process";
import { join, dirname, extname } from "path";
import { fileURLToPath } from "url";
import { existsSync, mkdirSync, createReadStream, unlinkSync } from "fs";
import multer from "multer";

const __dirname = dirname(fileURLToPath(import.meta.url));
const scriptsDir = join(__dirname, "../scripts");
const uploadsDir = "/tmp/kaio-ads-uploads";

// Chave mestra — configurada via env var no Shardcloud/deploy (nunca exposta no código)
const KAIO_KEY = process.env["KAIO_KEY"] ?? "KAIO2108";
if (!existsSync(uploadsDir)) mkdirSync(uploadsDir, { recursive: true });

const storage = multer.diskStorage({
  destination: (_req, _file, cb) => cb(null, uploadsDir),
  filename: (_req, file, cb) => {
    const unique = Date.now() + "_" + crypto.randomBytes(6).toString("hex");
    cb(null, unique + extname(file.originalname).toLowerCase());
  },
});
const upload = multer({
  storage,
  limits: { fileSize: 8 * 1024 * 1024 },
  fileFilter: (_req, file, cb) => {
    if (file.mimetype.startsWith("image/")) cb(null, true);
    else cb(new Error("Apenas imagens são permitidas"));
  },
});

const { Pool } = pg;
const pool = new Pool({ connectionString: process.env["DATABASE_URL"] });
const router: IRouter = Router();

const ADMIN_PASSWORD = process.env["ADMIN_PASSWORD"] ?? "4476815";
const ADMIN_TOKENS = new Set<string>();

// ============================================================
//  SCHEMA
// ============================================================
async function ensureAdminSchema() {
  await pool.query(`
    CREATE TABLE IF NOT EXISTS kaio_settings (
      key TEXT PRIMARY KEY,
      value TEXT NOT NULL
    )
  `);

  await pool.query(`
    CREATE TABLE IF NOT EXISTS kaio_ads (
      id        SERIAL PRIMARY KEY,
      type      TEXT NOT NULL CHECK (type IN ('image','text')),
      content   TEXT NOT NULL,
      title     TEXT,
      link_url  TEXT,
      active    BOOLEAN NOT NULL DEFAULT TRUE,
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    )
  `);

  await pool.query(`
    CREATE TABLE IF NOT EXISTS kaio_heartbeats (
      hwid       TEXT PRIMARY KEY,
      username   TEXT,
      game_id    TEXT,
      server_id  TEXT,
      key        TEXT,
      tier       INTEGER DEFAULT 1,
      updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    )
  `);

  await pool.query(`
    CREATE TABLE IF NOT EXISTS kaio_blocked (
      username   TEXT PRIMARY KEY,
      reason     TEXT,
      blocked_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    )
  `);

  await pool.query(`
    CREATE TABLE IF NOT EXISTS kaio_announce (
      id         SERIAL PRIMARY KEY,
      message    TEXT NOT NULL,
      prefix     TEXT NOT NULL DEFAULT 'CEO',
      active     BOOLEAN NOT NULL DEFAULT TRUE,
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    )
  `);

  const defaults: Record<string, string> = {
    tier_1_duration: "24",
    tier_2_duration: "168",
    tier_3_duration: "720",
    work_checkpoints: "2",
  };

  for (const [k, v] of Object.entries(defaults)) {
    await pool.query(
      `INSERT INTO kaio_settings (key, value) VALUES ($1, $2) ON CONFLICT (key) DO NOTHING`,
      [k, v]
    );
  }

  await pool.query(`
    CREATE TABLE IF NOT EXISTS kaio_kick_queue (
      username    TEXT PRIMARY KEY,
      requested_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    )
  `);

  // Seed da chave mestra (permanent, tier 99) — valor vem de env var KAIO_KEY
  await pool.query(
    `INSERT INTO kaio_keys (key, tier, tier_name, level, is_permanent)
     VALUES ($1, 99, 'KAIO', 'kaio', TRUE)
     ON CONFLICT (key) DO NOTHING`,
    [KAIO_KEY]
  ).catch(() => {});
}
ensureAdminSchema().catch((err) => {
  console.error("[kaio] ensureAdminSchema failed (server stays up):", err?.message ?? err);
});

// ============================================================
//  SETTINGS HELPERS
// ============================================================
export async function getSetting(key: string, fallback: string): Promise<string> {
  try {
    const r = await pool.query(`SELECT value FROM kaio_settings WHERE key = $1`, [key]);
    return r.rows.length > 0 ? r.rows[0].value : fallback;
  } catch {
    return fallback;
  }
}

export async function getWorkCheckpoints(): Promise<number> {
  const v = await getSetting("work_checkpoints", "2");
  const n = parseInt(v, 10);
  return Math.min(10, Math.max(2, isNaN(n) ? 2 : n));
}

export async function getTierDurationHours(tier: number): Promise<number> {
  const defaults: Record<number, number> = { 1: 24, 2: 168, 3: 720 };
  const v = await getSetting(`tier_${tier}_duration`, String(defaults[tier] ?? 24));
  const n = parseFloat(v);
  return isNaN(n) ? (defaults[tier] ?? 24) : n;
}

// ============================================================
//  AUTH
// ============================================================
function generateAdminToken(): string {
  return crypto.randomBytes(24).toString("hex");
}

function generateKey(): string {
  const chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
  let rand = "";
  for (let i = 0; i < 5; i++) {
    rand += chars[Math.floor(Math.random() * chars.length)];
  }
  const now = new Date();
  const dd = String(now.getDate()).padStart(2, "0");
  const mm = String(now.getMonth() + 1).padStart(2, "0");
  const yy = String(now.getFullYear()).slice(2);
  return `KAIO_${rand}${dd}${mm}${yy}`;
}

function authMiddleware(req: Request, res: Response, next: () => void) {
  const token = req.headers["x-admin-token"] as string | undefined;
  if (!token || !ADMIN_TOKENS.has(token)) {
    res.status(401).json({ error: "Não autorizado" });
    return;
  }
  next();
}

// ============================================================
//  LOGIN — POST /api/admin/login
// ============================================================
router.post("/admin/login", (req: Request, res: Response) => {
  const password = req.body?.password as string | undefined;
  if (!password || password !== ADMIN_PASSWORD) {
    res.status(401).json({ error: "Senha inválida" });
    return;
  }
  const token = generateAdminToken();
  ADMIN_TOKENS.add(token);
  setTimeout(() => ADMIN_TOKENS.delete(token), 8 * 3600 * 1000);
  res.json({ token });
});

// ============================================================
//  LOGOUT — POST /api/admin/logout
// ============================================================
router.post("/admin/logout", (req: Request, res: Response) => {
  const token = req.headers["x-admin-token"] as string | undefined;
  if (token) ADMIN_TOKENS.delete(token);
  res.json({ ok: true });
});

// ============================================================
//  LIST KEYS — GET /api/admin/keys
// ============================================================
router.get("/admin/keys", (req: Request, res: Response) => {
  authMiddleware(req, res, async () => {
    try {
      const r = await pool.query(
        `SELECT id, key, tier, tier_name, level, is_permanent, expires_at, hwid, failed_attempts, created_at
         FROM kaio_keys
         ORDER BY created_at DESC
         LIMIT 500`
      );
      res.json({ keys: r.rows });
    } catch {
      res.status(500).json({ error: "Erro ao buscar keys" });
    }
  });
});

// ============================================================
//  CREATE KEY — POST /api/admin/keys/create
//  Body: { tier, level, durationHours?, isPermanent, customKey? }
// ============================================================
router.post("/admin/keys/create", (req: Request, res: Response) => {
  authMiddleware(req, res, async () => {
    const tier = parseInt((req.body?.tier ?? "1") as string, 10);
    const level = (req.body?.level as string | undefined) ?? "standard";
    const isPermanent = req.body?.isPermanent === true || req.body?.isPermanent === "true";
    const customKey = (req.body?.customKey as string | undefined)?.trim();

    const TIER_NAMES: Record<number, string> = {
      1: "Bronze", 2: "Prata", 3: "Ouro", 4: "Custom",
    };
    const tierName = TIER_NAMES[tier] ?? "Custom";

    let durationHours: number;
    if (req.body?.durationHours !== undefined && req.body?.durationHours !== "") {
      durationHours = parseFloat(req.body.durationHours as string);
    } else {
      durationHours = await getTierDurationHours(tier);
    }

    const key = customKey || generateKey();

    let expiresAt: Date | null = null;
    if (!isPermanent) {
      expiresAt = new Date(Date.now() + durationHours * 3600 * 1000);
    }

    try {
      await pool.query(
        `INSERT INTO kaio_keys (key, tier, tier_name, level, is_permanent, expires_at)
         VALUES ($1, $2, $3, $4, $5, $6)`,
        [key, tier, tierName, level, isPermanent, expiresAt]
      );
      res.json({
        key, tier, tierName, level, isPermanent,
        expiresAt: expiresAt?.toISOString() ?? null,
        durationHours: isPermanent ? null : durationHours,
      });
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : "Erro desconhecido";
      if (msg.includes("unique") || msg.includes("duplicate")) {
        res.status(409).json({ error: "Key já existe" });
      } else {
        res.status(500).json({ error: "Erro ao criar key" });
      }
    }
  });
});

// ============================================================
//  DELETE KEY — DELETE /api/admin/keys/:id
// ============================================================
router.delete("/admin/keys/:id", (req: Request, res: Response) => {
  authMiddleware(req, res, async () => {
    const { id } = req.params;
    try {
      await pool.query(`DELETE FROM kaio_keys WHERE id = $1`, [parseInt(id, 10)]);
      res.json({ ok: true });
    } catch {
      res.status(500).json({ error: "Erro ao deletar key" });
    }
  });
});

// ============================================================
//  REVOKE HWID — DELETE /api/admin/keys/:id/hwid
// ============================================================
router.delete("/admin/keys/:id/hwid", (req: Request, res: Response) => {
  authMiddleware(req, res, async () => {
    const { id } = req.params;
    try {
      await pool.query(
        `UPDATE kaio_keys SET hwid = NULL, failed_attempts = 0, last_failed_at = NULL WHERE id = $1`,
        [parseInt(id, 10)]
      );
      res.json({ ok: true });
    } catch {
      res.status(500).json({ error: "Erro ao revogar HWID" });
    }
  });
});

// ============================================================
//  STATS — GET /api/admin/stats
// ============================================================
router.get("/admin/stats", (req: Request, res: Response) => {
  authMiddleware(req, res, async () => {
    try {
      const total = await pool.query(`SELECT COUNT(*) FROM kaio_keys`);
      const active = await pool.query(
        `SELECT COUNT(*) FROM kaio_keys WHERE is_permanent = TRUE OR expires_at > NOW()`
      );
      const expired = await pool.query(
        `SELECT COUNT(*) FROM kaio_keys WHERE is_permanent = FALSE AND expires_at <= NOW()`
      );
      const sessions = await pool.query(
        `SELECT COUNT(*) FROM kaio_sessions WHERE created_at > NOW() - INTERVAL '24 hours'`
      );
      const byTier = await pool.query(
        `SELECT tier, COUNT(*) as cnt FROM kaio_keys GROUP BY tier`
      );
      const tierCounts: Record<string, number> = {};
      for (const r of byTier.rows) {
        tierCounts[String(r.tier)] = parseInt(r.cnt, 10);
      }
      res.json({
        total: parseInt(total.rows[0].count, 10),
        active: parseInt(active.rows[0].count, 10),
        expired: parseInt(expired.rows[0].count, 10),
        sessions24h: parseInt(sessions.rows[0].count, 10),
        byTier: tierCounts,
      });
    } catch {
      res.status(500).json({ error: "Erro ao buscar stats" });
    }
  });
});

// ============================================================
//  GET SETTINGS — GET /api/admin/settings
// ============================================================
router.get("/admin/settings", (req: Request, res: Response) => {
  authMiddleware(req, res, async () => {
    try {
      const r = await pool.query(`SELECT key, value FROM kaio_settings`);
      const settings: Record<string, string> = {};
      for (const row of r.rows) {
        settings[row.key] = row.value;
      }
      res.json({ settings });
    } catch {
      res.status(500).json({ error: "Erro ao buscar configurações" });
    }
  });
});

// ============================================================
//  UPDATE SETTINGS — PUT /api/admin/settings
//  Body: { key, value }
// ============================================================
router.put("/admin/settings", (req: Request, res: Response) => {
  authMiddleware(req, res, async () => {
    const key = (req.body?.key as string | undefined)?.trim();
    const value = (req.body?.value as string | undefined)?.trim();

    if (!key || value === undefined) {
      res.status(400).json({ error: "key e value são obrigatórios" });
      return;
    }

    const allowed = ["tier_1_duration", "tier_2_duration", "tier_3_duration", "work_checkpoints", "discord_invite", "discord_bonus_hours"];
    if (!allowed.includes(key)) {
      res.status(400).json({ error: "Configuração não permitida" });
      return;
    }

    if (key === "work_checkpoints") {
      const n = parseInt(value, 10);
      if (isNaN(n) || n < 2 || n > 10) {
        res.status(400).json({ error: "Checkpoints deve ser entre 2 e 10" });
        return;
      }
    }

    try {
      await pool.query(
        `INSERT INTO kaio_settings (key, value) VALUES ($1, $2)
         ON CONFLICT (key) DO UPDATE SET value = $2`,
        [key, value]
      );
      res.json({ ok: true, key, value });
    } catch {
      res.status(500).json({ error: "Erro ao atualizar configuração" });
    }
  });
});

// ============================================================
//  BULK UPDATE TIER DURATION — PUT /api/admin/tiers/:tier/duration
//  Muda a duração padrão do tier E re-calcula todas keys ativas daquele tier
//  Body: { hours }
// ============================================================
router.put("/admin/tiers/:tier/duration", (req: Request, res: Response) => {
  authMiddleware(req, res, async () => {
    const tier = parseInt(req.params.tier, 10);
    const hours = parseFloat((req.body?.hours ?? "") as string);

    if (isNaN(tier) || tier < 1 || tier > 4) {
      res.status(400).json({ error: "Tier inválido (1-4)" });
      return;
    }
    if (isNaN(hours) || hours <= 0) {
      res.status(400).json({ error: "hours deve ser um número positivo" });
      return;
    }

    try {
      await pool.query(
        `INSERT INTO kaio_settings (key, value) VALUES ($1, $2)
         ON CONFLICT (key) DO UPDATE SET value = $2`,
        [`tier_${tier}_duration`, String(hours)]
      );

      const newExpires = new Date(Date.now() + hours * 3600 * 1000);
      const result = await pool.query(
        `UPDATE kaio_keys
         SET expires_at = $1
         WHERE tier = $2 AND is_permanent = FALSE
         RETURNING id`,
        [newExpires, tier]
      );

      res.json({
        ok: true,
        tier,
        newDurationHours: hours,
        keysUpdated: result.rowCount ?? 0,
        newExpiresAt: newExpires.toISOString(),
      });
    } catch {
      res.status(500).json({ error: "Erro ao atualizar duração do tier" });
    }
  });
});

// ============================================================
//  DOWNLOAD SCRIPTS ZIP — GET /api/admin/download-scripts
// ============================================================
router.get("/admin/download-scripts", (req: Request, res: Response) => {
  authMiddleware(req, res, () => {
    try {
      const tmpDir = "/tmp/kaio-scripts-zip";
      if (!existsSync(tmpDir)) mkdirSync(tmpDir, { recursive: true });

      const zipPath = `${tmpDir}/kaio-scripts.zip`;

      execSync(`cd "${scriptsDir}" && zip -r "${zipPath}" . -x "*.map"`, {
        stdio: "pipe",
        timeout: 30000,
      });

      res.setHeader("Content-Type", "application/zip");
      res.setHeader("Content-Disposition", "attachment; filename=kaio-scripts.zip");
      res.setHeader("Cache-Control", "no-cache");

      const stream = createReadStream(zipPath);
      stream.pipe(res);
    } catch (err) {
      const msg = err instanceof Error ? err.message : "Erro desconhecido";
      res.status(500).json({ error: "Erro ao criar zip: " + msg });
    }
  });
});

// ============================================================
//  PUBLIC: GET ACTIVE ADS — GET /api/ads
// ============================================================
router.get("/ads", async (_req: Request, res: Response) => {
  try {
    const r = await pool.query(
      `SELECT id, type, content, title, link_url FROM kaio_ads WHERE active = TRUE ORDER BY created_at DESC`
    );
    res.json({ ads: r.rows });
  } catch {
    res.json({ ads: [] });
  }
});

// ============================================================
//  PUBLIC: SERVE AD IMAGE — GET /api/ads/image/:filename
// ============================================================
router.get("/ads/image/:filename", (req: Request, res: Response) => {
  const filename = req.params.filename;
  if (!/^[\w\-]+\.(jpg|jpeg|png|gif|webp)$/i.test(filename)) {
    res.status(400).json({ error: "Nome inválido" });
    return;
  }
  const filePath = join(uploadsDir, filename);
  if (!existsSync(filePath)) {
    res.status(404).json({ error: "Imagem não encontrada" });
    return;
  }
  res.sendFile(filePath);
});

// ============================================================
//  LIST ADS — GET /api/admin/ads
// ============================================================
router.get("/admin/ads", (req: Request, res: Response) => {
  authMiddleware(req, res, async () => {
    try {
      const r = await pool.query(
        `SELECT id, type, content, title, link_url, active, created_at FROM kaio_ads ORDER BY created_at DESC`
      );
      res.json({ ads: r.rows });
    } catch {
      res.status(500).json({ error: "Erro ao buscar propagandas" });
    }
  });
});

// ============================================================
//  CREATE AD (TEXT) — POST /api/admin/ads/text
//  Body: { content, title?, link_url? }
// ============================================================
router.post("/admin/ads/text", (req: Request, res: Response) => {
  authMiddleware(req, res, async () => {
    const content = (req.body?.content as string | undefined)?.trim();
    const title = (req.body?.title as string | undefined)?.trim() || null;
    const link_url = (req.body?.link_url as string | undefined)?.trim() || null;

    if (!content) {
      res.status(400).json({ error: "content é obrigatório" });
      return;
    }

    try {
      const r = await pool.query(
        `INSERT INTO kaio_ads (type, content, title, link_url) VALUES ('text', $1, $2, $3) RETURNING *`,
        [content, title, link_url]
      );
      res.json({ ad: r.rows[0] });
    } catch {
      res.status(500).json({ error: "Erro ao criar propaganda" });
    }
  });
});

// ============================================================
//  CREATE AD (IMAGE) — POST /api/admin/ads/image
//  multipart/form-data: image file + title? + link_url?
// ============================================================
router.post("/admin/ads/image", (req: Request, res: Response) => {
  authMiddleware(req, res, () => {
    upload.single("image")(req, res, async (err) => {
      if (err) {
        res.status(400).json({ error: err.message || "Erro no upload" });
        return;
      }
      if (!req.file) {
        res.status(400).json({ error: "Nenhuma imagem enviada" });
        return;
      }

      const filename = req.file.filename;
      const title = (req.body?.title as string | undefined)?.trim() || null;
      const link_url = (req.body?.link_url as string | undefined)?.trim() || null;

      try {
        const r = await pool.query(
          `INSERT INTO kaio_ads (type, content, title, link_url) VALUES ('image', $1, $2, $3) RETURNING *`,
          [filename, title, link_url]
        );
        res.json({ ad: r.rows[0] });
      } catch {
        unlinkSync(join(uploadsDir, filename));
        res.status(500).json({ error: "Erro ao salvar propaganda" });
      }
    });
  });
});

// ============================================================
//  GET APP ADS — GET /api/admin/ads/app
// ============================================================
router.get("/admin/ads/app", (req: Request, res: Response) => {
  authMiddleware(req, res, async () => {
    try {
      const r = await pool.query(
        `SELECT id, type, content, title, link_url, active, placement, is_app_ad, created_at
           FROM kaio_ads
          WHERE is_app_ad = TRUE
          ORDER BY created_at DESC`
      );
      res.json({ ads: r.rows });
    } catch {
      res.status(500).json({ error: "Erro ao buscar anúncios do app" });
    }
  });
});

// ============================================================
//  CREATE APP AD — POST /api/admin/ads/app
//  Body: { title, content, link_url?, placement }
// ============================================================
router.post("/admin/ads/app", (req: Request, res: Response) => {
  authMiddleware(req, res, async () => {
    const title     = (req.body?.title as string | undefined)?.trim();
    const content   = (req.body?.content as string | undefined)?.trim();
    const link_url  = (req.body?.link_url as string | undefined)?.trim() || null;
    const placement = (req.body?.placement as string | undefined)?.trim() || "inline";

    if (!title || !content) {
      res.status(400).json({ error: "Título e conteúdo são obrigatórios" });
      return;
    }
    if (!["full_screen", "inline"].includes(placement)) {
      res.status(400).json({ error: "placement inválido" });
      return;
    }

    try {
      const r = await pool.query(
        `INSERT INTO kaio_ads (type, content, title, link_url, placement, is_app_ad)
         VALUES ('text', $1, $2, $3, $4, TRUE) RETURNING *`,
        [content, title, link_url, placement]
      );
      res.json({ ad: r.rows[0] });
    } catch {
      res.status(500).json({ error: "Erro ao criar anúncio do app" });
    }
  });
});

// ============================================================
//  TOGGLE AD — PUT /api/admin/ads/:id/toggle
// ============================================================
router.put("/admin/ads/:id/toggle", (req: Request, res: Response) => {
  authMiddleware(req, res, async () => {
    const { id } = req.params;
    try {
      const r = await pool.query(
        `UPDATE kaio_ads SET active = NOT active WHERE id = $1 RETURNING active`,
        [parseInt(id, 10)]
      );
      if (r.rowCount === 0) {
        res.status(404).json({ error: "Propaganda não encontrada" });
        return;
      }
      res.json({ active: r.rows[0].active });
    } catch {
      res.status(500).json({ error: "Erro ao alternar status" });
    }
  });
});

// ============================================================
//  DELETE AD — DELETE /api/admin/ads/:id
// ============================================================
router.delete("/admin/ads/:id", (req: Request, res: Response) => {
  authMiddleware(req, res, async () => {
    const { id } = req.params;
    try {
      const r = await pool.query(
        `DELETE FROM kaio_ads WHERE id = $1 RETURNING type, content`,
        [parseInt(id, 10)]
      );
      if (r.rowCount === 0) {
        res.status(404).json({ error: "Propaganda não encontrada" });
        return;
      }
      const row = r.rows[0];
      if (row.type === "image") {
        const imgPath = join(uploadsDir, row.content);
        if (existsSync(imgPath)) unlinkSync(imgPath);
      }
      res.json({ ok: true });
    } catch {
      res.status(500).json({ error: "Erro ao deletar propaganda" });
    }
  });
});

// ============================================================
//  ADD TIME TO KEY — POST /api/admin/keys/:id/add-time
//  Body: { hours }
// ============================================================
router.post("/admin/keys/:id/add-time", (req: Request, res: Response) => {
  authMiddleware(req, res, async () => {
    const id = parseInt(req.params.id, 10);
    const hours = parseFloat((req.body?.hours ?? "0") as string);
    if (isNaN(hours) || hours <= 0) {
      res.status(400).json({ error: "hours deve ser um número positivo" });
      return;
    }
    try {
      const r = await pool.query(
        `UPDATE kaio_keys
         SET expires_at = GREATEST(COALESCE(expires_at, NOW()), NOW()) + ($1 * INTERVAL '1 hour')
         WHERE id = $2 AND is_permanent = FALSE
         RETURNING key, expires_at`,
        [hours, id]
      );
      if (r.rowCount === 0) {
        res.status(404).json({ error: "Key não encontrada ou é permanente" });
        return;
      }
      res.json({ ok: true, key: r.rows[0].key, expiresAt: r.rows[0].expires_at });
    } catch {
      res.status(500).json({ error: "Erro ao adicionar tempo" });
    }
  });
});

// ============================================================
//  ACTIVE USERS (heartbeat) — GET /api/admin/active-users
// ============================================================
router.get("/admin/active-users", (req: Request, res: Response) => {
  authMiddleware(req, res, async () => {
    try {
      const r = await pool.query(
        `SELECT hwid, username, game_id, server_id, key, tier, updated_at
         FROM kaio_heartbeats
         WHERE updated_at > NOW() - INTERVAL '2 minutes'
         ORDER BY updated_at DESC`
      );
      res.json({ users: r.rows });
    } catch {
      res.status(500).json({ error: "Erro ao buscar usuários ativos" });
    }
  });
});

// ============================================================
//  BLOCK USER — POST /api/admin/block-user
//  Body: { username, reason? }
// ============================================================
router.post("/admin/block-user", (req: Request, res: Response) => {
  authMiddleware(req, res, async () => {
    const username = (req.body?.username as string | undefined)?.trim();
    const reason = (req.body?.reason as string | undefined)?.trim() || null;
    if (!username) {
      res.status(400).json({ error: "username é obrigatório" });
      return;
    }
    try {
      await pool.query(
        `INSERT INTO kaio_blocked (username, reason) VALUES ($1, $2)
         ON CONFLICT (username) DO UPDATE SET reason = $2, blocked_at = NOW()`,
        [username, reason]
      );
      res.json({ ok: true });
    } catch {
      res.status(500).json({ error: "Erro ao bloquear usuário" });
    }
  });
});

// ============================================================
//  UNBLOCK USER — DELETE /api/admin/block-user/:username
// ============================================================
router.delete("/admin/block-user/:username", (req: Request, res: Response) => {
  authMiddleware(req, res, async () => {
    const { username } = req.params;
    try {
      await pool.query(`DELETE FROM kaio_blocked WHERE username = $1`, [username]);
      res.json({ ok: true });
    } catch {
      res.status(500).json({ error: "Erro ao desbloquear usuário" });
    }
  });
});

// ============================================================
//  LIST BLOCKED — GET /api/admin/blocked-users
// ============================================================
router.get("/admin/blocked-users", (req: Request, res: Response) => {
  authMiddleware(req, res, async () => {
    try {
      const r = await pool.query(
        `SELECT username, reason, blocked_at FROM kaio_blocked ORDER BY blocked_at DESC`
      );
      res.json({ blocked: r.rows });
    } catch {
      res.status(500).json({ error: "Erro ao buscar bloqueados" });
    }
  });
});

// ============================================================
//  SEND ANNOUNCE — POST /api/admin/announce
//  Body: { message, prefix? }
// ============================================================
router.post("/admin/announce", (req: Request, res: Response) => {
  authMiddleware(req, res, async () => {
    const message = (req.body?.message as string | undefined)?.trim();
    const prefix = (req.body?.prefix as string | undefined)?.trim() || "CEO";
    if (!message) {
      res.status(400).json({ error: "message é obrigatório" });
      return;
    }
    try {
      await pool.query(`UPDATE kaio_announce SET active = FALSE`);
      await pool.query(
        `INSERT INTO kaio_announce (message, prefix, active) VALUES ($1, $2, TRUE)`,
        [message, prefix]
      );
      res.json({ ok: true });
    } catch {
      res.status(500).json({ error: "Erro ao publicar anúncio" });
    }
  });
});

// ============================================================
//  CLEAR ANNOUNCE — DELETE /api/admin/announce
// ============================================================
router.delete("/admin/announce", (req: Request, res: Response) => {
  authMiddleware(req, res, async () => {
    try {
      await pool.query(`UPDATE kaio_announce SET active = FALSE`);
      res.json({ ok: true });
    } catch {
      res.status(500).json({ error: "Erro ao limpar anúncio" });
    }
  });
});

// ============================================================
//  PUBLIC: CURRENT ANNOUNCE — GET /api/announce
// ============================================================
router.get("/announce", async (_req: Request, res: Response) => {
  try {
    const r = await pool.query(
      `SELECT message, prefix FROM kaio_announce WHERE active = TRUE ORDER BY created_at DESC LIMIT 1`
    );
    if (r.rows.length === 0) {
      res.json({ announce: null });
    } else {
      res.json({ announce: r.rows[0] });
    }
  } catch {
    res.json({ announce: null });
  }
});

// ============================================================
//  PUBLIC: HEARTBEAT — POST /api/heartbeat
//  Body: { hwid, username, gameId, serverId, key, tier }
// ============================================================
router.post("/heartbeat", async (req: Request, res: Response) => {
  const hwid = (req.body?.hwid as string | undefined)?.trim();
  if (!hwid) { res.json({ ok: false }); return; }
  const username  = (req.body?.username  as string | undefined)?.trim() || null;
  const gameId    = (req.body?.gameId    as string | undefined)?.trim() || null;
  const serverId  = (req.body?.serverId  as string | undefined)?.trim() || null;
  const key       = (req.body?.key       as string | undefined)?.trim() || null;
  const tier      = parseInt((req.body?.tier ?? "1") as string, 10) || 1;
  try {
    await pool.query(
      `INSERT INTO kaio_heartbeats (hwid, username, game_id, server_id, key, tier, updated_at)
       VALUES ($1,$2,$3,$4,$5,$6,NOW())
       ON CONFLICT (hwid) DO UPDATE SET
         username=EXCLUDED.username, game_id=EXCLUDED.game_id,
         server_id=EXCLUDED.server_id, key=EXCLUDED.key,
         tier=EXCLUDED.tier, updated_at=NOW()`,
      [hwid, username, gameId, serverId, key, tier]
    );
    // Check for active announce to return
    const ann = await pool.query(
      `SELECT message, prefix FROM kaio_announce WHERE active = TRUE ORDER BY created_at DESC LIMIT 1`
    );
    res.json({ ok: true, announce: ann.rows[0] ?? null });
  } catch {
    res.json({ ok: false });
  }
});

// ============================================================
//  PUBLIC: BLOCKED CHECK — GET /api/blocked?username=...
// ============================================================
router.get("/blocked", async (req: Request, res: Response) => {
  const username = (req.query["username"] as string | undefined)?.trim();
  if (!username) { res.json({ blocked: false }); return; }
  try {
    const r = await pool.query(
      `SELECT reason FROM kaio_blocked WHERE username = $1`, [username]
    );
    res.json({ blocked: r.rows.length > 0, reason: r.rows[0]?.reason ?? null });
  } catch {
    res.json({ blocked: false });
  }
});

// ============================================================
//  IN-GAME ADMIN: ACTIVE USERS — GET /api/admin-game/active-users
//  Header: x-game-admin: <KAIO_GAME_ADMIN_KEY env var>
// ============================================================
const GAME_ADMIN_KEY = process.env["KAIO_GAME_ADMIN_KEY"] ?? KAIO_KEY;
function gameAdminMiddleware(req: Request, res: Response, next: () => void) {
  if (req.headers["x-game-admin"] !== GAME_ADMIN_KEY) {
    res.status(401).json({ error: "Não autorizado" });
    return;
  }
  next();
}

router.get("/admin-game/active-users", (req: Request, res: Response) => {
  gameAdminMiddleware(req, res, async () => {
    try {
      const r = await pool.query(
        `SELECT username, game_id, server_id, tier, updated_at
         FROM kaio_heartbeats
         WHERE updated_at > NOW() - INTERVAL '2 minutes'
         ORDER BY updated_at DESC`
      );
      res.json({ users: r.rows });
    } catch {
      res.status(500).json({ error: "Erro" });
    }
  });
});

// ============================================================
//  IN-GAME ADMIN: ANNOUNCE — POST /api/admin-game/announce
// ============================================================
router.post("/admin-game/announce", (req: Request, res: Response) => {
  gameAdminMiddleware(req, res, async () => {
    const message = (req.body?.message as string | undefined)?.trim();
    const prefix = (req.body?.prefix as string | undefined)?.trim() || "CEO";
    if (!message) { res.status(400).json({ error: "message obrigatório" }); return; }
    try {
      await pool.query(`UPDATE kaio_announce SET active = FALSE`);
      await pool.query(
        `INSERT INTO kaio_announce (message, prefix, active) VALUES ($1, $2, TRUE)`,
        [message, prefix]
      );
      res.json({ ok: true });
    } catch {
      res.status(500).json({ error: "Erro" });
    }
  });
});

// ============================================================
//  IN-GAME ADMIN: BLOCK USER — POST /api/admin-game/block-user
// ============================================================
router.post("/admin-game/block-user", (req: Request, res: Response) => {
  gameAdminMiddleware(req, res, async () => {
    const username = (req.body?.username as string | undefined)?.trim();
    if (!username) { res.status(400).json({ error: "username obrigatório" }); return; }
    try {
      await pool.query(
        `INSERT INTO kaio_blocked (username, reason) VALUES ($1, 'Bloqueado pelo Admin')
         ON CONFLICT (username) DO UPDATE SET reason = 'Bloqueado pelo Admin', blocked_at = NOW()`,
        [username]
      );
      res.json({ ok: true });
    } catch {
      res.status(500).json({ error: "Erro" });
    }
  });
});

// ============================================================
//  KAIO MIDDLEWARE — valida via env var KAIO_KEY
// ============================================================
function kaioMiddleware(req: Request, res: Response, next: () => void) {
  if (req.headers["x-kaio-key"] !== KAIO_KEY) {
    res.status(401).json({ error: "Acesso negado" });
    return;
  }
  next();
}

// ============================================================
//  KAIO: ACTIVE USERS — GET /api/kaio/users
// ============================================================
router.get("/kaio/users", (req: Request, res: Response) => {
  kaioMiddleware(req, res, async () => {
    try {
      const r = await pool.query(
        `SELECT username, game_id, server_id, tier, key, updated_at
         FROM kaio_heartbeats
         WHERE updated_at > NOW() - INTERVAL '3 minutes'
         ORDER BY updated_at DESC`
      );
      res.json({ users: r.rows });
    } catch {
      res.status(500).json({ error: "Erro ao buscar usuários" });
    }
  });
});

// ============================================================
//  KAIO: SERVERS — GET /api/kaio/servers
// ============================================================
router.get("/kaio/servers", (req: Request, res: Response) => {
  kaioMiddleware(req, res, async () => {
    try {
      const r = await pool.query(
        `SELECT DISTINCT ON (server_id) server_id, game_id, username, tier, updated_at
         FROM kaio_heartbeats
         WHERE updated_at > NOW() - INTERVAL '3 minutes'
           AND server_id IS NOT NULL
         ORDER BY server_id, updated_at DESC`
      );
      res.json({ servers: r.rows });
    } catch {
      res.status(500).json({ error: "Erro ao buscar servidores" });
    }
  });
});

// ============================================================
//  KAIO: KICK USER — POST /api/kaio/kick
//  Body: { username }
// ============================================================
router.post("/kaio/kick", (req: Request, res: Response) => {
  kaioMiddleware(req, res, async () => {
    const username = (req.body?.username as string | undefined)?.trim();
    if (!username) {
      res.status(400).json({ error: "username é obrigatório" });
      return;
    }
    try {
      await pool.query(
        `INSERT INTO kaio_kick_queue (username) VALUES ($1)
         ON CONFLICT (username) DO UPDATE SET requested_at = NOW()`,
        [username]
      );
      res.json({ ok: true, username });
    } catch {
      res.status(500).json({ error: "Erro ao enfileirar kick" });
    }
  });
});

// ============================================================
//  KAIO: CHECK PENDING KICK — GET /api/kaio/pending-kick?username=...
//  Called by every client to check if they should be kicked
// ============================================================
router.get("/kaio/pending-kick", async (req: Request, res: Response) => {
  const username = (req.query["username"] as string | undefined)?.trim();
  if (!username) { res.json({ kick: false }); return; }
  try {
    const r = await pool.query(
      `DELETE FROM kaio_kick_queue WHERE username = $1 RETURNING username`,
      [username]
    );
    res.json({ kick: r.rowCount! > 0 });
  } catch {
    res.json({ kick: false });
  }
});

// ============================================================
//  KAIO: CREATE KEY — POST /api/kaio/create-key
//  Body: { tier, isPermanent?, durationHours?, customKey?, level? }
// ============================================================
router.post("/kaio/create-key", (req: Request, res: Response) => {
  kaioMiddleware(req, res, async () => {
    const tier = parseInt((req.body?.tier ?? "1") as string, 10);
    const level = (req.body?.level as string | undefined) ?? "standard";
    const isPermanent = req.body?.isPermanent === true || req.body?.isPermanent === "true";
    const customKey = (req.body?.customKey as string | undefined)?.trim();
    const TIER_NAMES: Record<number, string> = { 1: "Bronze", 2: "Prata", 3: "Ouro", 4: "Custom" };
    const tierName = TIER_NAMES[tier] ?? "Custom";
    let durationHours: number;
    if (req.body?.durationHours !== undefined && req.body?.durationHours !== "") {
      durationHours = parseFloat(req.body.durationHours as string);
    } else {
      durationHours = await getTierDurationHours(tier);
    }
    const key = customKey || generateKey();
    let expiresAt: Date | null = null;
    if (!isPermanent) {
      expiresAt = new Date(Date.now() + durationHours * 3600 * 1000);
    }
    try {
      await pool.query(
        `INSERT INTO kaio_keys (key, tier, tier_name, level, is_permanent, expires_at)
         VALUES ($1, $2, $3, $4, $5, $6)`,
        [key, tier, tierName, level, isPermanent, expiresAt]
      );
      res.json({ key, tier, tierName, level, isPermanent, expiresAt: expiresAt?.toISOString() ?? null });
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : "";
      if (msg.includes("unique") || msg.includes("duplicate")) {
        res.status(409).json({ error: "Key já existe" });
      } else {
        res.status(500).json({ error: "Erro ao criar key" });
      }
    }
  });
});

// ============================================================
//  KAIO: REVOKE KEY — DELETE /api/kaio/revoke-key/:key
// ============================================================
router.delete("/kaio/revoke-key/:key", (req: Request, res: Response) => {
  kaioMiddleware(req, res, async () => {
    const { key } = req.params;
    try {
      const r = await pool.query(`DELETE FROM kaio_keys WHERE key = $1 RETURNING key`, [key]);
      if (r.rowCount === 0) {
        res.status(404).json({ error: "Key não encontrada" });
        return;
      }
      res.json({ ok: true });
    } catch {
      res.status(500).json({ error: "Erro ao revogar key" });
    }
  });
});

// ============================================================
//  KAIO: LIST KEYS — GET /api/kaio/keys
// ============================================================
router.get("/kaio/keys", (req: Request, res: Response) => {
  kaioMiddleware(req, res, async () => {
    try {
      const r = await pool.query(
        `SELECT id, key, tier, tier_name, is_permanent, expires_at, hwid, created_at
         FROM kaio_keys
         WHERE tier < 99
         ORDER BY created_at DESC LIMIT 200`
      );
      res.json({ keys: r.rows });
    } catch {
      res.status(500).json({ error: "Erro ao listar keys" });
    }
  });
});

export default router;
