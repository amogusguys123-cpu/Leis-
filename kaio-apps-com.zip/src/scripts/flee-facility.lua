-- KAIO APPS | Facility Apps — Flee The Facility
-- Script v4.3 — CEO Edition

-- ============================================================
--  WINDUI — carregado pelo loader via GitHub e exportado via getgenv()
-- ============================================================
local WindUI = getgenv().WindUI
if not WindUI then error("[KAIO] WindUI não carregado. Rode via loader.lua!") end

-- ============================================================
--  API / HTTP
-- ============================================================
local SERVER_URL = "__SERVER_URL__"
local HttpService = game:GetService("HttpService")

local function kaioRequest(method, path, body, headers)
  local ok, res = pcall(function()
    local req = {
      Url     = SERVER_URL .. path,
      Method  = method,
      Headers = headers or {},
      Body    = body and HttpService:JSONEncode(body) or nil,
    }
    if syn and syn.request then return syn.request(req)
    elseif http and http.request then return http.request(req)
    elseif request then return request(req)
    else return nil end
  end)
  if ok and res then
    local rawBody = type(res) == "string" and res or (res.Body or "")
    return true, rawBody
  end
  return false, nil
end

local KAIO_HEADERS = {
  ["Content-Type"] = "application/json",
  ["x-kaio-key"]   = "__KAIO_KEY__",
}

local function kaioGET(path)
  return kaioRequest("GET", path, nil, KAIO_HEADERS)
end

local function kaioPOST(path, body, _headers)
  return kaioRequest("POST", path, body, KAIO_HEADERS)
end

local function kaioDELETE(path)
  return kaioRequest("DELETE", path, nil, KAIO_HEADERS)
end

-- Window criado aqui para garantir que nunca seja nil
local Window = WindUI:CreateWindow({
  Title       = "Facility Apps",
  SubTitle    = "KAIO APPS v4.1",
  TabWidth    = 160,
  Size        = UDim2.fromOffset(580, 460),
  Acrylic     = true,
  Theme       = "Dark",
  MinimizeKey = Enum.KeyCode.H,
})

-- ============================================================
--  KEY TIER (via PandaAuth)
--  1 = Bronze  | 2 = Prata | 3 = Ouro (Premium) | 99 = KAIO
-- ============================================================
local tier = getgenv().KeyTier or 1
local isKaio = (tier >= 99)

local TIER_NAMES = {
  [1]  = "Bronze",
  [2]  = "Prata",
  [3]  = "Ouro",
  [99] = "KAIO"
}

local TIER_REQUIRED = {
  [2] = "Prata ou superior",
  [3] = "Ouro (Premium)"
}

-- hasAccess: sempre retorna true para mostrar todas as seções na UI
local function hasAccess(_required)
  return true
end

-- canUse: verificação REAL de tier, usada dentro das callbacks
local function canUse(required)
  return tier >= required
end

local function lockNotify(requiredTier)
  if tier == 1 and requiredTier <= 2 then
    WindUI:Popup({
      Title   = "🔒 Upgrade necessário",
      Icon    = "lock",
      Content = "Esta função requer Licença Prata ou superior.\n\nDeseja ver os planos e fazer upgrade?",
      Buttons = {
        {
          Title    = "Ver Planos de Upgrade",
          Icon     = "external-link",
          Variant  = "Primary",
          Callback = function()
            pcall(function() setclipboard("__GETKEY_URL__") end)
            WindUI:Notify({ Title = "Link copiado!", Content = "Cole no navegador para ver planos.", Icon = "link", Duration = 5 })
          end
        },
        { Title = "Agora não", Icon = "x", Variant = "Secondary", Callback = function() end }
      }
    })
  else
    WindUI:Notify({
      Title    = "🔒 Acesso Bloqueado",
      Content  = "Esta função requer Licença " .. (TIER_REQUIRED[requiredTier] or tostring(requiredTier)) .. ". Faça upgrade!",
      Icon     = "lock",
      Duration = 4
    })
  end
end

-- ============================================================
--  GLOBAL STATE
-- ============================================================
getgenv().PlayerESP         = false
getgenv().ComputerESP       = false
getgenv().ExitESP           = false
getgenv().SlowBeast         = false
getgenv().BreakRope         = false
getgenv().ForceAbility      = false
getgenv().AntiSlow          = false
getgenv().HitAura           = false
getgenv().AutoTie           = false
getgenv().NeverFail         = false
getgenv().AutoEscape        = false
getgenv().AlertUse          = false
getgenv().AutoHide          = false
getgenv().AutoBeastHide     = false
getgenv().AutoCollect       = false
getgenv().AutoAction        = false
getgenv().AutoInteract      = false
getgenv().AIPredict         = false
getgenv().NuncaDePego       = false
getgenv().StalkerArmario    = false
getgenv().ESPFreezer        = false
getgenv().AILastDanger      = 0
getgenv().BeastHistory      = {}   -- histórico de posições da fera
getgenv().BeastAlert        = false
getgenv().AlertDistance     = 45
getgenv().Camera3D          = false
getgenv().CameraSpeed       = 20
getgenv().AntiSlowSurvivor  = false
getgenv().Fullbright        = false
getgenv().SpeedBoost        = false
getgenv().BeastSpeed        = 25
getgenv().TeleportSurvivor  = false
getgenv().AutoHack          = false
getgenv().Noclip            = false
getgenv().BeastCheck        = false
getgenv().BeastCheckDist    = 75
getgenv().DimGraphics       = false
getgenv().AgacharForce      = false
getgenv().WallHop           = false
getgenv().SejaFera          = false
getgenv().KaioTemplateName  = ""
getgenv().BeastRadar        = false
getgenv().FugaExpress       = false

-- ============================================================
--  MORSE ENCODING — para geração de códigos de template
-- ============================================================
local MORSE = {
  A=".-",  B="-...", C="-.-.", D="-..",  E=".",    F="..-.", G="--.",
  H="....",I="..",   J=".---", K="-.-",  L=".-..", M="--",   N="-.",
  O="---", P=".--.", Q="--.-", R=".-.",  S="...",  T="-",    U="..-",
  V="...-",W=".--",  X="-..-", Y="-.--", Z="--..",
  ["0"]="-----", ["1"]=".----", ["2"]="..---", ["3"]="...--", ["4"]="....-",
  ["5"]=".....", ["6"]="-....", ["7"]="--...", ["8"]="---..", ["9"]="----.",
  ["."]=".-.-.-", [","]="--..--", [":"]="---...", ["-"]="-....-",
  ["+"]=".-.-.", ["/"]="-..-.", ["="]="...-.-",
}

local function morseEncode(text)
  local parts = {}
  text = text:upper()
  for i = 1, #text do
    local c = text:sub(i, i)
    if MORSE[c] then
      table.insert(parts, MORSE[c])
    elseif c == " " then
      table.insert(parts, "/")
    end
  end
  return table.concat(parts, " ")
end

-- ============================================================
--  LOCALS
-- ============================================================
local Players              = game:GetService("Players")
local ReplicatedStorage    = game:GetService("ReplicatedStorage")
local ProximityPromptService = game:GetService("ProximityPromptService")

local eu = Players.LocalPlayer
local Settings = {
  Colors = {
    Survivor = Color3.fromRGB(16, 239, 0),
    Beast    = Color3.fromRGB(255, 0, 0),
    ExitDoor = Color3.fromRGB(255, 165, 0)
  },
  GetBeastEvent = function(parent, event, dski)
    for _, p in pairs(Players:GetPlayers()) do
      if not dski and p == eu then continue end
      local char = p.Character
      if char and char:FindFirstChild("BeastPowers") then
        local s1 = char:FindFirstChild(parent)
        if s1 then
          local ev = s1:FindFirstChild(event)
          if ev then return ev end
        end
      end
    end
  end
}

-- ============================================================
--  BACKGROUND FUNCTIONS
-- ============================================================

-- Auto-Action
local function StartAutoAction()
  task.spawn(function()
    while true do
      if getgenv().AutoAction then
        pcall(function()
          local char = eu.Character
          if not char then return end
          local root = char:FindFirstChild("HumanoidRootPart")
          if not root then return end
          for _, obj in pairs(workspace:GetDescendants()) do
            if obj:IsA("ProximityPrompt") and obj.Enabled then
              local part = obj.Parent
              if part and part:IsA("BasePart") and (root.Position - part.Position).Magnitude <= 20 then
                pcall(function()
                  obj:InputHoldBegin()
                  task.wait(0.15)
                  obj:InputHoldEnd()
                end)
              end
            end
            if obj:IsA("ClickDetector") then
              local part = obj.Parent
              if part and part:IsA("BasePart") and (root.Position - part.Position).Magnitude <= 20 then
                pcall(function() fireclickdetector(obj) end)
              end
            end
          end
        end)
      end
      task.wait(0.3)
    end
  end)
end

-- Beast Alert
local function StartBeastAlert()
  task.spawn(function()
    local lastNotify = 0
    while true do
      if getgenv().BeastAlert then
        pcall(function()
          local char = eu.Character
          if not char then return end
          if char:FindFirstChild("BeastPowers") then return end
          local myRoot = char:FindFirstChild("HumanoidRootPart")
          if not myRoot then return end
          for _, p in pairs(Players:GetPlayers()) do
            if p ~= eu and p.Character and p.Character:FindFirstChild("BeastPowers") then
              local beastRoot = p.Character:FindFirstChild("HumanoidRootPart")
              if beastRoot then
                local distance = (myRoot.Position - beastRoot.Position).Magnitude
                if distance < getgenv().AlertDistance and tick() - lastNotify > 10 then
                  WindUI:Notify({
                    Title   = "FERA POR PERTO!",
                    Content = "A Fera está a " .. math.floor(distance) .. " studs!",
                    Duration = 4,
                    Icon    = "skull"
                  })
                  lastNotify = tick()
                end
              end
            end
          end
        end)
      end
      task.wait(1)
    end
  end)
end

-- Auto Hide on Beast Nearby (Tier 3) — teleports to FARTHEST locker
local function StartAutoHideOnBeast()
  task.spawn(function()
    local lastHide = 0
    while true do
      task.wait(1)
      if not getgenv().AutoBeastHide then continue end
      pcall(function()
        local char = eu.Character
        if not char then return end
        if char:FindFirstChild("BeastPowers") then return end
        local myRoot = char:FindFirstChild("HumanoidRootPart")
        if not myRoot then return end

        -- Check if beast is nearby
        local beastNear = false
        for _, p in pairs(Players:GetPlayers()) do
          if p ~= eu and p.Character and p.Character:FindFirstChild("BeastPowers") then
            local br = p.Character:FindFirstChild("HumanoidRootPart")
            if br and (myRoot.Position - br.Position).Magnitude < getgenv().AlertDistance then
              beastNear = true
              break
            end
          end
        end

        if not beastNear then return end
        if tick() - lastHide < 8 then return end

        -- Find FARTHEST locker (opposite of the regular Hide button)
        local map = ReplicatedStorage.CurrentMap and ReplicatedStorage.CurrentMap.Value
        if not map then return end

        local lockers = {}
        for _, obj in pairs(map:GetDescendants()) do
          local n = obj.Name:lower()
          if (n == "locker" or n == "closet" or n:find("locker") or n:find("closet")) and obj:IsA("Model") then
            table.insert(lockers, obj)
          end
        end

        if #lockers == 0 then return end

        local farthest, farthestDist = nil, -math.huge
        for _, locker in pairs(lockers) do
          local pivot = locker:IsA("Model") and locker:GetPivot()
          if pivot then
            local d = (myRoot.Position - pivot.Position).Magnitude
            if d > farthestDist then
              farthestDist = d
              farthest = locker
            end
          end
        end

        if not farthest then return end

        -- Try ProximityPrompt first, then teleport directly
        for _, obj in pairs(farthest:GetDescendants()) do
          if obj:IsA("ProximityPrompt") and obj.Enabled then
            pcall(function()
              obj:InputHoldBegin()
              task.wait(0.15)
              obj:InputHoldEnd()
            end)
            break
          end
        end

        task.wait(0.1)
        myRoot.CFrame = farthest:GetPivot()
        lastHide = tick()

        WindUI:Notify({
          Title   = "🛡 Auto-Escondido!",
          Content = "Teleportado para o armário mais longe da Fera.",
          Icon    = "eye-off",
          Duration = 3
        })
      end)
    end
  end)
end

local function StartBeastCheck()
  task.spawn(function()
    local lastTP = 0
    while true do
      task.wait(0.4)
      if not getgenv().BeastCheck then continue end
      pcall(function()
        local char = eu.Character
        if not char then return end
        if char:FindFirstChild("BeastPowers") then return end
        local myRoot = char:FindFirstChild("HumanoidRootPart")
        if not myRoot then return end
        if tick() - lastTP < 15 then return end

        local beastPos = nil
        local closestBeastDist = math.huge
        for _, p in pairs(Players:GetPlayers()) do
          if p ~= eu and p.Character and p.Character:FindFirstChild("BeastPowers") then
            local br = p.Character:FindFirstChild("HumanoidRootPart")
            if br then
              local d = (myRoot.Position - br.Position).Magnitude
              if d < closestBeastDist then
                closestBeastDist = d
                beastPos = br.Position
              end
            end
          end
        end

        if not beastPos then return end
        local dist = getgenv().BeastCheckDist or 75
        if closestBeastDist > dist then return end

        -- Beast detected — find FARTHEST locker from the BEAST (not from the player)
        local map = ReplicatedStorage.CurrentMap and ReplicatedStorage.CurrentMap.Value
        if not map then return end

        local lockers = {}
        for _, obj in pairs(map:GetDescendants()) do
          local n = obj.Name:lower()
          if (n == "locker" or n == "closet" or n:find("locker") or n:find("closet")) and obj:IsA("Model") then
            table.insert(lockers, obj)
          end
        end
        if #lockers == 0 then return end

        -- Farthest from beast
        local farthest, farthestDist = nil, -math.huge
        for _, locker in pairs(lockers) do
          local pivot = locker:IsA("Model") and locker:GetPivot()
          if pivot then
            local d = (beastPos - pivot.Position).Magnitude
            if d > farthestDist then
              farthestDist = d
              farthest = locker
            end
          end
        end
        if not farthest then return end

        WindUI:Notify({
          Title   = "⚠️ Fera detectada!",
          Content = string.format("%.0f studs — teleportando ao abrigo mais seguro...", closestBeastDist),
          Icon    = "triangle-alert",
          Duration = 2
        })
        task.wait(0.8)

        for _, obj in pairs(farthest:GetDescendants()) do
          if obj:IsA("ProximityPrompt") and obj.Enabled then
            pcall(function()
              obj:InputHoldBegin()
              task.wait(0.12)
              obj:InputHoldEnd()
            end)
            break
          end
        end
        task.wait(0.05)
        myRoot.CFrame = farthest:GetPivot()
        lastTP = tick()

        WindUI:Notify({
          Title   = "✅ Verificação de Fera",
          Content = "Seguro! Você está no abrigo mais distante da Fera.",
          Icon    = "shield-check",
          Duration = 4
        })
      end)
    end
  end)
end

-- ============================================================
--  AUTO INTERAGIR (background loop)
--  Pressiona E automaticamente em portas, cápsulas, etc.
--  Exclui ComputerTable (essa é função do AutoHack)
-- ============================================================
local function StartAutoInteract()
  task.spawn(function()
    while true do
      task.wait(0.25)
      if not getgenv().AutoInteract then continue end
      pcall(function()
        local char = eu.Character
        if not char then return end
        -- Nunca ativa quando o jogador é a Fera
        if char:FindFirstChild("BeastPowers") then return end

        local root = char:FindFirstChild("HumanoidRootPart")
        if not root then return end

        for _, obj in pairs(workspace:GetDescendants()) do
          -- Ignora objetos dentro de ComputerTable (esses ficam pro AutoHack)
          local ancestor = obj:FindFirstAncestorOfClass("Model")
          if ancestor and ancestor.Name == "ComputerTable" then continue end

          if obj:IsA("ProximityPrompt") and obj.Enabled then
            local part = obj.Parent
            if part and part:IsA("BasePart") then
              local dist = (root.Position - part.Position).Magnitude
              if dist <= (obj.MaxActivationDistance or 10) + 2 then
                -- Teleporta para ficar dentro do raio se um pouco longe
                if dist > (obj.MaxActivationDistance or 10) then
                  root.CFrame = CFrame.new(part.Position) * CFrame.new(0, 0, -2)
                  task.wait(0.05)
                end
                pcall(function()
                  if fireproximityprompt then
                    fireproximityprompt(obj)
                  else
                    obj:InputHoldBegin()
                    task.wait(0.12)
                    obj:InputHoldEnd()
                  end
                end)
              end
            end
          end

          if obj:IsA("ClickDetector") then
            local part = obj.Parent
            if part and part:IsA("BasePart") then
              local dist = (root.Position - part.Position).Magnitude
              if dist <= (obj.MaxActivationDistance or 32) then
                pcall(function() fireclickdetector(obj) end)
              end
            end
          end
        end
      end)
    end
  end)
end

-- ============================================================
--  AUTO HACK (background loop)
-- ============================================================
local function StartAutoHack()
  task.spawn(function()
    while true do
      task.wait(0.2)
      if not getgenv().AutoHack then continue end
      pcall(function()
        local char = eu.Character
        if not char then return end
        -- Nunca ativa quando o jogador é a Fera
        if char:FindFirstChild("BeastPowers") then return end

        local root = char:FindFirstChild("HumanoidRootPart")
        if not root then return end

        local map = ReplicatedStorage.CurrentMap and ReplicatedStorage.CurrentMap.Value
        if not map then return end

        -- Encontra o PC não concluído mais próximo (ComputerTable)
        local closest, closestDist = nil, math.huge
        for _, pc in pairs(map:GetChildren()) do
          if pc.Name ~= "ComputerTable" then continue end
          -- Ignora PCs com highlight verde (já concluídos)
          local hl = pc:FindFirstChild("KaioHl")
          if hl and hl.FillColor == Color3.fromRGB(0, 220, 80) then continue end
          local pivot = pc:IsA("Model") and pc:GetPivot()
          if not pivot then continue end
          local d = (root.Position - pivot.Position).Magnitude
          if d < closestDist then
            closestDist = d
            closest = pc
          end
        end

        if not closest then return end

        local pivot = closest:GetPivot()

        -- Teleporta para dentro do raio de interação se estiver longe
        if closestDist > 5 then
          root.CFrame = pivot * CFrame.new(0, 0, -2.5)
          task.wait(0.1)
        end

        -- Tenta hackear: fireproximityprompt → InputHoldBegin/End → fireclickdetector
        for _, obj in pairs(closest:GetDescendants()) do
          if obj:IsA("ProximityPrompt") and obj.Enabled then
            -- Método 1: fireproximityprompt (mais eficaz, instantâneo)
            pcall(function()
              if fireproximityprompt then
                fireproximityprompt(obj)
              end
            end)
            -- Método 2: hold clássico como fallback
            pcall(function()
              obj:InputHoldBegin()
              task.wait(0.12)
              obj:InputHoldEnd()
            end)
          end
          if obj:IsA("ClickDetector") then
            pcall(function() fireclickdetector(obj) end)
          end
        end
      end)
    end
  end)
end

-- ============================================================
--  IA KAIO — Previsão de Fera + Alerta de PC (background)
-- ============================================================
local function StartAIPredict()
  task.spawn(function()
    local lastAPICall    = 0
    local lastLocalWarn  = 0
    local lastLeavePCWarn = 0

    while true do
      task.wait(0.5)
      if not getgenv().AIPredict then continue end
      pcall(function()
        local char = eu.Character
        if not char then return end
        if char:FindFirstChild("BeastPowers") then return end

        local myRoot = char:FindFirstChild("HumanoidRootPart")
        if not myRoot then return end

        -- ── 1. Rastreia posições da fera ─────────────────────
        local beastRoot = nil
        local beastDist = math.huge
        for _, p in pairs(Players:GetPlayers()) do
          if p ~= eu and p.Character and p.Character:FindFirstChild("BeastPowers") then
            local br = p.Character:FindFirstChild("HumanoidRootPart")
            if br then
              local d = (myRoot.Position - br.Position).Magnitude
              if d < beastDist then beastDist = d; beastRoot = br end
              local hist = getgenv().BeastHistory
              table.insert(hist, { x = br.Position.X, y = br.Position.Y, z = br.Position.Z, t = tick() })
              if #hist > 10 then table.remove(hist, 1) end
              getgenv().BeastHistory = hist
            end
          end
        end

        -- ── 2. Alerta LOCAL (distância atual + previsão) ──────
        local now = tick()
        local cooldownOk = now - lastLocalWarn > 8

        -- 2a. Fera JÁ está perto agora (passa do lado) — prioridade máxima
        if beastRoot and beastDist < 35 and cooldownOk then
          lastLocalWarn = now
          local lvl = beastDist < 15 and "⛔ FUJA!" or "⚠️ Fera perto!"
          WindUI:Notify({
            Title   = "🤖 " .. lvl,
            Content = string.format("%.0f studs — pare tudo!", beastDist),
            Icon    = "skull", Duration = 2
          })
          getgenv().AILastDanger = beastDist < 15 and 10 or 7
          return
        end

        -- 2b. Previsão de trajetória (fera VINDO aí em ~6s)
        local hist = getgenv().BeastHistory
        if #hist >= 2 and cooldownOk then
          local last2 = hist[#hist]
          local prev2 = hist[#hist - 1]
          local vx = last2.x - prev2.x
          local vz = last2.z - prev2.z
          local predX = last2.x + vx * 6
          local predZ = last2.z + vz * 6
          local predDist = math.sqrt((predX - myRoot.Position.X)^2 + (predZ - myRoot.Position.Z)^2)
          if predDist < 25 then
            lastLocalWarn = now
            local lvl = predDist < 12 and "⛔ FUJA!" or "⚠️ Fera vindo!"
            WindUI:Notify({
              Title   = "🤖 " .. lvl,
              Content = string.format("Prevista a %.0f studs em ~6s", predDist),
              Icon    = "brain", Duration = 2
            })
            getgenv().AILastDanger = predDist < 12 and 10 or 7
          end
        end

        -- ── 3. Gemini — só a cada 15s e só se fera detectada ─────
        if tick() - lastAPICall < 15 then return end
        if #getgenv().BeastHistory == 0 then return end
        lastAPICall = tick()

        local map = ReplicatedStorage.CurrentMap and ReplicatedStorage.CurrentMap.Value
        local pcsTotal, pcsDone, myPCHackers = 0, 0, 0
        if map then
          for _, pc in pairs(map:GetChildren()) do
            if pc.Name == "ComputerTable" then
              pcsTotal += 1
              local hl = pc:FindFirstChild("KaioHl")
              if hl and hl.FillColor == Color3.fromRGB(0,220,80) then pcsDone += 1 end
              local pivot = pc:IsA("Model") and pc:GetPivot()
              if pivot and (myRoot.Position - pivot.Position).Magnitude <= 8 then myPCHackers += 1 end
            end
          end
        end

        local beastPosArr = {}
        for _, bp in ipairs(getgenv().BeastHistory) do
          table.insert(beastPosArr, {x=bp.x,y=bp.y,z=bp.z})
        end

        local bodyData = HttpService:JSONEncode({
          beast_positions = beastPosArr,
          player_pos      = {x=myRoot.Position.X,y=myRoot.Position.Y,z=myRoot.Position.Z},
          pcs_total       = pcsTotal, pcs_done = pcsDone, my_pc_hackers = myPCHackers,
          is_frozen       = (char:FindFirstChild("Frozen") ~= nil),
          survivors_count = #Players:GetPlayers() - 1,
        })

        local ok, res = pcall(function()
          local req = { Url=SERVER_URL.."/ai/predict", Method="POST",
            Headers={["Content-Type"]="application/json",["x-kaio-key"]="__KAIO_KEY__"},
            Body=bodyData }
          if syn and syn.request then return syn.request(req)
          elseif http and http.request then return http.request(req)
          elseif request then return request(req) end
        end)

        if not ok or not res then return end
        local rawBody = type(res)=="string" and res or (res.Body or "")
        local ok2, data = pcall(function() return HttpService:JSONDecode(rawBody) end)
        if not ok2 or not data then return end

        local danger  = data.danger_level or 0
        local msg     = data.message or ""
        local leavePc = data.leave_pc == true
        local dword   = data.danger_word or "Safe"

        -- Notifica Gemini APENAS se perigo real (>= 5) e cooldown ok
        if danger >= 5 and msg ~= "" and tick() - lastLocalWarn > 12 then
          lastLocalWarn = tick()
          WindUI:Notify({
            Title   = "🤖 " .. dword,
            Content = msg,
            Icon    = danger >= 8 and "skull" or "triangle-alert",
            Duration = 2
          })
        end

        if leavePc and tick() - lastLeavePCWarn > 15 then
          lastLeavePCWarn = tick()
          WindUI:Notify({
            Title = "⚡ Saia do PC!", Content = "Fera chegando rápido!",
            Icon = "log-out", Duration = 2
          })
        end
      end)
    end
  end)
end

-- ============================================================
--  NUNCA DE PEGO — solta a corda no momento certo
--  Lógica: quando a fera fica <= 12 studs da cápsula onde
--  o player está sendo congelado, dispara o break-free prompt.
--  Cache de prompts a cada 5s para não varrer workspace todo frame.
-- ============================================================
local function StartNuncaDePego()
  task.spawn(function()
    local lastBreak  = 0
    local cachedPrompts = {}
    local cacheTime  = 0

    local function refreshCache(root)
      local now = tick()
      if now - cacheTime < 5 then return end
      cacheTime = now
      cachedPrompts = {}
      for _, obj in pairs(workspace:GetDescendants()) do
        if obj:IsA("ProximityPrompt") and obj.Enabled then
          local at = (obj.ActionText or ""):lower()
          local pn = (obj.Parent and obj.Parent.Name or ""):lower()
          if at:find("break") or at:find("free") or at:find("escape") or at:find("soltar")
            or pn:find("freeze") or pn:find("tube") or pn:find("frozen") or pn:find("rescue") then
            local part = obj.Parent
            if part and part:IsA("BasePart") then
              table.insert(cachedPrompts, {prompt=obj, part=part})
            end
          end
        end
      end
    end

    while true do
      task.wait(0.25)
      if not getgenv().NuncaDePego then continue end
      pcall(function()
        local char = eu.Character
        if not char then return end
        local hum = char:FindFirstChildOfClass("Humanoid")
        if hum and hum.Health <= 0 then return end

        -- Só age se estiver sendo congelado (FrozenTube ou Frozen no char)
        local inCapsule = char:FindFirstChild("FrozenTube") or char:FindFirstChild("Frozen")
          or char:FindFirstChild("IsFrozen")
        if not inCapsule then return end

        local root = char:FindFirstChild("HumanoidRootPart")
        if not root then return end

        -- Verifica se a fera está se aproximando da cápsula (momento crítico)
        local beastClose = false
        for _, p in pairs(Players:GetPlayers()) do
          if p ~= eu and p.Character and p.Character:FindFirstChild("BeastPowers") then
            local br = p.Character:FindFirstChild("HumanoidRootPart")
            if br and (root.Position - br.Position).Magnitude <= 14 then
              beastClose = true; break
            end
          end
        end

        -- Dispara apenas no momento crítico: fera chegando + cooldown de 1.2s
        if not beastClose then return end
        if tick() - lastBreak < 1.2 then return end
        lastBreak = tick()

        refreshCache(root)
        for _, entry in pairs(cachedPrompts) do
          local d = (root.Position - entry.part.Position).Magnitude
          if d <= 18 then
            pcall(function()
              if fireproximityprompt then fireproximityprompt(entry.prompt) end
              entry.prompt:InputHoldBegin()
              task.wait(0.06)
              entry.prompt:InputHoldEnd()
            end)
          end
        end
      end)
    end
  end)
end

-- ============================================================
--  STALKER ARMÁRIO — detecta power Stalker da fera e se esconde
--  Quando a fera ativa Stalker (invisibilidade/stalk), teleporta
--  para o armário mais próximo e volta quando Stalker encerra.
-- ============================================================
local function StartStalkerArmario()
  task.spawn(function()
    local savedPos   = nil
    local inLocker   = false
    local lastAction = 0

    local function getBeastStalking()
      for _, p in pairs(Players:GetPlayers()) do
        if p ~= eu and p.Character and p.Character:FindFirstChild("BeastPowers") then
          -- Detecta Stalker via CurrentPower ou transparência do personagem
          local powerVal = ReplicatedStorage:FindFirstChild("CurrentPower")
          if powerVal then
            local v = tostring(powerVal.Value or ""):lower()
            if v:find("stalk") or v:find("invisible") or v:find("invis") then
              return true
            end
          end
          -- Fallback: verifica transparência do personagem da fera
          local bChar = p.Character
          local transparentCount = 0
          for _, part in pairs(bChar:GetChildren()) do
            if part:IsA("BasePart") and part.Transparency > 0.7 then
              transparentCount += 1
            end
          end
          if transparentCount >= 3 then return true end
        end
      end
      return false
    end

    local function findNearestLocker(root)
      local map = ReplicatedStorage.CurrentMap and ReplicatedStorage.CurrentMap.Value
      if not map then return nil end
      local closest, closestDist = nil, math.huge
      for _, obj in pairs(map:GetDescendants()) do
        local n = obj.Name:lower()
        if (n:find("locker") or n:find("closet")) and obj:IsA("Model") then
          local pivot = obj:GetPivot()
          local d = (root.Position - pivot.Position).Magnitude
          if d < closestDist then closestDist = d; closest = obj end
        end
      end
      return closest
    end

    while true do
      task.wait(0.4)
      if not getgenv().StalkerArmario then
        -- Se estava no armário e desativou, volta
        if inLocker and savedPos then
          pcall(function()
            local root = eu.Character and eu.Character:FindFirstChild("HumanoidRootPart")
            if root then root.CFrame = savedPos end
          end)
          inLocker = false; savedPos = nil
        end
        continue
      end
      pcall(function()
        local char = eu.Character
        if not char or char:FindFirstChild("BeastPowers") then return end
        local root = char:FindFirstChild("HumanoidRootPart")
        if not root then return end

        local stalking = getBeastStalking()

        if stalking and not inLocker and tick() - lastAction > 3 then
          -- Fera ativou Stalker → vai pro armário mais perto
          local locker = findNearestLocker(root)
          if not locker then return end
          savedPos = root.CFrame
          lastAction = tick()
          -- Tenta ProximityPrompt do armário primeiro
          for _, obj in pairs(locker:GetDescendants()) do
            if obj:IsA("ProximityPrompt") and obj.Enabled then
              pcall(function() obj:InputHoldBegin(); task.wait(0.12); obj:InputHoldEnd() end)
              break
            end
          end
          task.wait(0.08)
          root.CFrame = locker:GetPivot()
          inLocker = true
          WindUI:Notify({
            Title = "🕵️ Stalker detectado!",
            Content = "Escondido no armário mais próximo.",
            Icon = "eye-off", Duration = 2
          })

        elseif not stalking and inLocker and savedPos then
          -- Stalker encerrou → volta pro lugar
          root.CFrame = savedPos
          savedPos = nil
          inLocker = false
          lastAction = tick()
          WindUI:Notify({
            Title = "✅ Stalker encerrou",
            Content = "Voltando à posição anterior.",
            Icon = "eye", Duration = 2
          })
        end
      end)
    end
  end)
end

-- ============================================================
--  ESP FREEZER — highlight nos congeladores do mapa
-- ============================================================
local function StartESPFreezer()
  task.spawn(function()
    local freezerHLs = {}
    while true do
      task.wait(1)
      if not getgenv().ESPFreezer then
        -- Remove highlights quando desativado
        for _, hl in pairs(freezerHLs) do pcall(function() hl:Destroy() end) end
        freezerHLs = {}
        task.wait(1)
        continue
      end
      pcall(function()
        local map = ReplicatedStorage.CurrentMap and ReplicatedStorage.CurrentMap.Value
        if not map then return end

        -- Limpa highlights de objetos removidos
        local active = {}
        for obj, hl in pairs(freezerHLs) do
          if hl and hl.Parent then
            active[obj] = hl
          end
        end
        freezerHLs = active

        -- Procura congeladores no mapa
        for _, obj in pairs(map:GetDescendants()) do
          if not obj:IsA("Model") then continue end
          local n = obj.Name:lower()
          if not (n:find("freeze") or n:find("frozen") or n:find("tube") or n:find("pod") or n:find("cell")) then continue end
          if freezerHLs[obj] then continue end

          -- Verifica se há sobrevivente dentro
          local hasSurvivor = false
          for _, p in pairs(Players:GetPlayers()) do
            if p ~= eu and p.Character then
              local pr = p.Character:FindFirstChild("HumanoidRootPart")
              local pivot = obj:GetPivot()
              if pr and (pr.Position - pivot.Position).Magnitude < 6 then
                hasSurvivor = true
                break
              end
            end
          end

          local hl = Instance.new("Highlight")
          hl.Name = "KaioFreezerHL"
          hl.FillTransparency = 0.35
          hl.OutlineTransparency = 0
          if hasSurvivor then
            hl.FillColor    = Color3.fromRGB(0, 120, 255)
            hl.OutlineColor = Color3.fromRGB(80, 180, 255)
          else
            hl.FillColor    = Color3.fromRGB(160, 220, 255)
            hl.OutlineColor = Color3.fromRGB(100, 160, 220)
          end
          hl.Adornee = obj
          hl.Parent  = obj
          freezerHLs[obj] = hl
        end
      end)
    end
  end)
end

-- ============================================================
--  CHAT ALERT SYSTEM
-- ============================================================
getgenv().ChatAlertActive = false

-- addChatAlertMsg: agora mostra WindUI:Notify em vez de chat box
local function addChatAlertMsg(prefix, _username, msg, _color)
  if not getgenv().ChatAlertActive then return end
  pcall(function()
    WindUI:Notify({
      Title   = "⚡ " .. prefix,
      Content = msg,
      Icon    = "zap",
      Duration = 6,
    })
  end)
end

-- StartChatAlertSystem foi removido: MIMI agora usa WindUI:Notify puro (sem janela)

-- ============================================================
--  PC PROGRESS ALERT
-- ============================================================
getgenv().PCAlertActive = false

-- HackBoost: reduz estimativa de tempo em 5% (toggle externo)
getgenv().HackBoostActive = false

local function StartPCAlert()
  task.spawn(function()
    -- hackTime estimate per number of hackers (seconds)
    -- Com HackBoost ativo, reduz 5% (jogadores mais eficientes)
    local function estimateHackTime(n)
      local base
      if n <= 0 then base = 60
      elseif n == 1 then base = 60
      elseif n == 2 then base = 40
      elseif n == 3 then base = 32
      else base = 28 end
      if getgenv().HackBoostActive then base = base * 0.95 end
      return base
    end

    local pcStartTimes  = {} -- [pc] = tick() quando começou a hackear
    local pcHackerCount = {} -- [pc] = qtd jogadores próximos
    local pcAlerted     = {} -- [pc] = já notificou
    local pcLastActive  = {} -- [pc] = último tick() com alguém presente (debounce)
    local pcDone        = {} -- [pc] = PC estimado como concluído

    local function getOrCreateHL(pc)
      local hl = pc:FindFirstChild("KaioHl")
      if not hl then
        hl = Instance.new("Highlight")
        hl.Name = "KaioHl"
        hl.FillTransparency = 0.4
        hl.OutlineTransparency = 0
        hl.Adornee = pc
        hl.Parent  = pc
      end
      return hl
    end

    while true do
      task.wait(0.5)
      if not getgenv().PCAlertActive then
        pcStartTimes  = {}
        pcHackerCount = {}
        pcAlerted     = {}
        pcLastActive  = {}
        pcDone        = {}
        task.wait(1)
        continue
      end
      pcall(function()
        local map = ReplicatedStorage.CurrentMap and ReplicatedStorage.CurrentMap.Value
        if not map then return end

        local myChar = eu.Character
        if not myChar then return end
        if myChar:FindFirstChild("BeastPowers") then return end

        for _, pc in ipairs(map:GetChildren()) do
          if pc.Name ~= "ComputerTable" then continue end
          local pivot = pc:IsA("Model") and pc:GetPivot()
          if not pivot then continue end

          -- Conta jogadores hackeando este PC (raio 8 studs)
          local count = 0
          for _, p in ipairs(Players:GetPlayers()) do
            local c = p.Character
            if not c then continue end
            if c:FindFirstChild("BeastPowers") then continue end
            local r = c:FindFirstChild("HumanoidRootPart")
            if not r then continue end
            if (r.Position - pivot.Position).Magnitude <= 8 then
              count = count + 1
            end
          end

          -- Se PC já marcado como concluído → só mostra verde, ignora resto
          if pcDone[pc] then
            pcall(function()
              local hl = pc:FindFirstChild("KaioHl")
              if hl then
                hl.FillColor    = Color3.fromRGB(0, 220, 80)
                hl.OutlineColor = Color3.fromRGB(0, 180, 50)
              end
            end)
            continue
          end

          if count > 0 then
            pcLastActive[pc] = tick()
            if not pcStartTimes[pc] then
              -- Retoma timer se ainda estava dentro do timeout de abandono (8s)
              pcStartTimes[pc]  = tick()
              pcHackerCount[pc] = count
              pcAlerted[pc]     = false
            else
              pcHackerCount[pc] = count
            end

            local total   = estimateHackTime(pcHackerCount[pc])
            local elapsed = tick() - pcStartTimes[pc]
            local remain  = total - elapsed

            -- PC concluído: elapsed ultrapassou estimativa
            if remain <= 0 then
              pcDone[pc] = true
              pcall(function()
                local hl = getOrCreateHL(pc)
                hl.FillColor    = Color3.fromRGB(0, 220, 80)
                hl.OutlineColor = Color3.fromRGB(0, 180, 50)
              end)
              WindUI:Notify({
                Title    = "✅ PC COMPLETO!",
                Content  = "Um PC foi hackeado! Chegue para o próximo.",
                Icon     = "check-circle",
                Duration = 5,
              })
              continue
            end

            -- Alerta quando ≤ 22s restantes
            if remain <= 22 and not pcAlerted[pc] then
              pcAlerted[pc] = true
              local secs = math.max(1, math.floor(remain))
              WindUI:Notify({
                Title    = "⚠ PC QUASE COMPLETO!",
                Content  = string.format("Chega rápido! ~%d segundo(s) restante(s).", secs),
                Icon     = "monitor",
                Duration = 6,
              })
              pcall(function()
                local hl = getOrCreateHL(pc)
                hl.FillColor    = Color3.fromRGB(255, 200, 0)
                hl.OutlineColor = Color3.fromRGB(255, 60, 60)
              end)
            end

          else
            -- Ninguém no PC agora
            local lastSeen = pcLastActive[pc]
            if lastSeen then
              local idle = tick() - lastSeen
              if idle > 8 then
                -- Abandonado por mais de 8s → reseta timer (não confunde com conclusão)
                pcall(function()
                  local hl = pc:FindFirstChild("KaioHl")
                  if hl then hl:Destroy() end
                end)
                pcStartTimes[pc]  = nil
                pcHackerCount[pc] = nil
                pcAlerted[pc]     = nil
                pcLastActive[pc]  = nil
              end
              -- Se saiu mas voltará em < 8s → timer continua intacto
            end
          end
        end
      end)
    end
  end)
end

-- ============================================================
--  KICK SELF-CHECK (runs for all users)
-- ============================================================
local function StartKickCheck()
  task.spawn(function()
    local myName = eu.Name
    while true do
      task.wait(30)
      pcall(function()
        local url = SERVER_URL .. "/kaio/pending-kick?username=" .. myName
        local ok, res = pcall(function() return game:HttpGet(url, true) end)
        if not ok or not res then return end
        local ok2, data = pcall(function()
          return HttpService:JSONDecode(res)
        end)
        if ok2 and data and type(data) == "table" and data.kick then
          eu:Kick("[KAIO] Você foi removido pelo administrador.")
        end
      end)
    end
  end)
end

-- ============================================================
--  VISUAL FERA — small beast HUD
-- ============================================================
getgenv().VisualFeraActive = false

local function StartVisualFera()
  pcall(function()
    if eu.PlayerGui:FindFirstChild("KaioVisualFera") then
      eu.PlayerGui.KaioVisualFera:Destroy()
    end

    local sg = Instance.new("ScreenGui")
    sg.Name = "KaioVisualFera"
    sg.ResetOnSpawn = false
    sg.DisplayOrder = 16
    sg.IgnoreGuiInset = true
    sg.Parent = eu.PlayerGui

    local frame = Instance.new("Frame", sg)
    frame.Size = UDim2.fromOffset(140, 36)
    frame.Position = UDim2.new(1, -148, 0, 80)
    frame.BackgroundColor3 = Color3.fromRGB(10, 10, 16)
    frame.BackgroundTransparency = 0.2
    frame.BorderSizePixel = 0
    Instance.new("UICorner", frame).CornerRadius = UDim.new(0, 6)
    local stroke = Instance.new("UIStroke", frame)
    stroke.Color = Color3.fromRGB(220, 60, 60)
    stroke.Thickness = 1.2

    local lbl = Instance.new("TextLabel", frame)
    lbl.Name = "FeraLabel"
    lbl.Size = UDim2.new(1, -6, 1, 0)
    lbl.Position = UDim2.new(0, 6, 0, 0)
    lbl.BackgroundTransparency = 1
    lbl.TextColor3 = Color3.fromRGB(255, 80, 80)
    lbl.TextSize = 11
    lbl.Font = Enum.Font.GothamBold
    lbl.TextXAlignment = Enum.TextXAlignment.Left
    lbl.Text = "🐺 Fera: --"

    local conn
    local _beastLastUpdate = 0
    conn = game:GetService("RunService").Heartbeat:Connect(function()
      if not getgenv().VisualFeraActive then
        pcall(function() sg:Destroy() end)
        conn:Disconnect()
        return
      end
      -- Throttle: atualiza no máximo 8 vezes por segundo (a cada 0.12s)
      local now = tick()
      if now - _beastLastUpdate < 0.12 then return end
      _beastLastUpdate = now
      pcall(function()
        local myChar = eu.Character
        local myRoot = myChar and myChar:FindFirstChild("HumanoidRootPart")
        if not myRoot then lbl.Text = "🐺 Fera: --" return end

        local beastName, beastDist = nil, math.huge
        for _, p in ipairs(Players:GetPlayers()) do
          if p == eu then continue end
          local c = p.Character
          if not c or not c:FindFirstChild("BeastPowers") then continue end
          local r = c:FindFirstChild("HumanoidRootPart")
          if not r then continue end
          local d = (myRoot.Position - r.Position).Magnitude
          if d < beastDist then beastDist = d beastName = p.Name end
        end

        if beastName then
          local col
          if beastDist < 30 then
            col = Color3.fromRGB(255, 60, 60)
          elseif beastDist < 70 then
            col = Color3.fromRGB(255, 165, 0)
          else
            col = Color3.fromRGB(120, 220, 120)
          end
          lbl.TextColor3 = col
          stroke.Color   = col
          lbl.Text = string.format("🐺 %s | %.0f", beastName, beastDist)
        else
          lbl.TextColor3 = Color3.fromRGB(100, 200, 100)
          stroke.Color   = Color3.fromRGB(100, 200, 100)
          lbl.Text = "🐺 Fera: fora"
        end
      end)
    end)
  end)
end

StartAutoAction()
StartAutoInteract()
StartBeastAlert()
StartAutoHideOnBeast()
StartBeastCheck()
StartKickCheck()
StartPCAlert()
StartAutoHack()
StartAIPredict()
StartNuncaDePego()
StartStalkerArmario()
StartESPFreezer()

-- ============================================================
--  TABS
-- ============================================================
local Tabs = {
  Roles   = Window:Section({ Title = "Roles", Icon = "user-lock", Opened = true }),
  Window:Divider(),
  Visuals = Window:Tab({ Title = "Visuals", Icon = "eye" }),
  Troll   = Window:Tab({ Title = "Troll", Icon = "laugh" }),
  Window:Divider(),
  Event   = Window:Tab({ Title = "Event", Icon = "gift" })
}

if isKaio then
  Window:Divider()
  Tabs.Kaio = Window:Tab({ Title = "⚡ KAIO", Icon = "shield" })
end

Window:Divider()
Tabs.Template = Window:Tab({ Title = "📋 Templates", Icon = "layers" })

Window:SelectTab(1)

-- ============================================================
--  ROLES > SURVIVOR
-- ============================================================
do
  local survivor = Tabs.Roles:Tab({ Title = "Survivor", Icon = "smile-plus" })

  -- Beast info
  local info = survivor:Section({ Title = "Beast", Icon = "gavel", Opened = true })
  local abco = info:Paragraph({ Title = "Ability and Cooldown Progress", Desc = "Loading..." })
  task.spawn(function()
    while true do
      local temp = Settings.GetBeastEvent("BeastPowers", "PowerProgressPercent", true)
      abco:SetDesc(string.format("Ability: %s | Progress: %s",
        (ReplicatedStorage.CurrentPower.Value or "Undefined"),
        (temp and temp.Value or "Undefined")
      ))
      task.wait(0.1)
    end
  end)
  info:Toggle({
    Title = "Alert Ability",
    Desc  = "Avisa quando a fera usa a habilidade",
    Value = false,
    Callback = function(state)
      getgenv().AlertUse = state
      if not state then return end
      local Gokka = loadstring(game:HttpGet("https://raw.githubusercontent.com/Moligrafi001/Triangulare/main/extra/Gokka.lua"))()
      local Alerts = {
        Seeker = "Beast is trying to blend in",
        Seer   = "Use the hide feature before beast finds you",
        Runner = "Beast is faster now, jump a window"
      }
      Gokka:Connect({
        Name   = "AbilityUsed",
        Parent = ReplicatedStorage.PowerActive,
        Signal = "Changed",
        Callback = function(value)
          if not getgenv().AlertUse or not value or eu.Character:FindFirstChild("BeastPowers") then return end
          local ability = ReplicatedStorage.CurrentPower.Value
          WindUI:Notify({
            Title    = "Beast activated ability!",
            Content  = string.format("Ability: %s | %s!", ability, Alerts[ability] or "Be careful"),
            Icon     = "triangle-alert",
            Duration = 5
          })
        end
      })
    end
  })

  survivor:Divider()

  -- Never Fail Hacking — TIER 1
  local undtc = survivor:Section({ Title = "Undetectable", Icon = "bell-off", Opened = true })
  undtc:Toggle({
    Title = "Never Fail Hacking",
    Desc  = "Nunca falha ao hackear computadores",
    Value = false,
    Callback = function(state)
      getgenv().NeverFail = state
      while getgenv().NeverFail do
        pcall(function()
          if not eu.Character:FindFirstChild("BeastPowers") then
            ReplicatedStorage.RemoteEvent:FireServer("SetPlayerMinigameResult", true)
          end
        end)
        task.wait(0.1)
      end
    end
  })

  survivor:Divider()

  -- ============================================================
  --  SALVAR PRESO — TIER 2
  -- ============================================================
  local saveSection = survivor:Section({ Title = "Salvar Preso", Icon = "user-check", Opened = true })
  saveSection:Paragraph({
    Title = "Como funciona",
    Desc  = "Auto Salvar Invisível: detecta cápsulas próximas e salva sem mostrar nada na tela. Teleport Salvar Voltar: vai até a cápsula, salva e volta ao seu lugar original."
  })

  -- Helper: encontrar cápsulas no mapa
  -- Retorna todos os pods (cápsulas) do mapa
  local function findCapsules()
    local map = ReplicatedStorage.CurrentMap and ReplicatedStorage.CurrentMap.Value
    if not map then return {} end
    local pods = {}
    local keywords = {"pod", "cage", "capsule", "capture", "prison", "cell", "freezetag", "cápsula", "preso"}
    for _, obj in ipairs(map:GetDescendants()) do
      if obj:IsA("Model") then
        local n = obj.Name:lower()
        for _, kw in ipairs(keywords) do
          if n:find(kw) then table.insert(pods, obj); break end
        end
      end
    end
    return pods
  end

  -- Retorna o pod que tem um sobrevivente PRESO mais próximo dele (≤ 8 studs)
  -- Prioriza salvar jogadores que estão realmente dentro da cápsula
  local function findOccupiedPod()
    local pods = findCapsules()
    if #pods == 0 then return nil end

    -- Coletar posições dos sobreviventes (não-fera, não eu)
    local survivors = {}
    for _, p in ipairs(Players:GetPlayers()) do
      if p == eu then continue end
      local c = p.Character
      if not c then continue end
      if c:FindFirstChild("BeastPowers") then continue end -- é a fera
      local hrp = c:FindFirstChild("HumanoidRootPart")
      if hrp then table.insert(survivors, hrp.Position) end
    end

    if #survivors == 0 then
      -- Fallback: retorna pod mais próximo de mim
      local myHRP = eu.Character and eu.Character:FindFirstChild("HumanoidRootPart")
      if not myHRP then return nil end
      local best, bestD = nil, math.huge
      for _, pod in ipairs(pods) do
        local ok, piv = pcall(function() return pod:GetPivot() end)
        if ok and piv then
          local d = (myHRP.Position - piv.Position).Magnitude
          if d < bestD then bestD = d; best = pod end
        end
      end
      return best
    end

    -- Encontrar pod mais próximo de qualquer sobrevivente (capturado)
    local best, bestD = nil, math.huge
    for _, pod in ipairs(pods) do
      local ok, piv = pcall(function() return pod:GetPivot() end)
      if not ok or not piv then continue end
      for _, sPos in ipairs(survivors) do
        local d = (sPos - piv.Position).Magnitude
        if d < 8 and d < bestD then bestD = d; best = pod end
      end
    end

    -- Nenhum sobrevivente dentro de 8 studs → fallback para o mais próximo
    if not best then
      local myHRP = eu.Character and eu.Character:FindFirstChild("HumanoidRootPart")
      if not myHRP then return nil end
      for _, pod in ipairs(pods) do
        local ok, piv = pcall(function() return pod:GetPivot() end)
        if ok and piv then
          local d = (myHRP.Position - piv.Position).Magnitude
          if d < bestD then bestD = d; best = pod end
        end
      end
    end

    return best
  end

  -- Helper: interagir com cápsula para salvar
  local function tryRescueAtPod(pod)
    for _, obj in ipairs(pod:GetDescendants()) do
      if obj:IsA("ProximityPrompt") and obj.Enabled then
        pcall(function() obj:InputHoldBegin(); task.wait(0.1); obj:InputHoldEnd() end)
      end
      if obj:IsA("ClickDetector") then
        pcall(function() fireclickdetector(obj) end)
      end
    end
  end

  if hasAccess(2) then
    saveSection:Toggle({
      Title = "Auto Salvar Invisível",
      Desc  = "Salva presos automaticamente quando estiver perto da cápsula — sem nenhuma notificação visível [🔒 Prata]",
      Value = false,
      Callback = function(state)
        if not canUse(2) then lockNotify(2); return end
        getgenv().AutoSaveInvis = state
        if state then
          task.spawn(function()
            while getgenv().AutoSaveInvis do
              pcall(function()
                local char = eu.Character
                if not char then return end
                local hrp = char:FindFirstChild("HumanoidRootPart")
                if not hrp or char:FindFirstChild("BeastPowers") then return end
                for _, pod in ipairs(findCapsules()) do
                  local ok, pivot = pcall(function() return pod:GetPivot() end)
                  if ok and pivot then
                    if (hrp.Position - pivot.Position).Magnitude < 12 then
                      tryRescueAtPod(pod)
                    end
                  end
                end
              end)
              task.wait(0.4)
            end
          end)
        end
      end
    })

    saveSection:Button({
      Title    = "Teleport → Salvar → Voltar",
      Desc     = "Vai até a cápsula mais próxima, salva o preso e retorna ao seu lugar original [🔒 Prata]",
      Icon     = "user-round-plus",
      Callback = function()
        if not canUse(2) then lockNotify(2); return end
        pcall(function()
          local char = eu.Character
          if not char then return end
          local hrp = char:FindFirstChild("HumanoidRootPart")
          if not hrp then return end
          if char:FindFirstChild("BeastPowers") then
            WindUI:Notify({ Title = "Você é a Fera!", Content = "Apenas sobreviventes podem salvar.", Icon = "x-circle", Duration = 3 })
            return
          end

          local savedCF = hrp.CFrame
          local closest = findOccupiedPod()
          if not closest then
            WindUI:Notify({ Title = "Sem cápsulas", Content = "Nenhuma cápsula com preso encontrada.", Icon = "info", Duration = 3 })
            return
          end

          WindUI:Notify({ Title = "Indo salvar...", Content = "Teleportando para o preso mais próximo.", Icon = "zap", Duration = 2 })
          pcall(function()
            hrp.CFrame = CFrame.new(closest:GetPivot().Position + Vector3.new(0, 3, 2))
          end)
          task.wait(0.15)

          for _ = 1, 15 do
            tryRescueAtPod(closest)
            task.wait(0.2)
          end

          task.wait(0.1)
          pcall(function() hrp.CFrame = savedCF end)
          WindUI:Notify({ Title = "✓ Voltou!", Content = "Retornou à posição anterior.", Icon = "rotate-ccw", Duration = 2 })
        end)
      end
    })
  else
    saveSection:Toggle({ Title = "🔒 Auto Salvar Invisível", Desc = "Requer Licença Prata", Value = false, Callback = function() lockNotify(2) end })
    saveSection:Button({ Title = "🔒 Teleport → Salvar → Voltar", Desc = "Requer Licença Prata", Icon = "lock", Callback = function() lockNotify(2) end })
  end

  survivor:Divider()

  -- Auto-Action — TIER 2 (locked for tier 1)
  local autoact = survivor:Section({ Title = "Auto-Action", Icon = "mouse-pointer-click", Opened = true })
  autoact:Toggle({
    Title = "Auto-Action (Tecla E)",
    Desc  = "Executa automaticamente interações: portas, PCs, resgates [🔒 Prata]",
    Value = false,
    Callback = function(state)
      if not canUse(2) then lockNotify(2); return end
      getgenv().AutoAction = state
    end
  })

  survivor:Divider()

  -- Auto Interagir — TIER 2
  local aint = survivor:Section({ Title = "Auto Interagir", Icon = "hand", Opened = true })
  aint:Toggle({
    Title = "Auto Interagir",
    Desc  = "Pressiona E automaticamente em portas, cápsulas e resgates. Não ativa em PCs (use Auto Hack) [🔒 Prata]",
    Value = false,
    Callback = function(state)
      if not canUse(2) then lockNotify(2); return end
      getgenv().AutoInteract = state
      if state then
        WindUI:Notify({
          Title   = "🖐 Auto Interagir ATIVO",
          Content = "Abre portas e salva sobreviventes automaticamente. Não ativa se for a Fera.",
          Icon    = "hand",
          Duration = 4
        })
      else
        WindUI:Notify({ Title = "Auto Interagir desativado", Content = "", Icon = "hand", Duration = 2 })
      end
    end
  })

  survivor:Divider()

  -- Hide — TIER 1 (manual button only)
  local HidAl = survivor:Section({ Title = "Hide", Icon = "eye-closed", Opened = true })
  HidAl:Button({
    Title    = "Hide",
    Desc     = "Teleporta para o armário mais próximo",
    Icon     = "eye-off",
    Callback = function()
      local map = ReplicatedStorage.CurrentMap.Value
      if not map then return end
      local r = eu.Character and eu.Character:FindFirstChild("HumanoidRootPart")
      if not r then return end
      local lockers = {}
      for _, obj in pairs(map:GetDescendants()) do
        local n = obj.Name:lower()
        if (n == "locker" or n == "closet" or n:find("locker") or n:find("closet")) and obj:IsA("Model") then
          table.insert(lockers, obj)
        end
      end
      if #lockers == 0 then
        for _, obj in pairs(map:GetChildren()) do
          local n = obj.Name:lower()
          if n == "locker" or n == "closet" then table.insert(lockers, obj) end
        end
      end
      if #lockers == 0 then
        WindUI:Notify({ Title = "Nenhum armário encontrado", Content = "Não foi possível localizar um armário.", Icon = "triangle-alert", Duration = 4 })
        return
      end
      local closest, closestDist = nil, math.huge
      for _, locker in pairs(lockers) do
        local pivot = locker:IsA("Model") and locker:GetPivot()
        if pivot then
          local d = (r.Position - pivot.Position).Magnitude
if d < closestDist then closestDist = d
          closest = locker end
        end
      end
      if not closest then return end
      for _, obj in pairs(closest:GetDescendants()) do
        if obj:IsA("ProximityPrompt") and obj.Enabled then
pcall(function() obj:InputHoldBegin()
          task.wait(0.15)
          obj:InputHoldEnd() end)
          break
        end
        if obj:IsA("ClickDetector") then
          pcall(function() fireclickdetector(obj) end)
          break
        end
      end
      task.wait(0.1)
      r.CFrame = closest:GetPivot()
      WindUI:Notify({ Title = "Escondido!", Content = "Teleportado para um armário.", Icon = "eye-off", Duration = 3 })
    end
  })

  survivor:Divider()

  -- Auto Hack — TIER 2 (locked for tier 1)
  local ahack = survivor:Section({ Title = "Auto Hack", Icon = "monitor", Opened = true })
  ahack:Toggle({
    Title = "Auto Hack",
    Desc  = "Hackeia os computadores automaticamente e abre as portas [🔒 Prata]",
    Value = false,
    Callback = function(state)
      if not canUse(2) then lockNotify(2); return end
      getgenv().AutoHack = state
      if state then
        WindUI:Notify({
          Title   = "⚡ Auto Hack ATIVO",
          Content = "Hackeando PCs automaticamente. Não ativa se você for a Fera.",
          Icon    = "monitor",
          Duration = 4
        })
      else
        WindUI:Notify({ Title = "Auto Hack desativado", Content = "", Icon = "monitor-off", Duration = 2 })
      end
    end
  })

  survivor:Divider()

  -- TP to Nearest Computer — TIER 1
  local tpComp = survivor:Section({ Title = "TP to Computer", Icon = "monitor", Opened = true })
  tpComp:Button({
    Title    = "Teleport to Nearest Computer",
    Desc     = "Teleporta instantaneamente para o PC mais próximo no mapa",
    Icon     = "locate",
    Callback = function()
      pcall(function()
        local char = eu.Character
        if not char or char:FindFirstChild("BeastPowers") then
          WindUI:Notify({ Title = "Você é a Fera!", Content = "Apenas para sobreviventes.", Icon = "triangle-alert", Duration = 2 })
          return
        end
        local root = char:FindFirstChild("HumanoidRootPart")
        if not root then return end
        local map = ReplicatedStorage.CurrentMap.Value
        if not map then return end
        local closest, closestDist = nil, math.huge
        for _, pc in pairs(map:GetChildren()) do
          if pc.Name == "ComputerTable" then
            local pivot = pc:IsA("Model") and pc:GetPivot()
            if pivot then
              local d = (root.Position - pivot.Position).Magnitude
if d < closestDist then closestDist = d
              closest = pivot end
            end
          end
        end
        if closest then
          root.CFrame = closest * CFrame.new(0, 0, -3)
          WindUI:Notify({ Title = "Teleportado!", Content = "Você está em frente ao computador.", Icon = "monitor", Duration = 2 })
        else
          WindUI:Notify({ Title = "Nenhum PC encontrado", Content = "Nenhum computador disponível no mapa.", Icon = "triangle-alert", Duration = 3 })
        end
      end)
    end
  })

  survivor:Divider()

  -- ⚡ Hack em Massa — TIER 3
  local hmassa = survivor:Section({ Title = "⚡ Hack em Massa", Icon = "zap", Opened = true })
  hmassa:Paragraph({
    Title  = "Hack em Massa",
    Desc   = "Dispara todos os eventos de hackear computadores simultaneamente. Extremamente OP — pode terminar a rodada em segundos!"
  })
  hmassa:Button({
    Title    = "⚡ Hackear Tudo Agora [🔒 Ouro]",
    Desc     = "Tenta completar todos os computadores de uma vez",
    Icon     = "zap",
    Callback = function()
      if not canUse(3) then lockNotify(3); return end
      pcall(function()
          local map = ReplicatedStorage.CurrentMap and ReplicatedStorage.CurrentMap.Value
          if not map then
            WindUI:Notify({ Title="Mapa não encontrado", Content="Tente durante uma partida ativa.", Icon="triangle-alert", Duration=3 })
            return
          end
          local count = 0
          for _, obj in pairs(map:GetDescendants()) do
            if obj:IsA("ProximityPrompt") and obj.Enabled then
              local pn = obj.Parent and obj.Parent.Name:lower() or ""
              local gpn = obj.Parent and obj.Parent.Parent and obj.Parent.Parent.Name:lower() or ""
              if pn:find("computer") or pn:find("terminal") or pn:find("hack") or gpn:find("computer") or gpn:find("terminal") then
                count += 1
                task.spawn(function()
                  pcall(function()
                    for _ = 1, 8 do
obj:InputHoldBegin()
                      task.wait(0.06)
                      obj:InputHoldEnd()
                      task.wait(0.02)
                    end
                  end)
                end)
              end
            end
          end
          WindUI:Notify({
            Title   = "⚡ Hack em Massa Ativado!",
            Content = count > 0 and ("Sinais enviados para " .. count .. " terminais!") or "Todos os sinais de hack foram disparados.",
            Icon    = "zap",
            Duration = 4
          })
        end)
      end
    })

  survivor:Divider()

  -- ✅ Verificação de Fera — TIER 1 (all tiers)
  local bchk = survivor:Section({ Title = "Verificação de Fera", Icon = "shield-check", Opened = true })
  bchk:Paragraph({
    Title = "Como funciona",
    Desc  = "Monitora distância da Fera. Quando ela entra no raio definido, teleporta você para o armário MAIS LONGE dela — com aviso antes de agir."
  })
  bchk:Slider({
    Title = "Raio de Detecção (studs)",
    Desc  = "Quanto mais alto, mais cedo o sistema reage. Padrão: 75",
    Step  = 5,
    Value = { Min = 40, Max = 130, Default = 75 },
    Callback = function(v) getgenv().BeastCheckDist = v end
  })
  bchk:Toggle({
    Title = "Verificação de Fera",
    Desc  = "Ativa sistema automático de fuga ao detectar a Fera",
    Value = false,
    Callback = function(state)
      getgenv().BeastCheck = state
      if state then
        WindUI:Notify({
          Title   = "Verificação de Fera ATIVA",
          Content = "Raio: " .. (getgenv().BeastCheckDist or 75) .. " studs. Fuja antes de ser pego!",
          Icon    = "shield-check",
          Duration = 4
        })
      else
        WindUI:Notify({ Title = "Verificação de Fera desativada", Content = "", Icon = "shield-off", Duration = 2 })
      end
    end
  })

  survivor:Divider()

  -- Ghost Mode — visível a todos [🔒 Ouro]
  local ghost = survivor:Section({ Title = "Ghost Mode [🔒 Ouro]", Icon = "ghost", Opened = true })
  ghost:Toggle({
    Title = "Ghost Mode (Noclip)",
    Desc  = "Atravessa paredes. Desative ao entrar em locais normais [🔒 Ouro]",
    Value = false,
    Callback = function(state)
      if not canUse(3) then lockNotify(3); return end
      getgenv().Noclip = state
        if state then
          task.spawn(function()
            local connection
            connection = game:GetService("RunService").Stepped:Connect(function()
if not getgenv().Noclip then connection:Disconnect()
              return end
              pcall(function()
                local char = eu.Character
                if not char then return end
                for _, part in pairs(char:GetDescendants()) do
                  if part:IsA("BasePart") and part.CanCollide then
                    part.CanCollide = false
                  end
                end
              end)
            end)
          end)
        else
          pcall(function()
            local char = eu.Character
            if char then
              for _, part in pairs(char:GetDescendants()) do
                if part:IsA("BasePart") then part.CanCollide = true end
              end
            end
          end)
        end
      end
  })
  survivor:Divider()

  -- Escape — TIER 2 (locked for tier 1)
  local escape = survivor:Section({ Title = "Escape", Icon = "door-open", Opened = true })
  local function Escape()
    if ReplicatedStorage.ComputersLeft.Value ~= 0 or eu.Character:FindFirstChild("BeastPowers") then return end
    local map = ReplicatedStorage.CurrentMap.Value
    if not map then return end
    local r, backup = eu.Character.HumanoidRootPart
    for _, door in pairs(map:GetChildren()) do
      if door.Name == "ExitDoor" and door:FindFirstChild("ExitArea") then
        backup, r.CFrame = r.CFrame, door.ExitArea.CFrame
        task.wait(0.1)
        r.CFrame = backup
      end
    end
  end

  escape:Button({ Title = "Escape [🔒 Prata]", Desc = "Escapes, basically", Icon = "log-out", Callback = function()
    if not canUse(2) then lockNotify(2); return end
    Escape()
  end })
  escape:Toggle({
    Title = "Auto Escape [🔒 Prata]",
    Desc  = "Automatically escapes",
    Value = false,
    Callback = function(state)
      if not canUse(2) then lockNotify(2); return end
      getgenv().AutoEscape = state
      while getgenv().AutoEscape do pcall(Escape)
        task.wait(3) end
    end
  })

  -- Fuga Express: monitora ComputersLeft e foge automaticamente assim que chega a 0
  escape:Toggle({
    Title = "🚀 Fuga Express [🔒 Prata]",
    Desc  = "Assim que o último PC for hackeado, foge pela saída automaticamente em <1s",
    Value = false,
    Callback = function(state)
      if not canUse(2) then lockNotify(2); return end
      getgenv().FugaExpress = state
      if state then
        task.spawn(function()
          local warned = false
          while getgenv().FugaExpress do
            pcall(function()
              local left = ReplicatedStorage.ComputersLeft
              if left and left.Value == 0 then
                if not warned then
                  warned = true
                  WindUI:Notify({ Title = "🚀 FUGA EXPRESS!", Content = "Todos os PCs hackados — fugindo agora!", Icon = "door-open", Duration = 3 })
                end
                Escape()
              else
                warned = false
              end
            end)
            task.wait(0.4)
          end
        end)
        WindUI:Notify({ Title = "Fuga Express ativa!", Content = "Vai escapar automaticamente quando o último PC for hackeado.", Icon = "zap", Duration = 4 })
      else
        WindUI:Notify({ Title = "Fuga Express desativada", Content = "", Icon = "circle-off", Duration = 2 })
      end
    end
  })

  survivor:Divider()

  -- Diminuir Gráfico — TIER 1 (otimização mobile)
  local dimGfx = survivor:Section({ Title = "Diminuir Gráfico", Icon = "settings", Opened = true })
  dimGfx:Paragraph({
    Title = "Para Celular",
    Desc  = "Reduz qualidade gráfica para o jogo rodar mais leve e sem travar no celular."
  })
  dimGfx:Toggle({
    Title = "Diminuir Gráfico",
    Desc  = "Remove efeitos pesados, partículas e sombras para ganhar FPS",
    Value = false,
    Callback = function(state)
      getgenv().DimGraphics = state
      pcall(function()
        local Light = game:GetService("Lighting")
        if state then
          Light.GlobalShadows = false
          Light.FogEnd   = 9e9
          Light.FogStart = 9e9
          for _, fx in ipairs(Light:GetChildren()) do
            if fx:IsA("BloomEffect") or fx:IsA("BlurEffect") or
               fx:IsA("SunRaysEffect") or fx:IsA("ColorCorrectionEffect") or
               fx:IsA("DepthOfFieldEffect") or fx:IsA("Atmosphere") then
              pcall(function() fx.Enabled = false end)
            end
          end
          pcall(function()
            settings().Rendering.QualityLevel = Enum.QualityLevel.Level01
          end)
          for _, obj in pairs(workspace:GetDescendants()) do
            if obj:IsA("ParticleEmitter") or obj:IsA("Trail") or
               obj:IsA("Sparkles") or obj:IsA("Fire") or obj:IsA("Smoke") then
              pcall(function() obj.Enabled = false end)
            end
          end
          WindUI:Notify({ Title = "Gráfico reduzido!", Content = "Efeitos desativados. Jogo deve rodar mais leve!", Icon = "settings", Duration = 3 })
        else
          Light.GlobalShadows = true
          for _, fx in ipairs(Light:GetChildren()) do
            pcall(function() fx.Enabled = true end)
          end
          pcall(function()
            settings().Rendering.QualityLevel = Enum.QualityLevel.Automatic
          end)
          WindUI:Notify({ Title = "Gráfico restaurado", Content = "Qualidade gráfica padrão restaurada.", Icon = "monitor", Duration = 2 })
        end
      end)
    end
  })

  survivor:Divider()

  -- Agachar Force — TIER 1
  local agachar = survivor:Section({ Title = "Agachar Force", Icon = "arrow-down-to-line", Opened = true })
  agachar:Paragraph({
    Title = "Como funciona",
    Desc  = "Remove o delay entre agachamentos. Clique várias vezes no botão de agachar sem esperar cooldown."
  })
  agachar:Toggle({
    Title = "Agachar Force",
    Desc  = "Agachamento sem delay — funciona no mobile e PC",
    Value = false,
    Callback = function(state)
      getgenv().AgacharForce = state
      if state then
        task.spawn(function()
          local UIS     = game:GetService("UserInputService")
          local CAS     = game:GetService("ContextActionService")
          local RS      = game:GetService("ReplicatedStorage")
          -- Cache de ProximityPrompts: evita GetDescendants a cada tick
          local _cachedPrompts = {}
          local _promptCacheTime = 0
          local function refreshPromptCache(map)
            local now = tick()
            if now - _promptCacheTime < 4 then return end
            _promptCacheTime = now
            _cachedPrompts = {}
            for _, obj in ipairs(map:GetDescendants()) do
              if obj:IsA("ProximityPrompt") then
                local pn = (obj.Parent and obj.Parent.Name or ""):lower()
                if pn:find("vent") or pn:find("duck") or pn:find("crawl") or pn:find("locker") then
                  table.insert(_cachedPrompts, obj)
                end
              end
            end
          end

          while getgenv().AgacharForce do
            pcall(function()
              local char = eu.Character
              if not char then return end
              local hum = char:FindFirstChild("Humanoid")
              if not hum then return end
              -- Muda estado uma vez por ciclo (não 2x), reduz replicação de rede
              pcall(function() hum:ChangeState(Enum.HumanoidStateType.Swimming) end)
              pcall(function() CAS:CallFunction("duck") end)
              -- Usa cache de ProximityPrompts (atualizado a cada 4s)
              local map = ReplicatedStorage.CurrentMap and ReplicatedStorage.CurrentMap.Value
              if map then
                refreshPromptCache(map)
                local root = char:FindFirstChild("HumanoidRootPart")
                if root then
                  for _, obj in ipairs(_cachedPrompts) do
                    pcall(function()
                      local pos = obj.Parent and obj.Parent:IsA("BasePart") and obj.Parent.Position
                      if pos and (root.Position - pos).Magnitude <= 5 then
                        obj:InputHoldBegin()
                      end
                    end)
                  end
                end
              end
            end)
            task.wait(0.15)
          end
        end)
        WindUI:Notify({ Title = "Agachar Force ATIVO!", Content = "Agachamento rápido sem delay. Clique sem parar!", Icon = "arrow-down-to-line", Duration = 3 })
      else
        WindUI:Notify({ Title = "Agachar Force desativado", Content = "", Icon = "circle-off", Duration = 2 })
      end
    end
  })

  survivor:Divider()

  -- ── IA KAIO — Previsão de Fera ─────────────────────────────
  local aiSec = survivor:Section({ Title = "🤖 IA KAIO", Icon = "brain", Opened = true })
  aiSec:Paragraph({
    Title = "Como funciona",
    Desc  = "Rastreia a Fera em tempo real, prevê os movimentos dela e avisa:\n• Se ela está vindo até você\n• Se você deve sair do PC antes de ser pego\n• Análise profunda via IA Gemini a cada 7s"
  })
  aiSec:Toggle({
    Title = "IA KAIO — Previsão de Fera",
    Desc  = "Monitora e prevê movimentos da Fera automaticamente [🔒 Prata]",
    Value = false,
    Callback = function(state)
      if not canUse(2) then lockNotify(2); return end
      getgenv().AIPredict = state
      getgenv().BeastHistory = {}
      if state then
        WindUI:Notify({
          Title   = "🤖 IA KAIO ATIVA",
          Content = "Monitorando Fera em tempo real. Análise via Gemini a cada 7s.",
          Icon    = "brain",
          Duration = 5
        })
      else
        WindUI:Notify({ Title = "IA KAIO desativada", Content = "", Icon = "brain", Duration = 2 })
      end
    end
  })

  survivor:Divider()

  -- ── NUNCA DE PEGO ───────────────────────────────────────────
  local ndpSec = survivor:Section({ Title = "🛡 Nunca de Pego", Icon = "shield-check", Opened = true })
  ndpSec:Paragraph({
    Title = "Como funciona",
    Desc  = "Quando você está numa cápsula e a fera se aproxima (<=14 studs), dispara o prompt de escape no momento exato — soltando a corda antes dela completar o congelamento."
  })
  ndpSec:Toggle({
    Title = "Nunca de Pego",
    Desc  = "Solta a corda no momento certo quando a fera se aproxima da cápsula [🔒 Prata]",
    Value = false,
    Callback = function(state)
      if not canUse(2) then lockNotify(2); return end
      getgenv().NuncaDePego = state
      if state then
        WindUI:Notify({ Title = "🛡 Nunca de Pego ATIVO", Content = "Aguardando cápsula...", Icon = "shield-check", Duration = 2 })
      else
        WindUI:Notify({ Title = "Nunca de Pego off", Content = "", Icon = "shield-off", Duration = 2 })
      end
    end
  })

  ndpSec:Toggle({
    Title = "🕵️ Stalker Armário",
    Desc  = "Quando a fera ativar o Stalker (invisibilidade), te esconde no armário mais perto e volta depois [🔒 Prata]",
    Value = false,
    Callback = function(state)
      if not canUse(2) then lockNotify(2); return end
      getgenv().StalkerArmario = state
      if state then
        WindUI:Notify({ Title = "🕵️ Stalker Armário ATIVO", Content = "Monitorando poder Stalker da fera.", Icon = "eye-off", Duration = 2 })
      else
        WindUI:Notify({ Title = "Stalker Armário off", Content = "", Icon = "eye", Duration = 2 })
      end
    end
  })

  survivor:Divider()

  -- ── ESP FREEZER ─────────────────────────────────────────────
  local espFrzSec = survivor:Section({ Title = "❄ ESP Freezer", Icon = "snowflake", Opened = true })
  espFrzSec:Paragraph({
    Title = "Como funciona",
    Desc  = "Destaca todos os congeladores no mapa:\n• Azul brilhante = sobrevivente dentro\n• Azul claro = congelador vazio\nÚtil pra saber quem salvar primeiro."
  })
  espFrzSec:Toggle({
    Title = "ESP Freezer",
    Desc  = "Mostra congeladores e sobreviventes congelados no mapa",
    Value = false,
    Callback = function(state)
      getgenv().ESPFreezer = state
      if state then
        WindUI:Notify({
          Title   = "❄ ESP Freezer ATIVO",
          Content = "Congeladores destacados. Azul brilhante = alguém dentro.",
          Icon    = "snowflake",
          Duration = 4
        })
      else
        WindUI:Notify({ Title = "ESP Freezer desativado", Content = "", Icon = "snowflake", Duration = 2 })
      end
    end
  })
end

-- ============================================================
--  ROLES > GLOBAL
-- ============================================================
do
  local global = Tabs.Roles:Tab({ Title = "Global", Icon = "globe" })

  -- Câmera 3D — TIER 2 (locked for tier 1)
  local cam3d = global:Section({ Title = "Câmera 3D (Drone View)", Icon = "video", Opened = true })
  cam3d:Paragraph({
    Title = "Como usar",
    Desc  = "Câmera livre flutuante. W/A/S/D movem a câmera, mouse rotaciona."
  })

  if hasAccess(2) then
    cam3d:Slider({
      Title = "Velocidade da Câmera",
      Desc  = "Quão rápido a câmera se move",
      Step  = 5,
      Value = { Min = 5, Max = 100, Default = 20 },
      Callback = function(value) getgenv().CameraSpeed = value end
    })
    cam3d:Toggle({
      Title = "Câmera 3D",
      Desc  = "Ativa/desativa câmera drone livre",
      Value = false,
      Callback = function(state)
        getgenv().Camera3D = state
        local UIS = game:GetService("UserInputService")
        local RS  = game:GetService("RunService")
        local cam = workspace.CurrentCamera
        local isMobile = UIS.TouchEnabled and not UIS.KeyboardEnabled
        if state then
          local char = eu.Character
          local humanoid = char and char:FindFirstChild("Humanoid")
          local origSpeed = humanoid and humanoid.WalkSpeed or 16
          local origJump  = humanoid and humanoid.JumpPower  or 50
          local origCamType = cam.CameraType
if humanoid then humanoid.WalkSpeed = 0
          humanoid.JumpPower = 0 end
          cam.CameraType = Enum.CameraType.Scriptable
          if not isMobile then UIS.MouseBehavior = Enum.MouseBehavior.LockCenter end
          local camPos = cam.CFrame.Position
          local yaw, pitch = 0, 0
          local mobileVelocity = Vector3.new(0, 0, 0)
          local savedCamTP = nil
          local camFrozen  = false

          -- Camera controls GUI (teleport + mobile up/down)
          local camGui = Instance.new("ScreenGui")
          camGui.Name = "Camera3DControls"
          camGui.ResetOnSpawn = false
          camGui.DisplayOrder = 20
          camGui.IgnoreGuiInset = true
          camGui.Parent = eu.PlayerGui

          -- Teleport button (bottom-center)
          local tpBtn = Instance.new("TextButton")
          tpBtn.Size = UDim2.fromOffset(210, 44)
          tpBtn.Position = UDim2.new(0.5, -105, 1, -72)
          tpBtn.BackgroundColor3 = Color3.fromRGB(108, 99, 255)
          tpBtn.BorderSizePixel = 0
          tpBtn.Text = "📍 Teleportar aqui"
          tpBtn.TextColor3 = Color3.fromRGB(255, 255, 255)
          tpBtn.Font = Enum.Font.GothamBold
          tpBtn.TextSize = 13
          tpBtn.ZIndex = 5
          tpBtn.Parent = camGui
          Instance.new("UICorner", tpBtn).CornerRadius = UDim.new(0, 10)

          -- Mobile up/down buttons (right side, mid-screen)
          local mobileUp, mobileDown = false, false
          if isMobile then
            local upBtn = Instance.new("TextButton")
            upBtn.Size = UDim2.fromOffset(58, 58)
            upBtn.Position = UDim2.new(1, -72, 0.5, -68)
            upBtn.BackgroundColor3 = Color3.fromRGB(40, 40, 65)
            upBtn.BorderSizePixel = 0
            upBtn.Text = "▲"
            upBtn.TextColor3 = Color3.fromRGB(210, 210, 240)
            upBtn.Font = Enum.Font.GothamBold
            upBtn.TextSize = 22
            upBtn.ZIndex = 5
            upBtn.Parent = camGui
            Instance.new("UICorner", upBtn).CornerRadius = UDim.new(0, 10)

            local downBtn = Instance.new("TextButton")
            downBtn.Size = UDim2.fromOffset(58, 58)
            downBtn.Position = UDim2.new(1, -72, 0.5, 10)
            downBtn.BackgroundColor3 = Color3.fromRGB(40, 40, 65)
            downBtn.BorderSizePixel = 0
            downBtn.Text = "▼"
            downBtn.TextColor3 = Color3.fromRGB(210, 210, 240)
            downBtn.Font = Enum.Font.GothamBold
            downBtn.TextSize = 22
            downBtn.ZIndex = 5
            downBtn.Parent = camGui
            Instance.new("UICorner", downBtn).CornerRadius = UDim.new(0, 10)

            upBtn.MouseButton1Down:Connect(function()   mobileUp   = true  end)
            upBtn.MouseButton1Up:Connect(function()     mobileUp   = false end)
            downBtn.MouseButton1Down:Connect(function() mobileDown = true  end)
            downBtn.MouseButton1Up:Connect(function()   mobileDown = false end)
          end

          -- Teleport button logic
          tpBtn.MouseButton1Click:Connect(function()
            if camFrozen then
              -- Voltar: retorna ao ponto original, volta para câmera
              camFrozen = false
              pcall(function()
                local c2 = eu.Character
                local r2 = c2 and c2:FindFirstChild("HumanoidRootPart")
                local h2 = c2 and c2:FindFirstChild("Humanoid")
                if r2 and savedCamTP then r2.CFrame = savedCamTP end
if h2 then h2.WalkSpeed = 0
                h2.JumpPower = 0 end
              end)
              cam.CameraType = Enum.CameraType.Scriptable
              if not isMobile then UIS.MouseBehavior = Enum.MouseBehavior.LockCenter end
              tpBtn.Text = "📍 Teleportar aqui"
              tpBtn.BackgroundColor3 = Color3.fromRGB(108, 99, 255)
            else
              -- Teleportar: salva posição, vai para onde a câmera está
              pcall(function()
                local c2 = eu.Character
                local r2 = c2 and c2:FindFirstChild("HumanoidRootPart")
                local h2 = c2 and c2:FindFirstChild("Humanoid")
                if not r2 then return end
                savedCamTP = r2.CFrame
                local rot2 = CFrame.Angles(0, math.rad(yaw), 0)
                r2.CFrame = CFrame.new(camPos) * rot2
if h2 then h2.WalkSpeed = origSpeed
                h2.JumpPower = origJump end
              end)
              camFrozen = true
              cam.CameraType = origCamType
              if not isMobile then UIS.MouseBehavior = Enum.MouseBehavior.Default end
              tpBtn.Text = "↩ Voltar para câmera"
              tpBtn.BackgroundColor3 = Color3.fromRGB(0, 145, 70)
            end
          end)

          local touchConns = {}
          if isMobile then
            local activeTouches = {}
            touchConns[1] = UIS.TouchStarted:Connect(function(touch, gpe)
              if gpe then return end
              local side = touch.Position.X < cam.ViewportSize.X / 2 and "move" or "look"
              activeTouches[touch] = { side = side, start = touch.Position, last = touch.Position }
            end)
            touchConns[2] = UIS.TouchMoved:Connect(function(touch, gpe)
              if gpe or not getgenv().Camera3D then return end
              local info = activeTouches[touch]
              if not info then return end
              local delta = touch.Position - info.last
              info.last = touch.Position
              if info.side == "look" then
                yaw = yaw - delta.X * 0.5
                pitch = math.clamp(pitch - delta.Y * 0.5, -80, 80)
              else
                local disp = touch.Position - info.start
                local maxRadius = 60
                if disp.Magnitude > maxRadius then disp = disp.Unit * maxRadius end
                local rot = CFrame.Angles(0, math.rad(yaw), 0)
                local dir = Vector3.new(disp.X / maxRadius, 0, disp.Y / maxRadius)
                mobileVelocity = rot:VectorToWorldSpace(dir)
              end
            end)
            touchConns[3] = UIS.TouchEnded:Connect(function(touch)
              local info = activeTouches[touch]
              if info and info.side == "move" then mobileVelocity = Vector3.new(0, 0, 0) end
              activeTouches[touch] = nil
            end)
          end

          local conn
          conn = RS.RenderStepped:Connect(function(dt)
            if not getgenv().Camera3D then
              cam.CameraType = origCamType
              if not isMobile then UIS.MouseBehavior = Enum.MouseBehavior.Default end
if humanoid then humanoid.WalkSpeed = origSpeed
              humanoid.JumpPower = origJump end
              for _, c in ipairs(touchConns) do pcall(function() c:Disconnect() end) end
              pcall(function() camGui:Destroy() end)
              conn:Disconnect()
              return
            end
            if camFrozen then return end  -- personagem no lugar da câmera, câmera pausa
            local spd = getgenv().CameraSpeed or 20
            if isMobile then
              if mobileVelocity.Magnitude > 0 then camPos = camPos + mobileVelocity * spd * dt end
              if mobileUp   then camPos = camPos + Vector3.new(0, spd * dt, 0) end
              if mobileDown then camPos = camPos - Vector3.new(0, spd * dt, 0) end
            else
              local md = UIS:GetMouseDelta()
              yaw = yaw - md.X * 0.5
              pitch = math.clamp(pitch - md.Y * 0.5, -80, 80)
              local rot = CFrame.Angles(0, math.rad(yaw), 0) * CFrame.Angles(math.rad(pitch), 0, 0)
              local move = Vector3.new(0, 0, 0)
              if UIS:IsKeyDown(Enum.KeyCode.W) then move += Vector3.new(0, 0, -1) end
              if UIS:IsKeyDown(Enum.KeyCode.S) then move += Vector3.new(0, 0,  1) end
              if UIS:IsKeyDown(Enum.KeyCode.A) then move += Vector3.new(-1, 0, 0) end
              if UIS:IsKeyDown(Enum.KeyCode.D) then move += Vector3.new( 1, 0, 0) end
              if UIS:IsKeyDown(Enum.KeyCode.E) then move += Vector3.new(0,  1, 0) end
              if UIS:IsKeyDown(Enum.KeyCode.Q) then move += Vector3.new(0, -1, 0) end
              if move.Magnitude > 0 then camPos = camPos + rot:VectorToWorldSpace(move.Unit) * spd * dt end
            end
            local rot = CFrame.Angles(0, math.rad(yaw), 0) * CFrame.Angles(math.rad(pitch), 0, 0)
            cam.CFrame = CFrame.new(camPos) * rot
          end)
          if isMobile then
            WindUI:Notify({ Title = "Câmera 3D ativada!", Content = "Esquerdo: mover | Direito: girar | ▲▼: subir/descer", Icon = "video", Duration = 5 })
          else
            WindUI:Notify({ Title = "Câmera 3D ativada!", Content = "W/A/S/D+Mouse | Q/E: altura | Botão: teleportar", Icon = "video", Duration = 5 })
          end
        else
          WindUI:Notify({ Title = "Câmera 3D desativada", Content = "Controle normal restaurado.", Icon = "video-off", Duration = 2 })
        end
      end
    })
  else
    cam3d:Toggle({ Title = "🔒 Câmera 3D", Desc = "Requer Licença Prata", Value = false, Callback = function() lockNotify(2) end })
  end

  global:Divider()

  -- Anti-Slowdown — TIER 2 (locked for tier 1)
  local antislow = global:Section({ Title = "Anti-Slowdown", Icon = "zap", Opened = true })
  antislow:Paragraph({
    Title = "Como funciona",
    Desc  = "Monitora WalkSpeed. Se cair abaixo de 16, restaura instantaneamente."
  })
  if hasAccess(2) then
    antislow:Toggle({
      Title = "Anti-Slowdown",
      Desc  = "Impede que sua velocidade caia abaixo de 16 studs/s",
      Value = false,
      Callback = function(state)
        getgenv().AntiSlowSurvivor = state
        if state then
          local conn
          local _antiSlowLast = 0
          conn = game:GetService("RunService").Heartbeat:Connect(function()
            if not getgenv().AntiSlowSurvivor then conn:Disconnect() return end
            -- Throttle: verifica apenas 10x por segundo
            local now = tick()
            if now - _antiSlowLast < 0.1 then return end
            _antiSlowLast = now
            pcall(function()
              local char = eu.Character
              if not char then return end
              local h = char:FindFirstChild("Humanoid")
              if h and h.WalkSpeed > 0 and h.WalkSpeed < 16 then h.WalkSpeed = 16 end
            end)
          end)
          WindUI:Notify({ Title = "Anti-Slowdown ativo!", Content = "Velocidade mínima mantida em 16.", Icon = "zap", Duration = 3 })
        else
          WindUI:Notify({ Title = "Anti-Slowdown desativado", Content = "", Icon = "circle-off", Duration = 2 })
        end
      end
    })
  else
    antislow:Toggle({ Title = "🔒 Anti-Slowdown", Desc = "Requer Licença Prata", Value = false, Callback = function() lockNotify(2) end })
  end

  global:Divider()

  -- Fullbright — TIER 1
  local fb = global:Section({ Title = "Fullbright", Icon = "sun", Opened = true })
  fb:Toggle({
    Title = "Fullbright",
    Desc  = "Remove escuridão total do mapa",
    Value = false,
    Callback = function(state)
      getgenv().Fullbright = state
      local Light = game:GetService("Lighting")
      if state then
        local function doFB()
          Light.Ambient = Color3.new(1, 1, 1)
          Light.ColorShift_Bottom = Color3.new(1, 1, 1)
          Light.ColorShift_Top = Color3.new(1, 1, 1)
        end
        doFB()
        Light.LightingChanged:Connect(function() if getgenv().Fullbright then doFB() end end)
        WindUI:Notify({ Title = "Fullbright ativo!", Content = "Iluminação máxima aplicada.", Icon = "sun", Duration = 2 })
      else
        Light.Ambient = Color3.new(0, 0, 0)
        Light.ColorShift_Bottom = Color3.new(0, 0, 0)
        Light.ColorShift_Top = Color3.new(0, 0, 0)
        WindUI:Notify({ Title = "Fullbright desativado", Content = "Iluminação padrão restaurada.", Icon = "moon", Duration = 2 })
      end
    end
  })

  global:Divider()

  -- Shift Lock — TIER 1
  local sl = global:Section({ Title = "Shift Lock", Icon = "lock", Opened = true })
  sl:Toggle({
    Title = "Shift Lock",
    Desc  = "Ativa bloqueio de câmera third-person",
    Value = false,
    Callback = function(state)
      if state then
        pcall(function()
          loadstring(game:HttpGet("https://raw.githubusercontent.com/MiniNoobie/ShiftLockx/main/Shiftlock-MiniNoobie", true))()
        end)
        WindUI:Notify({ Title = "Shift Lock ativado!", Content = "Câmera travada no personagem.", Icon = "lock", Duration = 2 })
      end
    end
  })

  global:Divider()

  -- Speed Boost Survivor — TIER 1
  getgenv().SurvivorSpeed = getgenv().SurvivorSpeed or 16
  getgenv().SurvivorSpeedActive = false
  local spdSurv = global:Section({ Title = "Speed Boost (Sobrevivente)", Icon = "rabbit", Opened = true })

  local speedPreview = spdSurv:Paragraph({
    Title = "Velocidade atual",
    Desc  = tostring(getgenv().SurvivorSpeed) .. " studs/s  |  mín: 16  ·  máx: 100"
  })

  spdSurv:Input({
    Title       = "Definir Velocidade",
    Desc        = "Aceita decimais (ex: 17.5). Pressione Enter para aplicar.",
    Placeholder = tostring(getgenv().SurvivorSpeed),
    Callback    = function(val)
      val = tostring(val or ""):match("^%s*(.-)%s*$")
      local n = tonumber(val)
      if n and n >= 16 and n <= 100 then
        getgenv().SurvivorSpeed = n
        pcall(function() speedPreview:SetDesc(tostring(n) .. " studs/s  |  mín: 16  ·  máx: 100") end)
        pcall(function()
          local char = eu.Character
          local h = char and char:FindFirstChild("Humanoid")
          if h and not char:FindFirstChild("BeastPowers") then h.WalkSpeed = n end
        end)
        WindUI:Notify({ Title = "✅ Velocidade: " .. tostring(n) .. " studs/s", Content = "", Icon = "rabbit", Duration = 2 })
      elseif val ~= "" then
        WindUI:Notify({ Title = "⚠️ Valor inválido", Content = "Use entre 16 e 100 (ex: 17.5)", Icon = "alert-triangle", Duration = 3 })
      end
    end
  })
  spdSurv:Toggle({
    Title = "Speed Boost",
    Desc  = "Mantém sua velocidade configurada continuamente",
    Value = false,
    Callback = function(state)
      getgenv().SurvivorSpeedActive = state
      if state then
        task.spawn(function()
          while getgenv().SurvivorSpeedActive do
            pcall(function()
              local char = eu.Character
              local h = char and char:FindFirstChild("Humanoid")
              if h and not char:FindFirstChild("BeastPowers") then
                h.WalkSpeed = getgenv().SurvivorSpeed or 16
              end
            end)
            task.wait(0.2)
          end
        end)
        WindUI:Notify({ Title = "Speed Boost ativo!", Content = "Velocidade fixada em " .. (getgenv().SurvivorSpeed or 16) .. " studs/s.", Icon = "rabbit", Duration = 3 })
      else
        pcall(function()
          local char = eu.Character
          local h = char and char:FindFirstChild("Humanoid")
          if h then h.WalkSpeed = 16 end
        end)
        WindUI:Notify({ Title = "Speed Boost desativado", Content = "Velocidade restaurada para 16.", Icon = "circle-off", Duration = 2 })
      end
    end
  })

  global:Divider()

  -- Infinite Jump — TIER 1
  getgenv().InfJump = false
  local infJump = global:Section({ Title = "Infinite Jump", Icon = "chevrons-up", Opened = true })
  infJump:Toggle({
    Title = "Infinite Jump",
    Desc  = "Permite pular infinitamente no ar (Espaço ou botão de pulo)",
    Value = false,
    Callback = function(state)
      getgenv().InfJump = state
      if state then
        local UIS = game:GetService("UserInputService")
        local conn
        conn = UIS.JumpRequest:Connect(function()
if not getgenv().InfJump then conn:Disconnect()
          return end
          pcall(function()
            local char = eu.Character
            local hum = char and char:FindFirstChild("Humanoid")
            if hum then hum:ChangeState(Enum.HumanoidStateType.Jumping) end
          end)
        end)
        WindUI:Notify({ Title = "Infinite Jump ativo!", Content = "Pressione pulo no ar para continuar pulando.", Icon = "chevrons-up", Duration = 3 })
      else
        WindUI:Notify({ Title = "Infinite Jump desativado", Content = "", Icon = "circle-off", Duration = 2 })
      end
    end
  })

  global:Divider()

  -- Anti-AFK — TIER 1
  getgenv().AntiAFK = false
  local antiAFK = global:Section({ Title = "Anti-AFK", Icon = "activity", Opened = true })
  antiAFK:Toggle({
    Title = "Anti-AFK",
    Desc  = "Impede que você seja kickado por inatividade",
    Value = false,
    Callback = function(state)
      getgenv().AntiAFK = state
      if state then
        local VU = game:GetService("VirtualUser")
        Players.LocalPlayer.Idled:Connect(function()
          if getgenv().AntiAFK then
            VU:Button2Down(Vector2.new(0, 0), workspace.CurrentCamera.CFrame)
            task.wait(1)
            VU:Button2Up(Vector2.new(0, 0), workspace.CurrentCamera.CFrame)
          end
        end)
        WindUI:Notify({ Title = "Anti-AFK ativo!", Content = "Você não será kickado por inatividade.", Icon = "activity", Duration = 3 })
      else
        WindUI:Notify({ Title = "Anti-AFK desativado", Content = "", Icon = "circle-off", Duration = 2 })
      end
    end
  })

  global:Divider()

  -- Modo Voo — TIER 3
  getgenv().FlyMode  = false
  getgenv().FlySpeed = 40
  local fly = global:Section({ Title = "Modo Voo", Icon = "plane", Opened = true })
  fly:Paragraph({ Title = "Como usar", Desc = "PC: W/A/S/D move a câmera | E/Q ou Space/Ctrl: subir/descer. Mobile: joystick + botões ▲▼." })
  if hasAccess(3) then
    fly:Slider({
      Title = "Velocidade de Voo",
      Desc  = "Velocidade ao voar (padrão: 40)",
      Step  = 5,
      Value = { Min = 10, Max = 120, Default = 40 },
      Callback = function(v) getgenv().FlySpeed = v end
    })
    fly:Toggle({
      Title = "Modo Voo",
      Desc  = "Voe pelo mapa sem restrições de gravidade",
      Value = false,
      Callback = function(state)
        getgenv().FlyMode = state
        if state then
          task.spawn(function()
            local UIS = game:GetService("UserInputService")
            local RS  = game:GetService("RunService")
            local char = eu.Character
            if not char then return end
            local hrp = char:FindFirstChild("HumanoidRootPart")
            local hum = char:FindFirstChild("Humanoid")
            if not hrp or not hum then return end
            hum.PlatformStand = true
            local bg = Instance.new("BodyGyro", hrp)
bg.MaxTorque = Vector3.new(4000, 4000, 4000)
            bg.D = 200
            bg.P = 80000
            local bv = Instance.new("BodyVelocity", hrp)
bv.MaxForce = Vector3.new(1e6, 1e6, 1e6)
            bv.Velocity = Vector3.new(0, 0, 0)
            local isMobile = UIS.TouchEnabled and not UIS.KeyboardEnabled
            local mUp, mDown = false, false
            local flyGui = nil
            if isMobile then
              flyGui = Instance.new("ScreenGui")
flyGui.Name = "FlyMobileControls"
              flyGui.ResetOnSpawn = false
flyGui.DisplayOrder = 18
              flyGui.IgnoreGuiInset = true
              flyGui.Parent = eu.PlayerGui
              local function mkFB(txt, py)
                local b = Instance.new("TextButton", flyGui)
b.Size=UDim2.fromOffset(56,56)
                b.Position=UDim2.new(0,14,0.5,py)
b.BackgroundColor3=Color3.fromRGB(40,40,65)
                b.BorderSizePixel=0
b.Text=txt
                b.Font=Enum.Font.GothamBold
                b.TextSize=22
b.TextColor3=Color3.fromRGB(200,200,240)
                b.ZIndex=6
                Instance.new("UICorner",b).CornerRadius=UDim.new(0,10)
                return b
              end
local ub=mkFB("▲",-66)
              local db=mkFB("▼",10)
              ub.MouseButton1Down:Connect(function() mUp=true end)
              ub.MouseButton1Up:Connect(function()   mUp=false end)
              db.MouseButton1Down:Connect(function() mDown=true end)
              db.MouseButton1Up:Connect(function()   mDown=false end)
            end
            local conn
            conn = RS.RenderStepped:Connect(function()
              if not getgenv().FlyMode then
pcall(function() bv:Destroy()
                bg:Destroy() end)
                hum.PlatformStand = false
                if flyGui then pcall(function() flyGui:Destroy() end) end
conn:Disconnect()
                return
              end
              local spd = getgenv().FlySpeed or 40
              local cam = workspace.CurrentCamera
              local move = Vector3.new(0,0,0)
              if isMobile then
                if mUp   then move += Vector3.new(0,1,0) end
                if mDown then move -= Vector3.new(0,1,0) end
              else
                if UIS:IsKeyDown(Enum.KeyCode.W)     then move += cam.CFrame.LookVector end
                if UIS:IsKeyDown(Enum.KeyCode.S)     then move -= cam.CFrame.LookVector end
                if UIS:IsKeyDown(Enum.KeyCode.A)     then move -= cam.CFrame.RightVector end
                if UIS:IsKeyDown(Enum.KeyCode.D)     then move += cam.CFrame.RightVector end
                if UIS:IsKeyDown(Enum.KeyCode.E) or UIS:IsKeyDown(Enum.KeyCode.Space) then move += Vector3.new(0,1,0) end
                if UIS:IsKeyDown(Enum.KeyCode.Q) or UIS:IsKeyDown(Enum.KeyCode.LeftControl) then move -= Vector3.new(0,1,0) end
              end
              if move.Magnitude > 0 then bv.Velocity = move.Unit * spd else bv.Velocity = Vector3.new(0,0,0) end
              bg.CFrame = CFrame.new(hrp.Position, hrp.Position + cam.CFrame.LookVector)
            end)
            WindUI:Notify({
              Title   = "✈ Modo Voo ATIVO!",
              Content = isMobile and "Use ▲▼ (esquerda) para altitude!" or "W/A/S/D+E/Q para voar!",
              Icon    = "plane", Duration = 4
            })
          end)
        else
          WindUI:Notify({ Title="Modo Voo desativado", Content="Gravidade restaurada.", Icon="circle-off", Duration=2 })
        end
      end
    })
  else
    fly:Toggle({ Title="🔒 Modo Voo", Desc="Requer Licença Ouro (Premium)", Value=false, Callback=function() lockNotify(3) end })
  end

  global:Divider()

  -- Wall Hop — TIER 3 (Ouro)
  local wh = global:Section({ Title = "Wall Hop", Icon = "chevrons-right", Opened = true })
  wh:Paragraph({
    Title = "Como funciona",
    Desc  = "Pule encostado numa parede para deslizar por ela. Ativa SOMENTE quando você está colado na parede e pula — sem bugs de câmera."
  })
  if hasAccess(3) then
    wh:Toggle({
      Title = "Wall Hop",
      Desc  = "Cole na parede e pule para deslizar",
      Value = false,
      Callback = function(state)
        getgenv().WallHop = state
        if not state then
          WindUI:Notify({ Title = "Wall Hop desativado", Content = "", Icon = "circle-off", Duration = 2 })
          return
        end

        local lastHop  = 0
        local stateConn

        local function hookHumanoid(char)
          local hum = char:WaitForChild("Humanoid", 5)
          if not hum then return end
          if stateConn then pcall(function() stateConn:Disconnect() end) end
          stateConn = hum.StateChanged:Connect(function(_, new)
            if new ~= Enum.HumanoidStateType.Jumping then return end
            if not getgenv().WallHop then
              pcall(function() stateConn:Disconnect() end)
              return
            end
            if tick() - lastHop < 0.25 then return end
            pcall(function()
              local hrp = char:FindFirstChild("HumanoidRootPart")
              if not hrp then return end

              local rp = RaycastParams.new()
              rp.FilterType = Enum.RaycastFilterType.Exclude
              rp.FilterDescendantsInstances = {char}

              local wallNormal = nil
              for _, dir in ipairs({
                hrp.CFrame.RightVector, -hrp.CFrame.RightVector,
                hrp.CFrame.LookVector,  -hrp.CFrame.LookVector
              }) do
                local hit = workspace:Raycast(hrp.Position, dir * 2.5, rp)
                if hit and hit.Instance then wallNormal = hit.Normal; break end
              end
              if not wallNormal then return end

              -- Direção de slide ao longo da parede
              local look  = hrp.CFrame.LookVector
              local slide = (look - look:Dot(wallNormal) * wallNormal)
              if slide.Magnitude < 0.01 then
                local r = hrp.CFrame.RightVector
                slide = r - r:Dot(wallNormal) * wallNormal
              end
              if slide.Magnitude < 0.01 then return end
              slide = slide.Unit

              lastHop = tick()
              local bv = Instance.new("BodyVelocity")
              bv.MaxForce = Vector3.new(9e4, 9e4, 9e4)
              bv.Velocity = slide * 32 + Vector3.new(0, 24, 0)
              bv.Parent   = hrp
              task.delay(0.25, function() pcall(function() bv:Destroy() end) end)
            end)
          end)
        end

        -- Conectar ao personagem atual
        if eu.Character then hookHumanoid(eu.Character) end
        eu.CharacterAdded:Connect(function(c)
          if getgenv().WallHop then hookHumanoid(c) end
        end)

        WindUI:Notify({ Title = "Wall Hop ATIVO!", Content = "Cole na parede e pule para deslizar.", Icon = "chevrons-right", Duration = 4 })
      end
    })
  else
    wh:Toggle({ Title = "🔒 Wall Hop", Desc = "Requer Licença Ouro (Premium)", Value = false, Callback = function() lockNotify(3) end })
  end

  global:Divider()

  -- ============================================================
  --  VISUAL FERA — small HUD (Global, All tiers)
  -- ============================================================
  local vf = global:Section({ Title = "Visual Fera", Icon = "radar", Opened = true })
  vf:Paragraph({
    Title = "O que é",
    Desc  = "Mini HUD discreto no canto superior direito da tela — mostra o nome e distância da Fera em tempo real. Fica verde (longe), laranja (médio) e vermelho (perto)."
  })
  vf:Toggle({
    Title = "Visual Fera",
    Desc  = "Mini indicador de distância da Fera (não afeta a jogabilidade)",
    Value = false,
    Callback = function(state)
      getgenv().VisualFeraActive = state
      if state then
        StartVisualFera()
        WindUI:Notify({ Title = "Visual Fera ativo!", Content = "Mini HUD ativado no canto da tela.", Icon = "radar", Duration = 2 })
      else
        pcall(function()
          if eu.PlayerGui:FindFirstChild("KaioVisualFera") then
            eu.PlayerGui.KaioVisualFera:Destroy()
          end
        end)
        WindUI:Notify({ Title = "Visual Fera desativado", Content = "", Icon = "circle-off", Duration = 2 })
      end
    end
  })

  global:Divider()

  -- ============================================================
  --  PC ALERT — notificações WindUI (sem janela fixa)
  -- ============================================================
  local ca = global:Section({ Title = "PC Alert", Icon = "monitor", Opened = true })
  ca:Paragraph({
    Title = "Como funciona",
    Desc  = "Avisa via notificação quando um PC está quase completo (~22s restantes). O PC também fica destacado em amarelo/vermelho no mapa."
  })
  ca:Toggle({
    Title = "Alerta de PC (Progress)",
    Desc  = "Notifica quando um PC está quase completo e destaca em amarelo. Fica VERDE quando concluído.",
    Value = false,
    Callback = function(state)
      getgenv().PCAlertActive = state
      getgenv().ChatAlertActive = state
      if state then
        WindUI:Notify({ Title = "PC Alert ativo!", Content = "Amarelo = quase pronto | Verde = concluído. Timer não reseta se alguém sair e voltar em <8s.", Icon = "monitor", Duration = 5 })
      else
        WindUI:Notify({ Title = "PC Alert desativado", Content = "", Icon = "circle-off", Duration = 2 })
      end
    end
  })
  -- HackBoost: reduz estimativa de tempo em 5%
  ca:Toggle({
    Title = "⚡ HackBoost (-5% tempo)",
    Desc  = "Considera que os hackers são 5% mais rápidos — alerta chega um pouco antes, dando mais tempo de chegar",
    Value = false,
    Callback = function(state)
      getgenv().HackBoostActive = state
      if state then
        WindUI:Notify({ Title = "HackBoost ATIVO!", Content = "Estimativa reduzida em 5%. Alerta antecipado para você chegar antes!", Icon = "zap", Duration = 3 })
      else
        WindUI:Notify({ Title = "HackBoost desativado", Content = "", Icon = "circle-off", Duration = 2 })
      end
    end
  })

  global:Divider()

  -- ── AUTO SKILL CHECK ──────────────────────────────────────
  -- Detecta o mini-game de Skill Check ao hackear e auto-completa.
  -- Flee the Facility: ao hackear surge um ring/círculo onde você
  -- clica no momento certo. Errar reduz 25% do progresso do PC.
  local scSection = global:Section({ Title = "Auto Skill Check", Icon = "target", Opened = true })
  scSection:Paragraph({
    Title = "Como funciona",
    Desc  = "Monitora sua PlayerGui. Quando o Skill Check aparecer durante o hack, auto-clica nos botões e ClickDetectors. Nunca perde progresso no PC."
  })
  getgenv().SkillCheckAuto = false
  scSection:Toggle({
    Title = "Auto Skill Check",
    Desc  = "Auto-completa o mini-game ao hackear. Combine com Auto Hack para resultado máximo [funciona solo também]",
    Value = false,
    Callback = function(state)
      getgenv().SkillCheckAuto = state
      if state then
        task.spawn(function()
          local pgui = eu:WaitForChild("PlayerGui")
          local knownGuis = {}
          for _, v in ipairs(pgui:GetChildren()) do knownGuis[v] = true end

          local conn
          conn = game:GetService("RunService").Heartbeat:Connect(function()
            if not getgenv().SkillCheckAuto then conn:Disconnect(); return end
            pcall(function()
              -- Método 1: detecta novas GUIs aparecendo (=skill check surgindo)
              for _, sg in ipairs(pgui:GetChildren()) do
                if not knownGuis[sg] then
                  knownGuis[sg] = true
                  task.spawn(function()
                    task.wait(0.025) -- deixa renderizar
                    -- Clica em todos os botões da nova GUI
                    for _, btn in ipairs(sg:GetDescendants()) do
                      if btn:IsA("ImageButton") or btn:IsA("TextButton") then
                        pcall(function() btn:TriggerClick() end)
                      end
                      if btn:IsA("ClickDetector") then
                        pcall(function() fireclickdetector(btn) end)
                      end
                    end
                  end)
                end
              end

              -- Método 2: dispara ClickDetectors no PC atual
              local map = ReplicatedStorage.CurrentMap and ReplicatedStorage.CurrentMap.Value
              if not map then return end
              local root = eu.Character and eu.Character:FindFirstChild("HumanoidRootPart")
              if not root then return end
              for _, pc in ipairs(map:GetChildren()) do
                if pc.Name ~= "ComputerTable" then continue end
                local pivot = pc:IsA("Model") and pc:GetPivot()
                if not pivot then continue end
                if (root.Position - pivot.Position).Magnitude <= 10 then
                  for _, obj in ipairs(pc:GetDescendants()) do
                    if obj:IsA("ClickDetector") then
                      pcall(function() fireclickdetector(obj) end)
                    end
                  end
                end
              end

              -- Método 3: procura skill check por nome em todas as GUIs
              local skillNames = {"skillcheck","skill_check","minigame","hackminigame","computermini","hackcheck"}
              for _, sg in ipairs(pgui:GetChildren()) do
                local n = sg.Name:lower()
                for _, kw in ipairs(skillNames) do
                  if n:find(kw) then
                    for _, btn in ipairs(sg:GetDescendants()) do
                      if btn:IsA("ImageButton") or btn:IsA("TextButton") then
                        pcall(function() btn:TriggerClick() end)
                      end
                      if btn:IsA("ClickDetector") then
                        pcall(function() fireclickdetector(btn) end)
                      end
                    end
                    break
                  end
                end
              end
            end)
          end)
        end)
        WindUI:Notify({ Title = "Auto Skill Check ATIVO!", Content = "Skill checks serão completados automaticamente. Combine com Auto Hack!", Icon = "target", Duration = 4 })
      else
        WindUI:Notify({ Title = "Auto Skill Check desativado", Content = "", Icon = "circle-off", Duration = 2 })
      end
    end
  })

  global:Divider()

  -- ── PC STATUS HUD ─────────────────────────────────────────
  -- HUD completo: PCs restantes, distância ao mais próximo,
  -- quem está sendo hackeado agora e status do Alert/SkillCheck.
  local hudSection = global:Section({ Title = "PC Status HUD", Icon = "layout-dashboard", Opened = true })
  hudSection:Paragraph({
    Title = "Como funciona",
    Desc  = "HUD no canto superior direito: mostra PCs restantes, distância ao PC mais próximo e quem está hackeando agora."
  })
  getgenv().PCHudActive = false
  local pcHudSg = nil
  hudSection:Toggle({
    Title = "PC Status HUD",
    Desc  = "Painel de estado dos PCs na tela (canto superior direito)",
    Value = false,
    Callback = function(state)
      getgenv().PCHudActive = state
      if state then
        pcall(function()
          if pcHudSg then pcHudSg:Destroy() end
          pcHudSg = Instance.new("ScreenGui")
          pcHudSg.Name = "KaioPCHud"
          pcHudSg.ResetOnSpawn = false
          pcHudSg.IgnoreGuiInset = true
          pcHudSg.DisplayOrder = 50
          pcHudSg.Parent = eu:WaitForChild("PlayerGui")

          local frame = Instance.new("Frame", pcHudSg)
          frame.Size = UDim2.fromOffset(190, 90)
          frame.Position = UDim2.new(1, -200, 0, 10)
          frame.BackgroundColor3 = Color3.fromRGB(8, 12, 18)
          frame.BackgroundTransparency = 0.12
          frame.BorderSizePixel = 0
          Instance.new("UICorner", frame).CornerRadius = UDim.new(0, 7)
          local stroke = Instance.new("UIStroke", frame)
          stroke.Color = Color3.fromRGB(229, 57, 53); stroke.Thickness = 1

          local function makeLbl(parent, size, pos, textSize, color)
            local l = Instance.new("TextLabel", parent)
            l.Size = size; l.Position = pos
            l.BackgroundTransparency = 1
            l.Font = Enum.Font.GothamBold
            l.TextSize = textSize
            l.TextColor3 = color
            l.TextXAlignment = Enum.TextXAlignment.Left
            return l
          end

          local titLbl = makeLbl(frame,
            UDim2.new(1,-8,0,16), UDim2.new(0,4,0,3),
            11, Color3.fromRGB(229,57,53))
          titLbl.Text = "⚡ KAIO — PC STATUS"

          local cntLbl = makeLbl(frame,
            UDim2.new(1,-8,0,15), UDim2.new(0,4,0,20),
            11, Color3.new(1,1,1))
          cntLbl.Text = "Restam: --"

          local distLbl = makeLbl(frame,
            UDim2.new(1,-8,0,15), UDim2.new(0,4,0,37),
            11, Color3.fromRGB(130,200,255))
          distLbl.Text = "PC mais próximo: --"

          local hackLbl = makeLbl(frame,
            UDim2.new(1,-8,0,15), UDim2.new(0,4,0,54),
            10, Color3.fromRGB(80,220,120))
          hackLbl.Text = "Hackeando: nenhum"

          local featLbl = makeLbl(frame,
            UDim2.new(1,-8,0,13), UDim2.new(0,4,0,72),
            9, Color3.fromRGB(160,160,160))
          featLbl.Text = ""

          task.spawn(function()
            while getgenv().PCHudActive and pcHudSg and pcHudSg.Parent do
              pcall(function()
                -- PCs restantes
                local cl = ReplicatedStorage:FindFirstChild("ComputersLeft")
                cntLbl.Text = "Restam: " .. (cl and tostring(cl.Value) or "?") .. " PC(s)"

                -- PC mais próximo + quem está hackeando
                local map = ReplicatedStorage.CurrentMap and ReplicatedStorage.CurrentMap.Value
                local root = eu.Character and eu.Character:FindFirstChild("HumanoidRootPart")
                if map and root then
                  local bestDist, bestHackers = math.huge, ""
                  for _, pc in ipairs(map:GetChildren()) do
                    if pc.Name ~= "ComputerTable" then continue end
                    local pivot = pc:IsA("Model") and pc:GetPivot()
                    if not pivot then continue end
                    local d = (root.Position - pivot.Position).Magnitude
                    if d < bestDist then bestDist = d end
                    -- Conta quem está hackeando este PC
                    local hackers = {}
                    for _, p in ipairs(Players:GetPlayers()) do
                      local c = p.Character
                      if not c or c:FindFirstChild("BeastPowers") then continue end
                      local r = c:FindFirstChild("HumanoidRootPart")
                      if r and (r.Position - pivot.Position).Magnitude <= 8 then
                        table.insert(hackers, p.Name)
                      end
                    end
                    if #hackers > 0 then
                      bestHackers = table.concat(hackers, ", ")
                    end
                  end
                  distLbl.Text = "PC mais próximo: " ..
                    (bestDist < math.huge and (math.floor(bestDist) .. " studs") or "--")
                  hackLbl.Text = "Hackeando: " .. (bestHackers ~= "" and bestHackers or "ninguém")
                end

                -- Status das features
                local feats = {}
                if getgenv().PCAlertActive    then table.insert(feats, "Alert") end
                if getgenv().HackBoostActive  then table.insert(feats, "Boost") end
                if getgenv().SkillCheckAuto   then table.insert(feats, "SC-Auto") end
                if getgenv().AutoHack         then table.insert(feats, "AutoHack") end
                featLbl.Text = #feats > 0 and ("▶ " .. table.concat(feats, " · ")) or "Recursos: OFF"
              end)
              task.wait(0.8)
            end
          end)
        end)
        WindUI:Notify({ Title = "PC HUD ativo!", Content = "Distância, PCs restantes e quem está hackeando — tudo no canto.", Icon = "layout-dashboard", Duration = 4 })
      else
        pcall(function() if pcHudSg then pcHudSg:Destroy(); pcHudSg = nil end end)
        WindUI:Notify({ Title = "PC HUD desativado", Content = "", Icon = "circle-off", Duration = 2 })
      end
    end
  })

  global:Divider()

  -- ── RADAR DE FERA ──────────────────────────────────────────
  local radarSec = global:Section({ Title = "🎯 Radar de Fera", Icon = "radar", Opened = true })
  radarSec:Paragraph({
    Title = "Como funciona",
    Desc  = "HUD circular no canto da tela: mostra direção + distância da Fera em tempo real.\n• Vermelho = próxima (<50 studs)\n• Laranja = média (50-150 studs)\n• Verde = longe (>150 studs)"
  })
  local _radarSg = nil
  radarSec:Toggle({
    Title = "🎯 Radar de Fera",
    Desc  = "Exibe direção e distância da Fera num mini-radar na tela",
    Value = false,
    Callback = function(state)
      getgenv().BeastRadar = state
      if state then
        pcall(function()
          if _radarSg then _radarSg:Destroy() end
          _radarSg = Instance.new("ScreenGui")
          _radarSg.Name           = "KaioRadar"
          _radarSg.ResetOnSpawn   = false
          _radarSg.IgnoreGuiInset = true
          _radarSg.DisplayOrder   = 55
          _radarSg.Parent = eu:WaitForChild("PlayerGui")

          local bg = Instance.new("Frame", _radarSg)
          bg.Size = UDim2.fromOffset(90, 90)
          bg.Position = UDim2.new(1, -106, 1, -106)
          bg.BackgroundColor3 = Color3.fromRGB(8, 12, 18)
          bg.BackgroundTransparency = 0.18
          bg.BorderSizePixel = 0
          Instance.new("UICorner", bg).CornerRadius = UDim.new(1, 0)
          local stroke = Instance.new("UIStroke", bg)
          stroke.Color = Color3.fromRGB(229, 57, 53); stroke.Thickness = 1.5

          local titL = Instance.new("TextLabel", bg)
          titL.Size = UDim2.new(1, 0, 0, 14); titL.Position = UDim2.fromOffset(0, 4)
          titL.BackgroundTransparency = 1
          titL.Font = Enum.Font.GothamBold; titL.TextSize = 9
          titL.TextColor3 = Color3.fromRGB(229, 57, 53)
          titL.Text = "⚡ FERA"; titL.TextXAlignment = Enum.TextXAlignment.Center

          local selfDot = Instance.new("Frame", bg)
          selfDot.Size = UDim2.fromOffset(6, 6)
          selfDot.AnchorPoint = Vector2.new(0.5, 0.5)
          selfDot.Position = UDim2.fromScale(0.5, 0.5)
          selfDot.BackgroundColor3 = Color3.fromRGB(80, 220, 120)
          selfDot.BorderSizePixel = 0
          Instance.new("UICorner", selfDot).CornerRadius = UDim.new(1, 0)

          local bDot = Instance.new("Frame", bg)
          bDot.Size = UDim2.fromOffset(10, 10)
          bDot.AnchorPoint = Vector2.new(0.5, 0.5)
          bDot.Position = UDim2.fromScale(0.5, 0.5)
          bDot.BackgroundColor3 = Color3.fromRGB(229, 57, 53)
          bDot.BorderSizePixel = 0
          bDot.Visible = false
          Instance.new("UICorner", bDot).CornerRadius = UDim.new(1, 0)

          local distL = Instance.new("TextLabel", bg)
          distL.Size = UDim2.new(1, 0, 0, 13); distL.Position = UDim2.new(0, 0, 1, -15)
          distL.BackgroundTransparency = 1
          distL.Font = Enum.Font.GothamBold; distL.TextSize = 9
          distL.TextColor3 = Color3.fromRGB(200, 200, 200)
          distL.Text = "--"; distL.TextXAlignment = Enum.TextXAlignment.Center

          task.spawn(function()
            while getgenv().BeastRadar and _radarSg and _radarSg.Parent do
              pcall(function()
                local myChar = eu.Character
                local myRoot = myChar and myChar:FindFirstChild("HumanoidRootPart")
                if not myRoot then bDot.Visible = false; return end
                local beastPos = nil
                for _, p in ipairs(Players:GetPlayers()) do
                  if p ~= eu and p.Character and p.Character:FindFirstChild("BeastPowers") then
                    local br = p.Character:FindFirstChild("HumanoidRootPart")
                    if br then beastPos = br.Position; break end
                  end
                end
                if beastPos then
                  local diff    = beastPos - myRoot.Position
                  local dist    = diff.Magnitude
                  local camYaw  = math.atan2(-workspace.CurrentCamera.CFrame.LookVector.X, -workspace.CurrentCamera.CFrame.LookVector.Z)
                  local angle   = math.atan2(diff.X, diff.Z) - camYaw
                  local scale   = math.min(dist / 250, 1)
                  bDot.Position = UDim2.fromScale(
                    math.clamp(0.5 + math.sin(angle)*scale*0.40, 0.09, 0.91),
                    math.clamp(0.5 - math.cos(angle)*scale*0.40, 0.09, 0.91))
                  bDot.Visible = true
                  distL.Text = math.floor(dist) .. "s"
                  if dist < 50 then
                    local c = Color3.fromRGB(229, 57, 53)
                    bDot.BackgroundColor3 = c; distL.TextColor3 = c
                  elseif dist < 150 then
                    local c = Color3.fromRGB(255, 160, 0)
                    bDot.BackgroundColor3 = c; distL.TextColor3 = c
                  else
                    local c = Color3.fromRGB(80, 220, 120)
                    bDot.BackgroundColor3 = c; distL.TextColor3 = c
                  end
                else
                  bDot.Visible = false
                  distL.Text = "--"; distL.TextColor3 = Color3.fromRGB(200, 200, 200)
                end
              end)
              task.wait(0.18)
            end
          end)
        end)
        WindUI:Notify({ Title = "🎯 Radar de Fera ativo!", Content = "Canto inferior direito: direção + distância da fera.", Icon = "radar", Duration = 4 })
      else
        pcall(function() if _radarSg then _radarSg:Destroy(); _radarSg = nil end end)
        WindUI:Notify({ Title = "Radar desativado", Content = "", Icon = "circle-off", Duration = 2 })
      end
    end
  })

  global:Divider()

  -- ── SEJA FERA ──────────────────────────────────────────────
  local sejaFeraSection = global:Section({ Title = "⚡ Seja Fera", Icon = "shield", Opened = true })
  sejaFeraSection:Paragraph({
    Title = "Como funciona",
    Desc  = "Teleporta imediatamente para um servidor aleatório e fica verificando a cada 60s se você é a Fera.\n'Iniciar/Parar' ativa ou desativa. 'Up' troca de servidor na hora."
  })

  -- Função loop interna (usada por auto-retoma e pelo botão)
  local function _sejaFeraLoop()
    task.spawn(function()
      task.wait(2)
      while getgenv().SejaFera do
        -- Verifica se já é Fera
        local char = eu.Character
        if char and char:FindFirstChild("BeastPowers") then
          getgenv().SejaFera = false
          WindUI:Notify({ Title = "🎉 VOCÊ É A FERA!", Content = "Seja Fera desativado. Boa sorte!", Icon = "shield", Duration = 10 })
          return
        end

        -- Conta 60 segundos, checando a cada 1s
        for _ = 1, 60 do
          if not getgenv().SejaFera then return end
          local c = eu.Character
          if c and c:FindFirstChild("BeastPowers") then
            getgenv().SejaFera = false
            WindUI:Notify({ Title = "🎉 VOCÊ É A FERA!", Content = "Seja Fera desativado. Boa sorte!", Icon = "shield", Duration = 10 })
            return
          end
          task.wait(1)
        end

        if not getgenv().SejaFera then return end
        WindUI:Notify({ Title = "🔄 Trocando servidor...", Content = "Não foi a Fera. Tentando próximo...", Icon = "refresh-cw", Duration = 3 })
        pcall(function() game:GetService("TeleportService"):Teleport(game.PlaceId, eu) end)
        task.wait(5)
      end
    end)
  end

  -- Botão principal: Iniciar / Parar
  sejaFeraSection:Button({
    Title    = "⚡ Iniciar / Parar Seja Fera",
    Desc     = "Clique para ativar — teleporta na hora e verifica a cada 60s. Clique novamente para parar.",
    Icon     = "shield",
    Callback = function()
      if getgenv().SejaFera then
        getgenv().SejaFera = false
        WindUI:Notify({ Title = "Seja Fera parado", Content = "", Icon = "circle-off", Duration = 2 })
      else
        getgenv().SejaFera = true
        WindUI:Notify({ Title = "⚡ Seja Fera ativado!", Content = "Teleportando agora e verificando a cada 60s...", Icon = "shield", Duration = 5 })
        pcall(function() game:GetService("TeleportService"):Teleport(game.PlaceId, eu) end)
        _sejaFeraLoop()
      end
    end
  })

  -- Botão Up: troca de servidor imediatamente
  sejaFeraSection:Button({
    Title    = "🔄 Up — Trocar Servidor Agora",
    Desc     = "Teleporta para um servidor aleatório do mesmo jogo imediatamente",
    Icon     = "refresh-cw",
    Callback = function()
      WindUI:Notify({ Title = "🔄 Trocando servidor...", Content = "Aguardando teleporte...", Icon = "refresh-cw", Duration = 3 })
      pcall(function() game:GetService("TeleportService"):Teleport(game.PlaceId, eu) end)
    end
  })

  -- Auto-retoma: se getgenv().SejaFera ainda estiver true ao recarregar
  if getgenv().SejaFera then
    task.delay(3, function()
      local char = eu.Character
      if char and char:FindFirstChild("BeastPowers") then
        getgenv().SejaFera = false
        WindUI:Notify({ Title = "🎉 VOCÊ É A FERA!", Content = "Seja Fera desativado automaticamente.", Icon = "shield", Duration = 10 })
      else
        WindUI:Notify({ Title = "⚡ Seja Fera retomado", Content = "Continuando busca por servidor...", Icon = "shield", Duration = 4 })
        _sejaFeraLoop()
      end
    end)
  end
end

-- ============================================================
--  ROLES > BEAST
-- ============================================================
do
  local beast = Tabs.Roles:Tab({ Title = "Beast", Icon = "gavel" })

  -- Hit Aura — TIER 3 ONLY
  if hasAccess(3) then
    local hitaura = beast:Section({ Title = "Hit Aura", Icon = "gavel", Opened = true })
    hitaura:Slider({
      Title = "Aura Range",
      Desc  = "Max range to hit survivors",
      Step  = 1,
      Value = { Min = 5, Max = 15, Default = 10 },
      Callback = function(value) end
    })
    hitaura:Toggle({
      Title = "Hit Aura",
      Callback = function(state) end
    })
    beast:Divider()
  end

  -- Auto Tie — TIER 3 ONLY
  if hasAccess(3) then
    local autotie = beast:Section({ Title = "Auto Tie", Icon = "link", Opened = true })
    autotie:Slider({
      Title = "Tie Range",
      Desc  = "Max range to tie survivors",
      Step  = 1,
      Value = { Min = 5, Max = 50, Default = 5 },
      Callback = function(value) end
    })
    autotie:Toggle({
      Title = "Auto Tie",
      Callback = function(state) end
    })
    beast:Divider()
  end

  -- Anti Slow — TIER 1
  local antislow = beast:Section({ Title = "Anti Slow", Icon = "fast-forward", Opened = true })
  antislow:Toggle({
    Title = "Anti Slow",
    Desc  = "Never gets slow after jumping",
    Callback = function(state)
      getgenv().AntiSlow = state
      while getgenv().AntiSlow do
        pcall(function()
          local char = eu.Character
          if not char:FindFirstChild("BeastPowers") then return end
          local humanoid = char:FindFirstChild("Humanoid")
          if not humanoid or humanoid:GetAttribute("AntiSlow") then return end
          humanoid:SetAttribute("AntiSlow", true)
          humanoid:GetPropertyChangedSignal("WalkSpeed"):Connect(function()
            if not getgenv().AntiSlow or not humanoid.Parent:FindFirstChild("BeastPowers") then return end
            if humanoid.WalkSpeed < 17 then humanoid.WalkSpeed = 17 end
          end)
        end)
        task.wait(1)
      end
    end
  })

  beast:Divider()

  -- Speed Boost — TIER 3 ONLY
  if hasAccess(3) then
    local spd = beast:Section({ Title = "Speed Boost", Icon = "zap", Opened = true })
    spd:Slider({
      Title = "Velocidade",
      Desc  = "WalkSpeed da fera (padrão: ~17)",
      Step  = 1,
      Value = { Min = 16, Max = 60, Default = 25 },
      Callback = function(value)
        getgenv().BeastSpeed = value
        pcall(function()
          local char = eu.Character
          if not char or not char:FindFirstChild("BeastPowers") then return end
          local h = char:FindFirstChild("Humanoid")
          if h then h.WalkSpeed = value end
        end)
      end
    })
    spd:Toggle({
      Title = "Speed Boost",
      Desc  = "Mantém a velocidade configurada enquanto for fera",
      Value = false,
      Callback = function(state)
        getgenv().SpeedBoost = state
        while getgenv().SpeedBoost do
          pcall(function()
            local char = eu.Character
            if not char or not char:FindFirstChild("BeastPowers") then return end
            local h = char:FindFirstChild("Humanoid")
            if h then h.WalkSpeed = getgenv().BeastSpeed end
          end)
          task.wait(0.2)
        end
      end
    })
    beast:Divider()
  end

  -- Teleport to Survivor — TIER 3 ONLY
  if hasAccess(3) then
    local tpSurv = beast:Section({ Title = "Teleport to Survivor", Icon = "crosshair", Opened = true })
    local function GetNearestSurvivor()
      local root = eu.Character and eu.Character:FindFirstChild("HumanoidRootPart")
      if not root then return nil end
      local closest, closestDist = nil, math.huge
      for _, p in pairs(Players:GetPlayers()) do
        if p ~= eu and p.Character and not p.Character:FindFirstChild("BeastPowers") then
          local pr = p.Character:FindFirstChild("HumanoidRootPart")
          if pr then
            local d = (root.Position - pr.Position).Magnitude
if d < closestDist then closestDist = d
            closest = pr end
          end
        end
      end
      return closest
    end
    tpSurv:Button({
      Title    = "Teleportar para Sobrevivente",
      Desc     = "Teleporta para o sobrevivente mais próximo",
      Icon     = "locate",
      Callback = function()
        pcall(function()
          local char = eu.Character
          if not char or not char:FindFirstChild("BeastPowers") then
            WindUI:Notify({ Title = "Você não é a Fera!", Content = "Apenas para quando você for a fera.", Icon = "triangle-alert", Duration = 3 })
            return
          end
          local target = GetNearestSurvivor()
          if target then
            local root = char:FindFirstChild("HumanoidRootPart")
            if root then root.CFrame = target.CFrame * CFrame.new(0, 0, 3) end
          end
        end)
      end
    })
    tpSurv:Toggle({
      Title = "Auto Teleport",
      Desc  = "Persegue sobreviventes automaticamente por teleporte",
      Value = false,
      Callback = function(state)
        getgenv().TeleportSurvivor = state
        while getgenv().TeleportSurvivor do
          pcall(function()
            local char = eu.Character
            if not char or not char:FindFirstChild("BeastPowers") then return end
            local target = GetNearestSurvivor()
            if target then
              local root = char:FindFirstChild("HumanoidRootPart")
              if root then root.CFrame = target.CFrame * CFrame.new(0, 0, 3) end
            end
          end)
          task.wait(2)
        end
      end
    })
  end

  -- ── ESP FREEZER (Beast) ─────────────────────────────────────
  beast:Divider()
  local beastFrzSec = beast:Section({ Title = "❄ ESP Freezer", Icon = "snowflake", Opened = true })
  beastFrzSec:Paragraph({
    Title = "Como funciona",
    Desc  = "Destaca congeladores no mapa:\n• Azul brilhante = sobrevivente dentro\n• Azul claro = vazio\nÚtil pra saber onde os sobreviventes congelados estão."
  })
  beastFrzSec:Toggle({
    Title = "ESP Freezer",
    Desc  = "Mostra congeladores e sobreviventes congelados",
    Value = false,
    Callback = function(state)
      getgenv().ESPFreezer = state
      if state then
        WindUI:Notify({ Title = "❄ ESP Freezer ATIVO", Content = "Congeladores destacados no mapa.", Icon = "snowflake", Duration = 4 })
      else
        WindUI:Notify({ Title = "ESP Freezer desativado", Content = "", Icon = "snowflake", Duration = 2 })
      end
    end
  })
end

-- ============================================================
--  VISUALS — TIER 1 (all)
-- ============================================================
do
  local Lib = loadstring(game:HttpGet("https://raw.githubusercontent.com/Moligrafi001/Triangulare/main/extra/lasp.lua"))()

  local esp = Tabs.Visuals:Section({ Title = "Extra Sensorial Experience", Icon = "scan-eye", Opened = true })

  esp:Toggle({
    Title = "Player ESP",
    Value = false,
    Callback = function(state)
      getgenv().PlayerESP = state
      local function Set(boolean)
        for _, p in pairs(Players:GetPlayers()) do
          if p ~= eu then
            local char = p.Character
            if char then
              if char:FindFirstChild("BeastPowers") then
                Lib:BasicESP({ Parent = char, Name = "Player", Highlight = { Enabled = boolean, Color = Settings.Colors.Beast } })
              else
                Lib:BasicESP({ Parent = char, Name = "Player", Highlight = { Enabled = boolean, Color = Settings.Colors.Survivor } })
              end
            end
          end
        end
      end
      if not state then return Set(false) end
while getgenv().PlayerESP do Set(true)
      task.wait(0.3) end
    end
  })
  esp:Colorpicker({ Title = "Survivor Color", Default = Settings.Colors.Survivor, Callback = function(c) Settings.Colors.Survivor = c end })
  esp:Colorpicker({ Title = "Beast Color",    Default = Settings.Colors.Beast,    Callback = function(c) Settings.Colors.Beast = c end })

  esp:Divider()

  esp:Toggle({
    Title = "Computer ESP",
    Value = false,
    Callback = function(state)
      getgenv().ComputerESP = state
      local function Set(boolean)
        local map = ReplicatedStorage.CurrentMap.Value
        if not map then return end
        for _, pc in pairs(map:GetChildren()) do
          if pc.Name == "ComputerTable" then
            local screen = pc:FindFirstChild("Screen")
            if screen then Lib:BasicESP({ Parent = pc, Name = "Computer", Highlight = { Enabled = boolean, Color = screen.Color } }) end
          end
        end
      end
      if not state then return Set(false) end
while getgenv().ComputerESP do Set(true)
      task.wait(0.3) end
    end
  })

  esp:Divider()

  esp:Toggle({
    Title = "Exit Door ESP",
    Desc  = "Destaca as portas de saída",
    Value = false,
    Callback = function(state)
      getgenv().ExitESP = state
      local function Set(boolean)
        local map = ReplicatedStorage.CurrentMap.Value
        if not map then return end
        for _, door in pairs(map:GetChildren()) do
          if door.Name == "ExitDoor" then
            Lib:BasicESP({ Parent = door, Name = "ExitDoor", Highlight = { Enabled = boolean, Color = Settings.Colors.ExitDoor } })
          end
        end
      end
      if not state then return Set(false) end
while getgenv().ExitESP do Set(true)
      task.wait(0.3) end
    end
  })
  esp:Colorpicker({ Title = "Exit Door Color", Default = Settings.Colors.ExitDoor, Callback = function(c) Settings.Colors.ExitDoor = c end })

  esp:Divider()

  local radar = Tabs.Visuals:Section({ Title = "Beast Alert", Icon = "radar", Opened = true })
  radar:Slider({
    Title = "Alert Distance",
    Desc  = "Distância (studs) para acionar o aviso",
    Step  = 5,
    Value = { Min = 10, Max = 150, Default = 45 },
    Callback = function(value) getgenv().AlertDistance = value end
  })
  radar:Toggle({
    Title = "Beast Alert",
    Desc  = "Avisa quando a Fera estiver perto",
    Value = false,
    Callback = function(state) getgenv().BeastAlert = state end
  })
end

-- ============================================================
--  TROLL — Beast Only (Troll Player removido)
-- ============================================================
do
  local GetBeastEvent = Settings.GetBeastEvent

  -- ── Section: Troll Beast ─────────────────────────────────
  local troll = Tabs.Troll:Section({ Title = "Troll Beast", Icon = "angry", Opened = true })

  -- Slow Beast — TIER 1 (button)
  local function SlowBeast()
    local event = GetBeastEvent("BeastPowers", "PowersEvent")
    if event then event:FireServer("Jumped") end
  end
  troll:Button({ Title = "Slow Beast", Desc = "Deixa a fera lenta (uma vez)", Icon = "snail", Callback = SlowBeast })

  -- Auto Slow — TIER 2 (locked for tier 1)
  if hasAccess(2) then
    troll:Toggle({
      Title = "Auto Slow",
      Desc  = "Deixa a fera lenta constantemente",
      Value = false,
      Callback = function(state)
        getgenv().SlowBeast = state
while getgenv().SlowBeast do pcall(SlowBeast)
        task.wait(0.05) end
      end
    })
  else
    troll:Toggle({ Title = "🔒 Auto Slow", Desc = "Requer Licença Prata", Value = false, Callback = function() lockNotify(2) end })
  end

  troll:Divider()

  -- Disable Rope — TIER 2 (locked for tier 1)
  local function DisableRope()
    local event = GetBeastEvent("Hammer", "HammerEvent")
    if event then event:FireServer("HammerClick", true) end
  end

  if hasAccess(2) then
    troll:Button({ Title = "Disable Rope", Icon = "unlink", Desc = "Desativa a corda da fera (uma vez)", Callback = DisableRope })
    troll:Toggle({
      Title = "Auto Disable",
      Desc  = "Desativa a corda constantemente",
      Value = false,
      Callback = function(state)
        getgenv().BreakRope = state
while getgenv().BreakRope do pcall(DisableRope)
        task.wait(0.05) end
      end
    })
  else
    troll:Button({ Title = "🔒 Disable Rope", Icon = "unlink", Desc = "Requer Licença Prata", Callback = function() lockNotify(2) end })
    troll:Toggle({ Title = "🔒 Auto Disable", Desc = "Requer Licença Prata", Value = false, Callback = function() lockNotify(2) end })
  end

  troll:Divider()

  -- Force Ability + Auto Force — TIER 3 ONLY (hidden for tier < 3)
  if hasAccess(3) then
    local function ForceAbility()
      local event = GetBeastEvent("BeastPowers", "PowersEvent")
      if event then event:FireServer("Input") end
      pcall(function()
        local remotes = ReplicatedStorage:FindFirstChild("Remotes")
        if remotes then
          local powerEvent = remotes:FindFirstChild("PowersEvent") or remotes:FindFirstChild("BeastEvent")
          if powerEvent then powerEvent:FireServer("Input") end
        end
      end)
    end
    troll:Button({ Title = "Force Ability", Icon = "zap", Desc = "Força a habilidade da fera (uma vez)", Callback = ForceAbility })
    troll:Toggle({
      Title = "Auto Force",
      Desc  = "Força a habilidade constantemente",
      Value = false,
      Callback = function(state)
        getgenv().ForceAbility = state
while getgenv().ForceAbility do pcall(ForceAbility)
        task.wait(1) end
      end
    })

    troll:Divider()

    -- ⚡ Captura em Área — super-OP beast function
    local captArea = troll:Section({ Title = "⚡ Captura em Área", Icon = "crosshair", Opened = true })
    captArea:Paragraph({
      Title  = "Captura em Área",
      Desc   = "Teleporta para cada sobrevivente próximo e dispara os eventos de captura. NÍVEL OP — equivalente ao Force Ability mas para captura!"
    })
    captArea:Slider({
      Title = "Raio de Captura (studs)",
      Desc  = "Distância máxima para tentar capturar sobreviventes",
      Step  = 5,
      Value = { Min = 10, Max = 80, Default = 35 },
      Callback = function(v) getgenv().CaptureRange = v end
    })
    captArea:Button({
      Title    = "⚡ Capturar Área",
      Desc     = "Tenta capturar todos os sobreviventes no raio",
      Icon     = "crosshair",
      Callback = function()
        pcall(function()
          local char = eu.Character
          if not char then return end
          local myRoot = char:FindFirstChild("HumanoidRootPart")
          if not myRoot then return end
          local range = getgenv().CaptureRange or 35
          local caught = 0
          for _, p in pairs(Players:GetPlayers()) do
            if p ~= eu and p.Character and not p.Character:FindFirstChild("BeastPowers") then
              local pr = p.Character:FindFirstChild("HumanoidRootPart")
              if pr and (myRoot.Position - pr.Position).Magnitude <= range then
                caught += 1
                task.spawn(function()
                  pcall(function()
                    -- Teleport beast to survivor
                    myRoot.CFrame = pr.CFrame * CFrame.new(0, 0, -2)
                    -- Fire catch/tie events
                    for _, obj in pairs(ReplicatedStorage:GetDescendants()) do
                      if obj:IsA("RemoteEvent") then
                        local n = obj.Name:lower()
                        if n:find("catch") or n:find("tie") or n:find("grab") or n:find("beast") or n:find("powers") then
                          pcall(function() obj:FireServer(p.Character) end)
                          pcall(function() obj:FireServer(p) end)
                        end
                      end
                    end
                    -- Touch-based catch attempt
                    local beastHit = char:FindFirstChild("HumanoidRootPart")
                    if beastHit then
                      pcall(function()
                        for _, part in pairs(p.Character:GetChildren()) do
                          if part:IsA("BasePart") then
                            firetouchinterest(beastHit, part, 0)
                            task.wait(0.05)
                            firetouchinterest(beastHit, part, 1)
                          end
                        end
                      end)
                    end
                  end)
                end)
              end
            end
          end
          WindUI:Notify({
            Title   = "⚡ Captura em Área!",
            Content = caught > 0 and ("Captura disparada em " .. caught .. " sobrevivente(s)!") or "Nenhum sobrevivente no raio.",
            Icon    = "crosshair",
            Duration = 4
          })
        end)
      end
    })
    troll:Divider()
  end

  -- ── Section: Auto Hide on Beast Nearby — TIER 3 ONLY ────
  if hasAccess(3) then
    Tabs.Troll:Divider()
    local autoHideSection = Tabs.Troll:Section({ Title = "Auto Hide na Fera", Icon = "shield", Opened = true })
    autoHideSection:Paragraph({
      Title = "Como funciona",
      Desc  = "Quando a fera chegar perto, você é teleportado automaticamente para o armário MAIS LONGE — dificulta ser encontrado."
    })
    autoHideSection:Slider({
      Title = "Distância de Trigger",
      Desc  = "Distância em studs para ativar o auto-hide",
      Step  = 5,
      Value = { Min = 15, Max = 80, Default = 45 },
      Callback = function(value) getgenv().AlertDistance = value end
    })
    autoHideSection:Toggle({
      Title = "Auto Hide na Fera",
      Desc  = "Esconde no armário mais longe quando a fera chegar perto",
      Value = false,
      Callback = function(state)
        getgenv().AutoBeastHide = state
        if state then
          WindUI:Notify({ Title = "Auto Hide ativado!", Content = "Será teleportado ao armário mais longe quando a fera chegar.", Icon = "shield", Duration = 4 })
        else
          WindUI:Notify({ Title = "Auto Hide desativado", Content = "", Icon = "circle-off", Duration = 2 })
        end
      end
    })
  end

end

-- ============================================================
--  EVENT
-- ============================================================
do
  local ShoCen = Tabs.Event:Section({ Title = "Shopping Center", Icon = "store", Opened = true })
  ShoCen:Paragraph({
    Title = "How to Use",
    Desc  = "When in the \"Shopping Center\" map click the button below or execute the specific action you need in the section below"
  })

  do
    local Steps = {
      ["1"] = function()
        fireclickdetector(workspace["Shopping Center by D4niel_Foxy"].Heels.ClickPart.ClickDetector)
      end,
      ["2"] = function()
        fireclickdetector(workspace["Shopping Center by D4niel_Foxy"].MirrorModel.MirrorFace.ClickDetector)
      end,
      ["3"] = function()
        local r = eu.Character.HumanoidRootPart
        local p = workspace["Shopping Center by D4niel_Foxy"].MirrorModel.TouchDetector
        firetouchinterest(r, p, 0)
        firetouchinterest(r, p, 1)
      end,
    }

    ShoCen:Button({
      Title    = "Finish All Steps",
      Desc     = "Finishes all steps, teleporting you to the event place.",
      Icon     = "shell",
      Callback = function()
        pcall(Steps["1"])
        pcall(Steps["2"])
        task.wait(3)
        pcall(Steps["3"])
      end
    })

    local step = "1"
    local specific = ShoCen:Section({ Title = "Specific Action", Icon = "crosshair", Opened = true })
    specific:Dropdown({
      Title  = "Selected Action",
      Desc   = "Selects a specific action",
      Values = {
        { Title = "Collect Heels [ 1 / 3 ]",  Desc = "Collects the heels from the stand",     Icon = "footprints"    },
        { Title = "Activate Mirror [ 2 / 3 ]", Desc = "Activates the portal so you can enter", Icon = "mouse-pointer" },
        { Title = "Enter Mirror [ 3 / 3 ]",    Desc = "Teleports you to the event place",       Icon = "log-in"        }
      },
      Value    = "Collect Heels [ 1 / 3 ]",
      Callback = function(option)
        step = option.Title:match("%d+")
      end
    })
    specific:Button({
      Title    = "Execute Action",
      Desc     = "Executes the step selected above",
      Icon     = "play",
      Callback = function()
        local action = Steps[step]
        if action then action() end
      end
    })
  end
end

Tabs.Event:Divider()

local Forest = Tabs.Event:Section({ Title = "Event Place", Icon = "calendar", Opened = true })
Forest:Button({
  Title    = "Mountain Climber",
  Desc     = "Step 1",
  Callback = function()
    local r = eu.Character.HumanoidRootPart
    local p = workspace.GameplaySections.Task1.Complete
firetouchinterest(r, p, 0)
    firetouchinterest(r, p, 1)
    r.CFrame = p.CFrame
  end
})
Forest:Toggle({
  Title = "Hiker Hunter",
  Desc  = "Step 2 (hit the npcs first)",
  Value = false,
  Callback = function(state)
    getgenv().AutoCollect = state
    while getgenv().AutoCollect do
      pcall(function()
        for _, npc in next, workspace:GetChildren() do
          pcall(function()
            local r = npc:FindFirstChild("HumanoidRootPart")
            if not r then return end
            local pp = r:FindFirstChild("HikerProximityPrompt")
            if pp and pp.Enabled then fireproximityprompt(pp) end
          end)
        end
      end)
      task.wait(0.1)
    end
  end
})
Forest:Button({
  Title    = "Cave Spider",
  Desc     = "Step 3",
  Callback = function()
    local r = eu.Character.HumanoidRootPart
    local p = workspace.GameplaySections.Task2.CompleteA
firetouchinterest(r, p, 0)
    firetouchinterest(r, p, 1)
  end
})
Forest:Button({
  Title    = "Cabin Dodger",
  Desc     = "Step 4",
  Callback = function()
    local r = eu.Character.HumanoidRootPart
    local p = workspace.GameplaySections.Task2.CompleteB
firetouchinterest(r, p, 0)
    firetouchinterest(r, p, 1)
  end
})
Forest:Button({
  Title    = "Decisions",
  Desc     = "Step 5",
  Callback = function()
    fireclickdetector(workspace.Map:GetChildren()[117].DressClone.ClickPart.ClickDetector)
  end
})
Forest:Button({
  Title    = "Finish Minigame",
  Desc     = "Step 6 (click when minigame start)",
  Callback = function()
    ReplicatedStorage.Remotes.MinigameEvent:FireServer(true)
  end
})

-- ============================================================
--  ⚡ KAIO TAB — EXCLUSIVO CEO
-- ============================================================
if isKaio and Tabs.Kaio then
  do
    local K = Tabs.Kaio

    -- ── INFO ──────────────────────────────────────────────────
    local kInfo = K:Section({ Title = "Painel KAIO", Icon = "shield", Opened = true })
    kInfo:Paragraph({
      Title = "⚡ Painel CEO",
      Desc  = "Funções de administração em tempo real: monitorar usuários, kick, entrar em servidores, gerenciar keys e mais."
    })

    K:Divider()

    -- ── USUÁRIOS ATIVOS ────────────────────────────────────────
    local usersSection = K:Section({ Title = "Usuários Ativos", Icon = "users", Opened = true })
    local usersPara = usersSection:Paragraph({ Title = "Lista", Desc = "Pressione Atualizar para carregar." })
    usersSection:Button({
      Title    = "↺ Atualizar Lista",
      Desc     = "Busca todos usando o script agora",
      Icon     = "refresh-cw",
      Callback = function()
        local ok, res = kaioGET("/kaio/users")
        if not ok or not res then
          usersPara:SetDesc("❌ Erro ao conectar com o servidor.")
          return
        end
        local ok2, data = pcall(function() return HttpService:JSONDecode(res) end)
        if not ok2 or not data or not data.users then
          usersPara:SetDesc("❌ Resposta inválida.")
          return
        end
        local users = data.users
        if #users == 0 then
          usersPara:SetDesc("Nenhum usuário ativo no momento.")
          return
        end
        local lines = {}
        for _, u in ipairs(users) do
          local tier_str = tostring(u.tier or "?")
          table.insert(lines, string.format("• %s | Tier %s | Srv: %s",
            u.username or "?",
            tier_str,
            (u.server_id and u.server_id:sub(1, 8) or "?")))
        end
        usersPara:SetDesc(table.concat(lines, "\n") .. "\n\nTotal: " .. #users)
      end
    })

    K:Divider()

    -- ── KICK USER ──────────────────────────────────────────────
    local kickSection = K:Section({ Title = "Kick User", Icon = "user-x", Opened = true })
    kickSection:Paragraph({
      Title = "Como funciona",
      Desc  = "Envia um kick para o player pelo username. O script dele detecta a solicitação e se expulsa automaticamente."
    })
    local kickInput = ""
    kickSection:Input({
      Title       = "Username",
      Desc        = "Nome exato do player (case sensitive)",
      Placeholder = "Ex: Playerxyz123",
      Callback    = function(val) kickInput = val end
    })
    kickSection:Button({
      Title    = "⚡ Kick",
      Desc     = "Expulsa o player informado",
      Icon     = "user-x",
      Callback = function()
        if kickInput == "" then
          WindUI:Notify({ Title = "Campo vazio", Content = "Digite o username primeiro.", Icon = "triangle-alert", Duration = 3 })
          return
        end
        local ok, res = kaioPOST("/kaio/kick", { username = kickInput }, KAIO_HEADERS)
        if ok then
          WindUI:Notify({ Title = "Kick enviado!", Content = kickInput .. " será expulso em até 30s.", Icon = "user-x", Duration = 4 })
        else
          WindUI:Notify({ Title = "Erro", Content = "Falha ao enviar kick.", Icon = "triangle-alert", Duration = 3 })
        end
      end
    })

    K:Divider()

    -- ── RANDOM SERVER ──────────────────────────────────────────
    local srvSection = K:Section({ Title = "Random Server", Icon = "server", Opened = true })
    srvSection:Paragraph({
      Title = "Como funciona",
      Desc  = "Busca um servidor aleatório onde alguém está usando nosso script e te teleporta para lá."
    })
    local serversPara = srvSection:Paragraph({ Title = "Servidores", Desc = "Pressione Buscar para ver." })
    srvSection:Button({
      Title    = "↺ Ver Servidores",
      Desc     = "Lista os servidores com usuários ativos",
      Icon     = "list",
      Callback = function()
        local ok, res = kaioGET("/kaio/servers")
        if not ok or not res then serversPara:SetDesc("❌ Erro de conexão.") return end
        local ok2, data = pcall(function() return HttpService:JSONDecode(res) end)
        if not ok2 or not data or not data.servers then serversPara:SetDesc("❌ Resposta inválida.") return end
        local srvs = data.servers
        if #srvs == 0 then serversPara:SetDesc("Nenhum servidor ativo.") return end
        local lines = {}
        for i, s in ipairs(srvs) do
          table.insert(lines, string.format("%d. %s | %s",
            i,
            s.username or "?",
            (s.server_id and s.server_id:sub(1, 12) .. "..." or "?")))
        end
        serversPara:SetDesc(table.concat(lines, "\n") .. "\n\nTotal: " .. #srvs)
      end
    })
    srvSection:Button({
      Title    = "🎲 Random Server",
      Desc     = "Entra em um servidor aleatório com usuários do script",
      Icon     = "shuffle",
      Callback = function()
        local ok, res = kaioGET("/kaio/servers")
        if not ok or not res then
          WindUI:Notify({ Title = "Erro", Content = "Não foi possível buscar servidores.", Icon = "triangle-alert", Duration = 3 })
          return
        end
        local ok2, data = pcall(function() return HttpService:JSONDecode(res) end)
        if not ok2 or not data or not data.servers then
          WindUI:Notify({ Title = "Erro", Content = "Resposta inválida.", Icon = "triangle-alert", Duration = 3 })
          return
        end
        local srvs = data.servers
        -- Filter out current server and same game
        local eligible = {}
        for _, s in ipairs(srvs) do
          if s.server_id ~= game.JobId and tostring(s.game_id) == tostring(game.PlaceId) then
            table.insert(eligible, s)
          end
        end
        if #eligible == 0 then
          WindUI:Notify({ Title = "Sem servidores", Content = "Nenhum outro servidor disponível no mesmo jogo.", Icon = "server", Duration = 4 })
          return
        end
        local target = eligible[math.random(1, #eligible)]
        WindUI:Notify({ Title = "Teleportando...", Content = "Entrando no servidor de " .. (target.username or "?"), Icon = "server", Duration = 3 })
        task.delay(1, function()
          pcall(function()
            game:GetService("TeleportService"):TeleportToPlaceInstance(game.PlaceId, target.server_id, eu)
          end)
        end)
      end
    })

    K:Divider()

    -- ── CRIAR KEY ──────────────────────────────────────────────
    local createKeySection = K:Section({ Title = "Criar Key", Icon = "key", Opened = true })
    local newKeyTier = 1
    local newKeyPerm = false
    local newKeyCustom = ""
    local newKeyHours = ""
    local createPara = createKeySection:Paragraph({ Title = "Resultado", Desc = "Preencha e clique em Criar." })
    createKeySection:Dropdown({
      Title  = "Tier da Key",
      Values = {
        { Title = "Bronze  (Tier 1)" },
        { Title = "Prata   (Tier 2)" },
        { Title = "Ouro    (Tier 3)" },
        { Title = "Custom  (Tier 4)" },
      },
      Value    = "Bronze  (Tier 1)",
      Callback = function(opt)
        local t = opt.Title:match("Tier (%d+)")
        newKeyTier = tonumber(t) or 1
      end
    })
    createKeySection:Toggle({
      Title = "Permanente",
      Desc  = "Key sem expiração",
      Value = false,
      Callback = function(state) newKeyPerm = state end
    })
    createKeySection:Input({
      Title       = "Horas (opcional)",
      Desc        = "Deixe vazio para usar o padrão do tier",
      Placeholder = "Ex: 48",
      Callback    = function(val) newKeyHours = val end
    })
    createKeySection:Input({
      Title       = "Key personalizada (opcional)",
      Desc        = "Deixe vazio para gerar automaticamente",
      Placeholder = "Ex: MEUID_2025",
      Callback    = function(val) newKeyCustom = val end
    })
    createKeySection:Button({
      Title    = "✚ Criar Key",
      Desc     = "Gera a key com as configurações acima",
      Icon     = "key",
      Callback = function()
        local body = {
          tier        = newKeyTier,
          isPermanent = newKeyPerm,
          customKey   = newKeyCustom ~= "" and newKeyCustom or nil,
          durationHours = newKeyHours ~= "" and tonumber(newKeyHours) or nil,
        }
        local ok, res = kaioPOST("/kaio/create-key", body, KAIO_HEADERS)
        if not ok or not res then
          createPara:SetDesc("❌ Erro ao conectar.")
          WindUI:Notify({ Title = "Erro", Content = "Falha ao criar key.", Icon = "triangle-alert", Duration = 3 })
          return
        end
        local ok2, data = pcall(function()
          return HttpService:JSONDecode(res.Body or res)
        end)
        if ok2 and data and data.key then
          createPara:SetDesc("✅ Key criada!\n\n" .. tostring(data.key) ..
            "\nTier: " .. tostring(data.tierName) ..
            " | Permanente: " .. tostring(data.isPermanent))
          WindUI:Notify({ Title = "Key criada!", Content = tostring(data.key), Icon = "key", Duration = 6 })
        elseif ok2 and data and data.error then
          createPara:SetDesc("❌ " .. tostring(data.error))
          WindUI:Notify({ Title = "Erro", Content = tostring(data.error), Icon = "triangle-alert", Duration = 4 })
        else
          createPara:SetDesc("❌ Resposta inesperada.")
        end
      end
    })

    K:Divider()

    -- ── REVOGAR KEY ────────────────────────────────────────────
    local revokeSection = K:Section({ Title = "Revogar Key", Icon = "key-round", Opened = true })
    local revokeInput = ""
    local revokePara = revokeSection:Paragraph({ Title = "Resultado", Desc = "Digite a key e confirme." })
    revokeSection:Input({
      Title       = "Key para revogar",
      Desc        = "Insira a key exata",
      Placeholder = "Ex: KAIO_AB12C010125",
      Callback    = function(val) revokeInput = val end
    })
    revokeSection:Button({
      Title    = "🗑 Revogar Key",
      Desc     = "Remove a key permanentemente do sistema",
      Icon     = "trash-2",
      Callback = function()
        if revokeInput == "" then
          WindUI:Notify({ Title = "Campo vazio", Content = "Digite a key primeiro.", Icon = "triangle-alert", Duration = 3 })
          return
        end
        local ok, res = kaioRequest("DELETE", "/kaio/revoke-key/" .. revokeInput, nil, KAIO_HEADERS)
        if not ok or not res then
          revokePara:SetDesc("❌ Erro ao conectar.")
          return
        end
        local ok2, data = pcall(function() return HttpService:JSONDecode(res) end)
        if ok2 and data and data.ok then
          revokePara:SetDesc("✅ Key revogada: " .. revokeInput)
          WindUI:Notify({ Title = "Key revogada!", Content = revokeInput, Icon = "trash-2", Duration = 4 })
          revokeInput = ""
        elseif ok2 and data and data.error then
          revokePara:SetDesc("❌ " .. tostring(data.error))
          WindUI:Notify({ Title = "Erro", Content = tostring(data.error), Icon = "triangle-alert", Duration = 4 })
        else
          revokePara:SetDesc("❌ Resposta inesperada.")
        end
      end
    })

    K:Divider()

    -- ── VER KEYS ──────────────────────────────────────────────
    local keysSection = K:Section({ Title = "Ver Todas as Keys", Icon = "list", Opened = false })
    local keysPara = keysSection:Paragraph({ Title = "Keys", Desc = "Pressione Carregar." })
    keysSection:Button({
      Title    = "↺ Carregar Keys",
      Desc     = "Lista as 50 keys mais recentes",
      Icon     = "refresh-cw",
      Callback = function()
        local ok, res = kaioGET("/kaio/keys")
        if not ok or not res then keysPara:SetDesc("❌ Erro de conexão.") return end
        local ok2, data = pcall(function() return HttpService:JSONDecode(res) end)
        if not ok2 or not data or not data.keys then keysPara:SetDesc("❌ Resposta inválida.") return end
        local keys = data.keys
        if #keys == 0 then keysPara:SetDesc("Nenhuma key encontrada.") return end
        local lines = {}
        for i, k in ipairs(keys) do
          if i > 50 then break end
          local exp = k.is_permanent and "∞" or (k.expires_at and k.expires_at:sub(1, 10) or "?")
          table.insert(lines, string.format("• %s | T%s | %s%s",
            tostring(k.key),
            tostring(k.tier),
            exp,
            k.hwid and " | 🔒" or ""))
        end
        keysPara:SetDesc(table.concat(lines, "\n"))
      end
    })

    K:Divider()

    -- ── UTILIDADES KAIO ───────────────────────────────────────
    local utilSection = K:Section({ Title = "Utilidades KAIO", Icon = "wrench", Opened = true })
    utilSection:Button({
      Title    = "📋 Copiar Job ID",
      Desc     = "Copia o ID do servidor atual para a área de transferência",
      Icon     = "clipboard",
      Callback = function()
        pcall(function() setclipboard(game.JobId) end)
        WindUI:Notify({ Title = "Copiado!", Content = "Job ID: " .. game.JobId:sub(1, 16) .. "...", Icon = "clipboard", Duration = 3 })
      end
    })
    utilSection:Button({
      Title    = "👥 Ver Jogadores no Servidor",
      Desc     = "Lista todos os players neste servidor",
      Icon     = "users",
      Callback = function()
        local lines = {}
        for _, p in ipairs(Players:GetPlayers()) do
          local isBeast = p.Character and p.Character:FindFirstChild("BeastPowers")
          table.insert(lines, string.format("• %s%s", p.Name, isBeast and " 🐺" or " 🏃"))
        end
        WindUI:Notify({
          Title   = "Jogadores (" .. #Players:GetPlayers() .. ")",
          Content = table.concat(lines, "\n"),
          Icon    = "users",
          Duration = 6,
        })
      end
    })
    utilSection:Button({
      Title    = "🔍 Localizar Player",
      Desc     = "Teleporta para o jogador mais próximo da tela",
      Icon     = "locate",
      Callback = function()
        local myChar = eu.Character
        local myRoot = myChar and myChar:FindFirstChild("HumanoidRootPart")
        if not myRoot then return end
        local closest, closestDist = nil, math.huge
        for _, p in ipairs(Players:GetPlayers()) do
          if p == eu then continue end
          local c = p.Character
          local r = c and c:FindFirstChild("HumanoidRootPart")
          if not r then continue end
          local d = (myRoot.Position - r.Position).Magnitude
          if d < closestDist then closestDist = d closest = p end
        end
        if closest then
          local r2 = closest.Character:FindFirstChild("HumanoidRootPart")
          if r2 then
            myRoot.CFrame = r2.CFrame * CFrame.new(4, 0, 0)
            WindUI:Notify({ Title = "Teleportado!", Content = "Você está perto de " .. closest.Name, Icon = "locate", Duration = 3 })
          end
        else
          WindUI:Notify({ Title = "Nenhum jogador", Content = "Não há outros jogadores no servidor.", Icon = "triangle-alert", Duration = 3 })
        end
      end
    })
    utilSection:Button({
      Title    = "🌐 Anunciar via API",
      Desc     = "Envia um anúncio para todos os usuários do script",
      Icon     = "megaphone",
      Callback = function()
        WindUI:Notify({
          Title   = "Use o painel web",
          Content = "Acesse o painel de admin no site para enviar anúncios globais.",
          Icon    = "megaphone",
          Duration = 4,
        })
      end
    })
    utilSection:Button({
      Title    = "♻ Rejoin",
      Desc     = "Reconecta ao mesmo servidor",
      Icon     = "refresh-cw",
      Callback = function()
        pcall(function()
          game:GetService("TeleportService"):TeleportToPlaceInstance(game.PlaceId, game.JobId, eu)
        end)
      end
    })

    K:Divider()

    -- ── PAINEL ADMIN WEB ───────────────────────────────────────
    local adminSec = K:Section({ Title = "Painel Admin Web", Icon = "shield-half", Opened = true })
    adminSec:Paragraph({
      Title = "Acesso Admin",
      Desc  = "O painel web de administração completo está disponível em:\n" .. SERVER_URL:gsub("/api", "") .. "/api/admin\n\nPressione o botão abaixo para copiar o link."
    })
    adminSec:Button({
      Title    = "📋 Copiar Link do Admin",
      Desc     = "Copia o link do painel admin para a área de transferência",
      Icon     = "clipboard",
      Callback = function()
        local adminUrl = SERVER_URL:gsub("/api", "") .. "/api/admin"
        pcall(function() setclipboard(adminUrl) end)
        WindUI:Notify({
          Title   = "✅ Link copiado!",
          Content = "Cole no navegador: " .. adminUrl,
          Icon    = "clipboard",
          Duration = 6
        })
      end
    })
    adminSec:Button({
      Title    = "📋 Copiar Link GetKey (admin)",
      Desc     = "Link da página de obter key para compartilhar",
      Icon     = "key",
      Callback = function()
        local getkeyUrl = SERVER_URL:gsub("/api", "") .. "/api/getkey"
        pcall(function() setclipboard(getkeyUrl) end)
        WindUI:Notify({
          Title   = "✅ Link GetKey copiado!",
          Content = getkeyUrl,
          Icon    = "key",
          Duration = 5
        })
      end
    })
  end
end

-- ============================================================
--  ABA TEMPLATES — Templates salvos do usuário
-- ============================================================
do
  local tmplTab = Tabs.Template
  local tmplSec = tmplTab:Section({ Title = "Seus Templates", Icon = "bookmark", Opened = true })

  local statusLabel = tmplSec:Paragraph({
    Title = "Carregando...",
    Desc  = "Buscando seus templates salvos..."
  })

  local activeId   = nil
  local toggleMap  = {}

  local function activateTemplate(tid)
    activeId = tid
    for otherId, tog in pairs(toggleMap) do
      if otherId ~= tid then
        tog:SetValue(false)
      end
    end
    task.spawn(function()
      kaioPOST("/bot/templates/" .. tid .. "/activate", { key = KAIO_HEADERS["x-kaio-key"] })
    end)
    WindUI:Notify({
      Title    = "✅ Template Ativado",
      Content  = "O template será aplicado no próximo carregamento.",
      Icon     = "check",
      Duration = 4
    })
  end

  local function loadTemplates()
    statusLabel:SetTitle("Carregando...")
    statusLabel:SetDesc("Buscando seus templates no servidor...")

    task.spawn(function()
      local ok, data = kaioGET("/bot/user-templates?key=" .. KAIO_HEADERS["x-kaio-key"])

      if not ok or type(data) ~= "table" then
        statusLabel:SetTitle("Erro ao carregar")
        statusLabel:SetDesc("Não foi possível buscar seus templates. Verifique sua key.")
        return
      end

      local templates = data.templates or {}

      if #templates == 0 then
        statusLabel:SetTitle("Nenhum template salvo")
        statusLabel:SetDesc("Você ainda não tem templates.\nUse o botão '▶️ Usar' em um template no Discord para salvar aqui.")
        return
      end

      statusLabel:SetTitle(#templates .. " template(s) disponível(is)")
      statusLabel:SetDesc("Ative um template para aplicar no próximo carregamento. Só um pode estar ativo por vez.")

      for _, tmpl in ipairs(templates) do
        local tid   = tmpl.template_id
        local title = "Template #" .. tostring(tid)
        local desc  = tostring(tmpl.system_desc or tmpl.description or "Configuração personalizada")
        if tmpl.discord_username then
          desc = "Por: " .. tostring(tmpl.discord_username) .. " — " .. desc
        end
        local isAct = (tmpl.is_active == true)
        if isAct then activeId = tid end

        if not toggleMap[tid] then
          local tog = tmplSec:Toggle({
            Title    = title,
            Desc     = desc,
            Value    = isAct,
            Callback = function(state)
              if state then
                activateTemplate(tid)
              else
                if activeId == tid then
                  activeId = nil
                end
              end
            end
          })
          toggleMap[tid] = tog
        else
          toggleMap[tid]:SetValue(isAct)
        end
      end
    end)
  end

  tmplSec:Button({
    Title    = "🔄 Atualizar Lista",
    Desc     = "Recarrega seus templates do servidor",
    Icon     = "refresh-cw",
    Callback = loadTemplates
  })

  -- ── GERAR CÓDIGO ──────────────────────────────────────────
  local genSec = tmplTab:Section({ Title = "Compartilhar Config", Icon = "share-2", Opened = true })
  genSec:Paragraph({
    Title = "Como funciona",
    Desc  = "1. Coloque seu nome (opcional)\n2. Ative as funções desejadas nas outras abas\n3. Clique em 'Gerar Código Morse'\n4. Cole o código no Discord pelo botão '📤 Enviar Template'"
  })

  local allSettingKeys = {
    "PlayerESP","ComputerESP","ExitESP","AutoHack","AutoEscape","NeverFail",
    "SpeedBoost","Noclip","AutoHide","AntiSlow","HitAura","AutoTie",
    "BreakRope","SlowBeast","ForceAbility","AlertUse","AutoBeastHide","AutoCollect",
    "AutoAction","AutoInteract","AIPredict","NuncaDePego","StalkerArmario","ESPFreezer",
    "BeastAlert","Camera3D","AntiSlowSurvivor","Fullbright","TeleportSurvivor",
    "DimGraphics","AgacharForce","WallHop","BeastCheck",
    "BeastRadar","FugaExpress"
  }

  genSec:Input({
    Title       = "Seu Nome (opcional)",
    Desc        = "Aparece na descrição do template — letras e números apenas",
    Placeholder = "Ex: PlayerName123",
    Callback    = function(val)
      getgenv().KaioTemplateName = tostring(val or ""):gsub("[^%w]", ""):upper()
    end
  })

  genSec:Button({
    Title    = "📋 Gerar Código Morse",
    Desc     = "Copia o código Morse da sua configuração atual",
    Icon     = "clipboard",
    Callback = function()
      local active = {}
      for _, key in ipairs(allSettingKeys) do
        if getgenv()[key] == true then
          table.insert(active, key)
        end
      end

      if #active == 0 then
        WindUI:Notify({
          Title   = "⚠️ Nenhuma config ativa",
          Content = "Ative pelo menos uma função antes de gerar o código.",
          Icon    = "alert-triangle",
          Duration = 4
        })
        return
      end

      -- Formato compacto: NOME:VELOCIDADE:FEAT1,FEAT2,...
      local nome  = (getgenv().KaioTemplateName ~= "" and getgenv().KaioTemplateName) or eu.Name:upper():gsub("[^%w]","")
      local speed = tostring(math.floor(getgenv().SurvivorSpeed or 16))
      local feats = table.concat(active, ",")
      local raw   = nome .. ":" .. speed .. ":" .. feats

      -- Codifica em Morse
      local morse = morseEncode(raw)

      if morse ~= "" then
        pcall(function() setclipboard(morse) end)
        WindUI:Notify({
          Title   = "✅ Código Morse copiado!",
          Content = #active .. " função(ões) ativa(s) | Speed: " .. speed .. "\nCole no Discord para criar o template.",
          Icon    = "clipboard",
          Duration = 6
        })
      else
        WindUI:Notify({
          Title   = "❌ Erro ao gerar código",
          Content = "Tente novamente.",
          Icon    = "x",
          Duration = 4
        })
      end
    end
  })

  -- ── LIMPAR TEMPLATE ATIVO ───────────────────────────────────
  genSec:Button({
    Title    = "🗑 Limpar Template Salvo",
    Desc     = "Remove o template salvo para esta key (para de aplicar ao iniciar)",
    Icon     = "trash-2",
    Callback = function()
      local ok = kaioDELETE("/bot/active-template?key=" .. KAIO_HEADERS["x-kaio-key"])
      if ok then
        WindUI:Notify({ Title = "✅ Template removido", Content = "Suas funções não serão mais restauradas automaticamente.", Icon = "trash-2", Duration = 4 })
      else
        WindUI:Notify({ Title = "❌ Erro ao remover", Content = "Tente novamente.", Icon = "x", Duration = 3 })
      end
    end
  })

  -- ── APLICAR TEMPLATE PENDENTE AO CARREGAR ──────────────────
  -- O template persiste entre partidas — só é limpo se o usuário clicar em "Limpar"
  task.delay(4, function()
    local ok, data = kaioGET("/bot/pending-template?key=" .. KAIO_HEADERS["x-kaio-key"])
    if not ok or type(data) ~= "table" or not data.config then return end

    local cfg = data.config
    if type(cfg) ~= "table" then return end

    -- cfg pode estar dentro de cfg.config (formato: {game=..., config={...}})
    local settings = cfg["config"] or cfg
    if type(settings) ~= "table" then return end

    local applied = 0
    for _, key in ipairs(allSettingKeys) do
      if settings[key] ~= nil then
        getgenv()[key] = (settings[key] == true)
        applied = applied + 1
      end
    end

    -- Aplica velocidade se vier no template
    if type(settings["speed"]) == "number" and settings["speed"] >= 16 and settings["speed"] <= 100 then
      getgenv().SurvivorSpeed = settings["speed"]
      pcall(function() speedPreview:SetDesc(tostring(settings["speed"]) .. " studs/s  |  mín: 16  ·  máx: 100") end)
    end

    local author = (cfg["author"] and tostring(cfg["author"])) or ""
    local extra  = author ~= "" and (" | De: " .. author) or ""

    if applied > 0 then
      WindUI:Notify({
        Title   = "📋 Template carregado!",
        Content = applied .. " função(ões) restaurada(s)" .. extra .. ".\nRecarregue o script para ativar os toggles.",
        Icon    = "check",
        Duration = 6
      })
    end
  end)

  task.delay(3, loadTemplates)
end
