-- KAIO APPS | Painel Admin In-Game
-- Carregado apenas quando a key ADMIN2108 é usada

local WindUI     = getgenv().WindUI
local SERVER_URL = getgenv().KaioServerURL

local Players        = game:GetService("Players")
local HttpService    = game:GetService("HttpService")
local TeleportService= game:GetService("TeleportService")
local eu             = Players.LocalPlayer

local HEADERS = { ["x-game-admin"] = "ADMIN2108", ["Content-Type"] = "application/json" }

local function request(method, path, body)
  local url = SERVER_URL .. path
  local ok, r = pcall(function()
    return HttpService:RequestAsync({
      Url     = url,
      Method  = method,
      Headers = HEADERS,
      Body    = body and HttpService:JSONEncode(body) or nil,
    })
  end)
  if not ok or not r then return nil end
  local dok, data = pcall(function() return HttpService:JSONDecode(r.Body) end)
  return dok and data or nil
end

local function getUsers()
  return request("GET", "/admin-game/active-users")
end

local function sendAnnounce(msg)
  return request("POST", "/admin-game/announce", { message = msg, prefix = "CEO" })
end

local function blockUser(username)
  return request("POST", "/admin-game/block-user", { username = username })
end

-- ============================================================
--  BUILD ADMIN WINDOW
-- ============================================================
local Window = WindUI:CreateWindow({
  Title    = "KAIO — Admin Panel",
  Icon     = "shield-alert",
  Author   = "ADMIN2108",
  Folder   = "KaioAdmin",
  Size     = UDim2.fromOffset(560, 400),
  Resize   = true,
  SideBarWidth = 160,
  Theme    = "Dark",
})

Window:Browser()

-- ============================================================
--  TAB: USUÁRIOS ONLINE
-- ============================================================
local usersTab = Window:Tab({ Title = "Online", Icon = "users" })
local usersSection = usersTab:Section({ Title = "Jogadores com Script Ativo (últimos 2 min)" })

local userListLabel = usersSection:Paragraph({
  Title   = "Carregando...",
  Content = "Aguarde",
})

local activeUsers = {}

local function refreshUsers()
  local data = getUsers()
  activeUsers = {}
  if data and data.users then
    activeUsers = data.users
  end

  if #activeUsers == 0 then
    userListLabel:Update({ Title = "Nenhum usuário online", Content = "Ninguém usando o script agora." })
    return
  end

  local lines = {}
  for i, u in ipairs(activeUsers) do
    local tier = u.tier == 3 and "🟡 Ouro" or u.tier == 2 and "⬜ Prata" or "🟤 Bronze"
    table.insert(lines, string.format("%d. %s [%s] — Server: %s", i, u.username or "?", tier, (u.server_id or "?"):sub(1,8)))
  end
  userListLabel:Update({
    Title   = string.format("Usuários Online: %d", #activeUsers),
    Content = table.concat(lines, "\n"),
  })
end

refreshUsers()

usersSection:Button({
  Title    = "🔄 Atualizar Lista",
  Icon     = "refresh-cw",
  Callback = refreshUsers,
})

-- ============================================================
--  TAB: ENTRAR NO SERVIDOR (Join Server)
-- ============================================================
local joinTab = Window:Tab({ Title = "Join Server", Icon = "door-open" })
local joinSection = joinTab:Section({ Title = "Entrar no Servidor de um Usuário" })

local selectedIdx = 1

joinSection:Dropdown({
  Title   = "Selecionar Usuário",
  Icon    = "user",
  Values  = { "Atualizar lista primeiro" },
  Default = 1,
  Callback = function(val)
    for i, u in ipairs(activeUsers) do
      if string.format("%s [%s]", u.username or "?", (u.server_id or ""):sub(1,8)) == val then
        selectedIdx = i
        break
      end
    end
  end,
})

joinSection:Button({
  Title    = "🔄 Carregar Usuários no Dropdown",
  Icon     = "users",
  Callback = function()
    refreshUsers()
    WindUI:Notify({ Title = "Lista atualizada!", Content = "Reabra o dropdown para ver.", Icon = "check", Duration = 3 })
  end,
})

joinSection:Button({
  Title    = "🚀 Entrar no Servidor",
  Icon     = "door-open",
  Callback = function()
    local user = activeUsers[selectedIdx]
    if not user or not user.server_id or not user.game_id then
      WindUI:Notify({ Title = "Erro", Content = "Selecione um usuário válido primeiro.", Icon = "x-circle", Duration = 4 })
      return
    end
    WindUI:Notify({ Title = "Teleportando...", Content = "Entrando no servidor de " .. (user.username or "?"), Icon = "door-open", Duration = 4 })
    pcall(function()
      TeleportService:TeleportToPlaceInstance(
        tonumber(user.game_id) or game.PlaceId,
        user.server_id,
        eu
      )
    end)
  end,
})

-- ============================================================
--  TAB: ESP (ver quem usa script)
-- ============================================================
local espTab = Window:Tab({ Title = "ESP", Icon = "eye" })
local espSection = espTab:Section({ Title = "ESP — Ver Jogadores com Script" })

local espEnabled = false
local espHighlights = {}

local function clearEsp()
  for _, h in pairs(espHighlights) do pcall(function() h:Destroy() end) end
  espHighlights = {}
end

local function updateEsp()
  clearEsp()
  if not espEnabled then return end
  for _, u in ipairs(activeUsers) do
    local plr = Players:FindFirstChild(u.username or "")
    if plr then
      local char = plr.Character
      if char then
        local h = Instance.new("Highlight")
        h.FillColor = Color3.fromRGB(0, 200, 255)
        h.OutlineColor = Color3.fromRGB(255, 255, 0)
        h.FillTransparency = 0.5
        h.Adornee = char
        h.Parent = game.CoreGui
        espHighlights[u.username] = h
      end
    end
  end
end

espSection:Toggle({
  Title    = "ESP — Destacar Usuários com Script",
  Icon     = "eye",
  Default  = false,
  Callback = function(state)
    espEnabled = state
    if state then
      refreshUsers()
      updateEsp()
      WindUI:Notify({ Title = "ESP Ativo", Content = "Jogadores com script destacados em azul.", Icon = "eye", Duration = 3 })
    else
      clearEsp()
    end
  end,
})

espSection:Button({
  Title    = "🔄 Atualizar ESP",
  Icon     = "refresh-cw",
  Callback = function()
    refreshUsers()
    updateEsp()
    WindUI:Notify({ Title = "ESP Atualizado", Content = string.format("%d usuários detectados.", #activeUsers), Icon = "check", Duration = 3 })
  end,
})

-- ============================================================
--  TAB: BLOQUEAR USUÁRIO
-- ============================================================
local blockTab = Window:Tab({ Title = "Bloquear", Icon = "user-x" })
local blockSection = blockTab:Section({ Title = "Bloquear Usuário (expulsa do servidor)" })

local blockUsername = ""

blockSection:Input({
  Title       = "Username do Jogador",
  Icon        = "user",
  Placeholder = "NomeDoJogador",
  Callback    = function(val) blockUsername = val end,
})

blockSection:Button({
  Title    = "🚫 Bloquear Usuário",
  Icon     = "user-x",
  Callback = function()
    local name = blockUsername:match("^%s*(.-)%s*$")
    if name == "" then
      WindUI:Notify({ Title = "Erro", Content = "Digite o username do jogador.", Icon = "x-circle", Duration = 4 })
      return
    end
    local r = blockUser(name)
    if r and r.ok then
      WindUI:Notify({ Title = "Bloqueado!", Content = name .. " foi bloqueado. Será expulso ao próximo heartbeat.", Icon = "user-x", Duration = 5 })
    else
      WindUI:Notify({ Title = "Erro", Content = "Não foi possível bloquear " .. name, Icon = "x-circle", Duration = 4 })
    end
    blockUsername = ""
  end,
})

blockSection:Paragraph({
  Title   = "ℹ️ Como funciona",
  Content = "Ao bloquear, o usuário é adicionado à lista negra. Na próxima vez que o script checar (heartbeat), ele será desconectado do servidor automaticamente.",
})

-- ============================================================
--  TAB: ANÚNCIO GLOBAL
-- ============================================================
local annTab = Window:Tab({ Title = "Anúncio", Icon = "megaphone" })
local annSection = annTab:Section({ Title = "Enviar Mensagem para Todos os Usuários" })

local annMessage = ""

annSection:Input({
  Title       = "Mensagem",
  Icon        = "megaphone",
  Placeholder = "Ex: Olá a todos! Novo update disponível.",
  Callback    = function(val) annMessage = val end,
})

annSection:Button({
  Title    = "📣 Enviar Anúncio Global",
  Icon     = "megaphone",
  Callback = function()
    local msg = annMessage:match("^%s*(.-)%s*$")
    if msg == "" then
      WindUI:Notify({ Title = "Erro", Content = "Digite uma mensagem.", Icon = "x-circle", Duration = 4 })
      return
    end
    local r = sendAnnounce(msg)
    if r and r.ok then
      WindUI:Notify({ Title = "Anúncio Enviado!", Content = "Todos verão: CEO: " .. msg, Icon = "megaphone", Duration = 5 })
    else
      WindUI:Notify({ Title = "Erro", Content = "Falha ao enviar anúncio.", Icon = "x-circle", Duration = 4 })
    end
    annMessage = ""
  end,
})

annSection:Paragraph({
  Title   = "ℹ️ Formato",
  Content = "A mensagem aparece no topo da tela de todos os usuários com o script ativo no formato:\n\"CEO: [sua mensagem]\"",
})

-- ============================================================
--  AUTO-REFRESH ESP a cada 60s
-- ============================================================
task.spawn(function()
  while task.wait(60) do
    if espEnabled then
      refreshUsers()
      updateEsp()
    end
  end
end)

WindUI:Notify({
  Title    = "Admin Panel Carregado",
  Content  = "Bem-vindo, ADMIN. Todos os poderes ativados.",
  Icon     = "shield-alert",
  Duration = 6
})
