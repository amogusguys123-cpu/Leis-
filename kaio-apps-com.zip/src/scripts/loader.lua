-- KAIO APPS | Facility Apps — Flee The Facility Edition
-- Loader v9.0 — ADMIN2108 + Heartbeat + Announce + Block Check

local WindUI = loadstring(game:HttpGet("https://github.com/Footagesus/WindUI/releases/latest/download/main.lua"))()

if game.GameId ~= 372226183 and game.PlaceId ~= 372226183 then
  WindUI:Notify({ Title="Script Incompatível!", Content="Exclusivo para Flee The Facility.", Icon="triangle-alert", Duration=9 })
  error("[KAIO] GameId incorreto: " .. tostring(game.GameId)); return
end

local Players        = game:GetService("Players")
local HttpService    = game:GetService("HttpService")
local TweenService   = game:GetService("TweenService")
local eu             = Players.LocalPlayer
local playerGui      = eu:WaitForChild("PlayerGui")
local KEY_FILE       = "kaio_facility_key.txt"
local SERVER_URL     = "__SERVER_URL__"

-- ============================================================
--  TIERS
-- ============================================================
local TIER_NAMES = { [1]="Bronze", [2]="Prata", [3]="Ouro", [99]="Admin" }

-- ============================================================
--  HWID HELPER
-- ============================================================
local function getHwid()
  local hwid = ""
  pcall(function() hwid = clonefunction(gethwid)() end)
  if hwid == "" then pcall(function() hwid = gethwid() end) end
  if hwid == "" then
    pcall(function() hwid = game:GetService("RbxAnalyticsService"):GetClientId() end)
  end
  return hwid ~= "" and hwid or "unknown"
end

-- ============================================================
--  HEARTBEAT — envia a cada 30s, retorna anúncio ativo
-- ============================================================
local function sendHeartbeat(key, tier)
  pcall(function()
    local body = HttpService:JSONEncode({
      hwid     = getHwid(),
      username = eu.Name,
      gameId   = tostring(game.PlaceId),
      serverId = tostring(game.JobId),
      key      = key or "",
      tier     = tier or 1,
    })
    local r = HttpService:RequestAsync({
      Url    = SERVER_URL .. "/heartbeat",
      Method = "POST",
      Headers= { ["Content-Type"] = "application/json" },
      Body   = body,
    })
    if r and r.Body then
      local ok, data = pcall(function() return HttpService:JSONDecode(r.Body) end)
      if ok and data and data.announce then
        local ann = data.announce
        local msg = (ann.prefix or "CEO") .. ": " .. (ann.message or "")
        getgenv()._kaioLastAnnounce = msg
      end
    end
  end)
end

-- ============================================================
--  CHECK BLOCKED — verifica se o usuário está bloqueado
-- ============================================================
local function checkBlocked()
  local blocked = false
  pcall(function()
    local r = game:HttpGet(SERVER_URL .. "/blocked?username=" .. HttpService:UrlEncode(eu.Name))
    local ok, data = pcall(function() return HttpService:JSONDecode(r) end)
    if ok and data and data.blocked then
      blocked = true
    end
  end)
  return blocked
end

-- ============================================================
--  ANNOUNCE DISPLAY — banner no topo da tela
-- ============================================================
local announceGui = nil
local lastAnnounceMsg = ""

local function showAnnounce(message)
  if message == lastAnnounceMsg and announceGui then return end
  lastAnnounceMsg = message

  if announceGui then pcall(function() announceGui:Destroy() end) end
  if not message or message == "" then announceGui = nil; return end

  local sg = Instance.new("ScreenGui")
  sg.Name = "KaioAnnounce"; sg.ResetOnSpawn = false
  sg.IgnoreGuiInset = true; sg.DisplayOrder = 1000
  sg.Parent = playerGui
  announceGui = sg

  local banner = Instance.new("Frame", sg)
  banner.Size = UDim2.new(1, 0, 0, 42)
  banner.Position = UDim2.fromOffset(0, -44)
  banner.BackgroundColor3 = Color3.fromRGB(183, 28, 28)
  banner.BorderSizePixel = 0
  banner.ZIndex = 10

  local lbl = Instance.new("TextLabel", banner)
  lbl.Size = UDim2.fromScale(1, 1)
  lbl.BackgroundTransparency = 1
  lbl.Text = "📣  " .. message
  lbl.TextColor3 = Color3.new(1, 1, 1)
  lbl.Font = Enum.Font.GothamBold
  lbl.TextSize = 14
  lbl.ZIndex = 11
  lbl.TextXAlignment = Enum.TextXAlignment.Center

  local closeBtn = Instance.new("TextButton", banner)
  closeBtn.Size = UDim2.fromOffset(28, 28)
  closeBtn.Position = UDim2.new(1, -32, 0.5, -14)
  closeBtn.BackgroundTransparency = 1
  closeBtn.Text = "✕"
  closeBtn.TextColor3 = Color3.new(1, 1, 1)
  closeBtn.Font = Enum.Font.GothamBold
  closeBtn.TextSize = 14
  closeBtn.ZIndex = 12
  closeBtn.MouseButton1Click:Connect(function()
    sg:Destroy(); announceGui = nil; lastAnnounceMsg = ""
  end)

  TweenService:Create(banner, TweenInfo.new(0.4, Enum.EasingStyle.Quart, Enum.EasingDirection.Out),
    { Position = UDim2.fromOffset(0, 0) }):Play()

  -- Auto-hide depois de 30s
  task.delay(30, function()
    if announceGui == sg then
      TweenService:Create(banner, TweenInfo.new(0.3), { Position = UDim2.fromOffset(0, -44) }):Play()
      task.wait(0.35)
      pcall(function() sg:Destroy() end)
      if announceGui == sg then announceGui = nil end
    end
  end)
end

-- ============================================================
--  HEARTBEAT LOOP (após autenticação)
-- ============================================================
local function startHeartbeatLoop(key, tier)
  task.spawn(function()
    while task.wait(30) do
      sendHeartbeat(key, tier)
      -- Mostrar anúncio se houver
      local ann = getgenv()._kaioLastAnnounce
      if ann and ann ~= "" and ann ~= lastAnnounceMsg then
        showAnnounce(ann)
      end
      -- Verificar se foi bloqueado
      if checkBlocked() then
        WindUI:Notify({
          Title   = "🚫 Conta Bloqueada!",
          Content = "Você foi bloqueado pelo administrador.",
          Icon    = "user-x",
          Duration = 10,
        })
        task.wait(3)
        eu:Kick("[KAIO] Conta bloqueada pelo administrador.")
        break
      end
    end
  end)
end

-- ============================================================
--  KAIO KEY VALIDATION
-- ============================================================
local function kaioCheck(key, hwid)
  local url = SERVER_URL .. "/keys/validate?key=" .. HttpService:UrlEncode(key) .. "&hwid=" .. HttpService:UrlEncode(hwid)
  local ok, raw = pcall(function() return game:HttpGet(url) end)
  if not ok or not raw or raw == "" then
    return { success=false, message="Erro de conexão com o servidor." }
  end

  local dok, data = pcall(function() return HttpService:JSONDecode(raw) end)
  if not dok or not data then
    return { success=false, message="Resposta inválida do servidor." }
  end

  if not data.valid then
    return { success=false, message=data.message or "Key inválida ou expirada." }
  end

  return {
    success    = true,
    tier       = data.tier or 1,
    tierName   = data.name or TIER_NAMES[data.tier or 1] or "Bronze",
    expireDate = data.expireDate or "?",
    isPermanent= data.isPermanent or false,
    isAdmin    = data.isAdmin or false,
  }
end

-- ============================================================
--  LOAD ADMIN PANEL (ADMIN2108)
-- ============================================================
local function LoadAdminPanel()
  task.spawn(function()
    getgenv().KaioServerURL = SERVER_URL
    local ok, content = pcall(function()
      return game:HttpGet(SERVER_URL .. "/scripts/admin-panel.lua")
    end)
    if not ok or not content or content == "" then
      WindUI:Notify({ Title="Erro", Content="Falha ao carregar painel admin.", Icon="bug-play", Duration=8 })
      return
    end
    local lok, err = pcall(function() loadstring(content)() end)
    if not lok then
      WindUI:Notify({ Title="Erro Admin", Content=tostring(err):sub(1,80), Icon="bug-play", Duration=8 })
    end
  end)
end

-- ============================================================
--  LOAD NORMAL SCRIPT
-- ============================================================
local function LoadScript(tier, name, key)
  task.spawn(function()
    -- Loading screen básico enquanto baixa o script
    local loadingSg = Instance.new("ScreenGui")
    loadingSg.Name = "KaioLoading"
    loadingSg.ResetOnSpawn = false
    loadingSg.IgnoreGuiInset = true
    loadingSg.DisplayOrder = 998
    loadingSg.Parent = playerGui

    local loadFrame = Instance.new("Frame", loadingSg)
    loadFrame.Size = UDim2.fromOffset(220, 52)
    loadFrame.Position = UDim2.new(0.5, -110, 0, 12)
    loadFrame.BackgroundColor3 = Color3.fromRGB(10, 14, 20)
    loadFrame.BackgroundTransparency = 0.05
    loadFrame.BorderSizePixel = 0
    Instance.new("UICorner", loadFrame).CornerRadius = UDim.new(0, 8)
    local ls = Instance.new("UIStroke", loadFrame)
    ls.Color = Color3.fromRGB(229, 57, 53); ls.Thickness = 1

    local loadLbl = Instance.new("TextLabel", loadFrame)
    loadLbl.Size = UDim2.fromScale(1, 1)
    loadLbl.BackgroundTransparency = 1
    loadLbl.Font = Enum.Font.GothamBold
    loadLbl.TextSize = 13
    loadLbl.TextColor3 = Color3.new(1, 1, 1)
    loadLbl.Text = "⚡ KAIO APPS — Carregando..."

    local dots = 0
    local lastDot = 0
    local dotConn = game:GetService("RunService").Heartbeat:Connect(function()
      if tick() - lastDot < 0.45 then return end
      lastDot = tick()
      dots = (dots + 1) % 4
      loadLbl.Text = "⚡ KAIO APPS — Carregando" .. string.rep(".", dots)
    end)

    local okMain, mainContent = pcall(function()
      return game:HttpGet("__SERVER_URL__/scripts/flee-facility.lua")
    end)

    dotConn:Disconnect()
    pcall(function() loadingSg:Destroy() end)

    if not okMain or not mainContent or mainContent == "" then
      WindUI:Notify({ Title="Erro ao carregar!", Content="Falha ao baixar script.", Icon="bug-play", Duration=8 })
      return
    end

    getgenv().WindUI  = WindUI
    getgenv().KeyTier = tier
    getgenv().KeyName = name

    local ok, err = pcall(function() loadstring(mainContent)() end)
    if not ok then
      pcall(function() setclipboard("-- KAIO ERROR --\n"..tostring(err)) end)
      WindUI:Notify({ Title="Erro Crítico!", Content="Erro copiado. Reporte no KAIO APPS!", Icon="bug-play", Duration=9 })
      return
    end

    -- Iniciar heartbeat após script carregado
    startHeartbeatLoop(key, tier)

    if game:GetService("UserInputService").KeyboardEnabled then
      WindUI:Notify({ Title="Teclado detectado!", Content="Use 'H' para abrir/fechar o menu.", Icon="keyboard", Duration=6 })
    end
  end)
end

-- ============================================================
--  SESSION ID
-- ============================================================
local function randHex(n)
  local s=""; local chars="0123456789ABCDEF"
  for _ = 1, n do s=s..chars:sub(math.random(1,16),math.random(1,16)) end
  return s
end
local SESSION_ID = randHex(6)

-- ============================================================
--  UI HELPERS
-- ============================================================
local function corner(r,p) local c=Instance.new("UICorner",p); c.CornerRadius=UDim.new(0,r) end
local function stroke(col,thick,p) local s=Instance.new("UIStroke",p); s.Color=col; s.Thickness=thick end
local function label(txt,size,bold,col,p,xa)
  local l=Instance.new("TextLabel",p); l.BackgroundTransparency=1; l.Text=txt
  l.TextSize=size; l.Font=bold and Enum.Font.GothamBold or Enum.Font.Gotham
  l.TextColor3=col; if xa then l.TextXAlignment=xa end; return l
end

-- ============================================================
--  KEY PROMPT
-- ============================================================
local function buildKeyPrompt(onSuccess)
  local sg=Instance.new("ScreenGui")
  sg.Name="KAIOKeyPrompt"; sg.ResetOnSpawn=false
  sg.IgnoreGuiInset=true; sg.DisplayOrder=999; sg.Parent=playerGui

  local ov=Instance.new("Frame",sg)
  ov.Size=UDim2.fromScale(1,1); ov.BackgroundColor3=Color3.new(0,0,0)
  ov.BackgroundTransparency=0.4; ov.BorderSizePixel=0

  local W,H=320,360
  local card=Instance.new("Frame",sg)
  card.Size=UDim2.fromOffset(W,H)
  card.Position=UDim2.new(0.5,0,0.55,0); card.AnchorPoint=Vector2.new(0.5,0.5)
  card.BackgroundColor3=Color3.fromRGB(13,17,23); card.BorderSizePixel=0; card.ZIndex=2
  corner(8,card); stroke(Color3.fromRGB(30,41,64),1,card)

  local lbar=Instance.new("Frame",card)
  lbar.Size=UDim2.new(0,3,1,0); lbar.BackgroundColor3=Color3.fromRGB(229,57,53); lbar.BorderSizePixel=0; lbar.ZIndex=3
  corner(2,lbar)

  local closeBtn=Instance.new("TextButton",card)
  closeBtn.Size=UDim2.fromOffset(28,28); closeBtn.Position=UDim2.new(1,-34,0,6)
  closeBtn.BackgroundColor3=Color3.fromRGB(40,20,20); closeBtn.BorderSizePixel=0
  closeBtn.Text="✕"; closeBtn.TextColor3=Color3.fromRGB(200,80,80)
  closeBtn.Font=Enum.Font.GothamBold; closeBtn.TextSize=13; closeBtn.ZIndex=4
  corner(6,closeBtn)
  closeBtn.MouseButton1Click:Connect(function() sg:Destroy() end)

  local hdr=Instance.new("Frame",card)
  hdr.Size=UDim2.new(1,-3,0,66); hdr.Position=UDim2.fromOffset(3,0)
  hdr.BackgroundColor3=Color3.fromRGB(17,23,32); hdr.BorderSizePixel=0; hdr.ZIndex=3

  local shieldBg=Instance.new("Frame",hdr)
  shieldBg.Size=UDim2.fromOffset(38,38); shieldBg.Position=UDim2.fromOffset(14,14)
  shieldBg.BackgroundColor3=Color3.fromRGB(21,101,192); shieldBg.BorderSizePixel=0; shieldBg.ZIndex=4
  corner(8,shieldBg)
  local shieldTxt=Instance.new("TextLabel",shieldBg)
  shieldTxt.Size=UDim2.fromScale(1,1); shieldTxt.BackgroundTransparency=1
  shieldTxt.Text="🛡"; shieldTxt.TextSize=20; shieldTxt.Font=Enum.Font.Gotham; shieldTxt.ZIndex=5

  local t1=label("KAIO DEFENSE SYSTEM",13,true,Color3.fromRGB(224,234,248),hdr,Enum.TextXAlignment.Left)
  t1.Size=UDim2.new(1,-70,0,18); t1.Position=UDim2.fromOffset(60,14); t1.ZIndex=4; t1.TextScaled=false

  local t2=label("KAIO Key System — Facility Apps v9",10,false,Color3.fromRGB(74,96,128),hdr,Enum.TextXAlignment.Left)
  t2.Size=UDim2.new(1,-70,0,14); t2.Position=UDim2.fromOffset(60,34); t2.ZIndex=4

  local statsY=68
  local statData={
    {label="AMEAÇA",val="ELEVADO",col=Color3.fromRGB(255,82,82)},
    {label="PROTEÇÃO",val="HWID-LOCK",col=Color3.fromRGB(0,230,118)},
    {label="SESSÃO",val=SESSION_ID,col=Color3.fromRGB(0,188,212)},
  }
  local statW=math.floor((W-3)/3)
  for i,st in ipairs(statData) do
    local sf=Instance.new("Frame",card)
    sf.Size=UDim2.fromOffset(statW,46); sf.Position=UDim2.fromOffset(3+(i-1)*statW,statsY)
    sf.BackgroundColor3=Color3.fromRGB(17,23,32); sf.BorderSizePixel=0; sf.ZIndex=3
    stroke(Color3.fromRGB(30,41,64),1,sf)
    local sl=label(st.label,9,true,Color3.fromRGB(74,96,128),sf,Enum.TextXAlignment.Left)
    sl.Size=UDim2.new(1,-6,0,14); sl.Position=UDim2.fromOffset(8,8); sl.ZIndex=4; sl.TextScaled=false
    local sv=label(st.val,11,true,st.col,sf,Enum.TextXAlignment.Left)
    sv.Size=UDim2.new(1,-6,0,16); sv.Position=UDim2.fromOffset(8,24); sv.ZIndex=4; sv.TextScaled=false
  end

  local sepY=statsY+48
  local sepLbl=label("◆  INSIRA SUA KEY KAIO  ◆",10,true,Color3.fromRGB(200,50,50),card,Enum.TextXAlignment.Center)
  sepLbl.Size=UDim2.new(1,-6,0,24); sepLbl.Position=UDim2.fromOffset(3,sepY); sepLbl.ZIndex=3
  sepLbl.BackgroundColor3=Color3.fromRGB(17,23,32); sepLbl.BackgroundTransparency=0

  local inputY=sepY+26
  local inputFrame=Instance.new("Frame",card)
  inputFrame.Size=UDim2.new(1,-19,0,42); inputFrame.Position=UDim2.fromOffset(3,inputY)
  inputFrame.BackgroundColor3=Color3.fromRGB(17,23,32); inputFrame.BorderSizePixel=0; inputFrame.ZIndex=3
  stroke(Color3.fromRGB(30,41,64),1,inputFrame)

  local ibar=Instance.new("Frame",inputFrame)
  ibar.Size=UDim2.fromOffset(3,42); ibar.BackgroundColor3=Color3.fromRGB(229,57,53); ibar.BorderSizePixel=0; ibar.ZIndex=4

  local tb=Instance.new("TextBox",inputFrame)
  tb.Size=UDim2.new(1,-8,1,0); tb.Position=UDim2.fromOffset(8,0)
  tb.BackgroundTransparency=1; tb.ClearTextOnFocus=false
  tb.PlaceholderText="Cole sua key KAIO aqui"
  tb.PlaceholderColor3=Color3.fromRGB(74,96,128)
  tb.Text=""; tb.TextColor3=Color3.fromRGB(200,220,240)
  tb.Font=Enum.Font.Code; tb.TextSize=13; tb.ZIndex=4
  tb.TextXAlignment=Enum.TextXAlignment.Left

  local statusY=inputY+46
  local statusLbl=label("",11,false,Color3.fromRGB(255,82,82),card,Enum.TextXAlignment.Left)
  statusLbl.Size=UDim2.new(1,-22,0,18); statusLbl.Position=UDim2.fromOffset(8,statusY)
  statusLbl.ZIndex=3; statusLbl.TextScaled=false; statusLbl.TextWrapped=true

  local authY=statusY+22
  local authBtn=Instance.new("TextButton",card)
  authBtn.Size=UDim2.new(1,-19,0,44); authBtn.Position=UDim2.fromOffset(3,authY)
  authBtn.BackgroundColor3=Color3.fromRGB(183,28,28); authBtn.BorderSizePixel=0
  authBtn.Text="▶  AUTENTICAR"; authBtn.TextColor3=Color3.new(1,1,1)
  authBtn.Font=Enum.Font.GothamBold; authBtn.TextSize=13; authBtn.ZIndex=3; corner(5,authBtn)

  local gkY=authY+50
  local gkBtn=Instance.new("TextButton",card)
  gkBtn.Size=UDim2.new(1,-19,0,30); gkBtn.Position=UDim2.fromOffset(3,gkY)
  gkBtn.BackgroundTransparency=1; gkBtn.BorderSizePixel=0
  gkBtn.Text="🔑  OBTER MINHA KEY GRÁTIS  →"
  gkBtn.TextColor3=Color3.fromRGB(74,96,128); gkBtn.Font=Enum.Font.Gotham; gkBtn.TextSize=11; gkBtn.ZIndex=3

  gkBtn.MouseButton1Click:Connect(function()
    local hwid=getHwid()
    local url="__GETKEY_URL__?hwid="..HttpService:UrlEncode(hwid)
    pcall(function() setclipboard(url) end)
    gkBtn.Text="🔑 Link copiado! Abra no navegador →"
    gkBtn.TextColor3=Color3.fromRGB(0,230,118)
  end)

  card.Position=UDim2.new(0.5,0,0.62,0); card.BackgroundTransparency=1
  TweenService:Create(card,TweenInfo.new(0.28,Enum.EasingStyle.Quart,Enum.EasingDirection.Out),
    {Position=UDim2.new(0.5,0,0.5,0),BackgroundTransparency=0}):Play()

  local busy=false
  local function doAuth(key)
    if busy then return end
    busy=true
    authBtn.Text="VERIFICANDO..."; authBtn.BackgroundColor3=Color3.fromRGB(100,20,20)
    statusLbl.Text=""
    task.spawn(function()
      local hwid=getHwid()
      local result=kaioCheck(key,hwid)
      if not result.success then
        statusLbl.Text="✗ "..(result.message or "KEY INVÁLIDA")
        statusLbl.TextColor3=Color3.fromRGB(255,82,82)
        authBtn.Text="▶  AUTENTICAR"; authBtn.BackgroundColor3=Color3.fromRGB(183,28,28)
        pcall(function() delfile(KEY_FILE) end)
        busy=false; return
      end

      -- ✅ Autenticado
      getgenv().KeyTier=result.tier; getgenv().KeyName=eu.Name
      pcall(function() writefile(KEY_FILE,key) end)

      if result.isAdmin then
        statusLbl.Text="✓ ADMIN AUTENTICADO — Painel Admin"
        statusLbl.TextColor3=Color3.fromRGB(255,200,0)
        authBtn.BackgroundColor3=Color3.fromRGB(100,60,0); authBtn.Text="✓ ADMIN"
      else
        statusLbl.Text="✓ ACESSO LIBERADO — Licença "..result.tierName
        statusLbl.TextColor3=Color3.fromRGB(0,230,118)
        authBtn.BackgroundColor3=Color3.fromRGB(0,100,50); authBtn.Text="✓ AUTORIZADO"
      end

      task.wait(0.9)
      TweenService:Create(card,TweenInfo.new(0.2,Enum.EasingStyle.Quart,Enum.EasingDirection.In),
        {Position=UDim2.new(0.5,0,0.4,0),BackgroundTransparency=1}):Play()
      TweenService:Create(ov,TweenInfo.new(0.2),{BackgroundTransparency=1}):Play()
      task.wait(0.22); sg:Destroy()
      onSuccess(result.tier,result.tierName,result.expireDate,result.isAdmin,key)
    end)
  end

  local function validateInput()
    local key=tb.Text:match("^%s*(.-)%s*$")
    if key=="" then
      statusLbl.Text="⚠ Insira sua key KAIO."
      statusLbl.TextColor3=Color3.fromRGB(255,200,50); return
    end
    doAuth(key)
  end
  authBtn.MouseButton1Click:Connect(validateInput)
  tb.FocusLost:Connect(function(enter) if enter then validateInput() end end)
end

-- ============================================================
--  SHOW POPUP → LOAD SCRIPT
-- ============================================================
local function proceedToLoad(tier, tierName, expira, isAdmin, key)
  local hwid = getHwid()
  local dashboardUrl = SERVER_URL .. "/dashboard?hwid=" .. HttpService:UrlEncode(hwid)

  if isAdmin then
    WindUI:Popup({
      Title   = "KAIO ADMIN — ADMIN2108",
      Icon    = "shield-alert",
      Content = "Chave Admin detectada!\nBem-vindo, CEO KAIO APPS.",
      Buttons = {{
        Title    = "Abrir Painel Admin",
        Icon     = "shield-alert",
        Callback = function() LoadAdminPanel() end,
        Variant  = "Primary"
      }}
    })
  else
    WindUI:Popup({
      Title   = "Facility Apps | KAIO APPS",
      Icon    = "shield",
      Content = string.format("Licença %s ativa. Bem-vindo, %s!\nExpira: %s", tierName, eu.Name, expira),
      Buttons = {{
        Title    = "Carregar Script",
        Icon     = "shield",
        Callback = function() LoadScript(tier, "Flee The Facility", key) end,
        Variant  = "Primary"
      }}
    })
  end

  -- Mostrar notificação com link do painel pessoal e copiar para clipboard
  task.delay(1.5, function()
    pcall(function() setclipboard(dashboardUrl) end)
    WindUI:Notify({
      Title    = "🖥 Seu Painel Pessoal",
      Content  = "Link do seu painel copiado!\nVeja sua key, indicações e muito mais.",
      Icon     = "layout-dashboard",
      Duration = 10,
    })
  end)
end

-- ============================================================
--  CHECK STORED KEY FIRST
-- ============================================================
task.spawn(function()
  local storedKey=nil
  pcall(function()
    local f=readfile(KEY_FILE)
    if f and #f>4 then storedKey=f:match("^%s*(.-)%s*$") end
  end)

  if storedKey then
    local hwid=getHwid()
    local result=kaioCheck(storedKey,hwid)
    if result.success then
      getgenv().KeyTier=result.tier; getgenv().KeyName=eu.Name

      -- Verifica se bloqueado antes de prosseguir
      if not result.isAdmin and checkBlocked() then
        WindUI:Notify({ Title="🚫 Bloqueado!", Content="Sua conta foi bloqueada pelo administrador.", Icon="user-x", Duration=10 })
        task.wait(3); eu:Kick("[KAIO] Conta bloqueada."); return
      end

      WindUI:Popup({
        Title   = result.isAdmin and "✓ Admin autenticado!" or "✓ Key salva encontrada!",
        Icon    = "shield-check",
        Content = result.isAdmin
          and "Bem-vindo, CEO.\nDeseja continuar ou usar outra key?"
          or  ("Licença "..result.tierName.." ativa. Expira: "..result.expireDate.."\nDeseja continuar ou trocar a key?"),
        Buttons = {
          {
            Title    = "Continuar",
            Icon     = "shield",
            Variant  = "Primary",
            Callback = function()
              proceedToLoad(result.tier, result.tierName, result.expireDate, result.isAdmin, storedKey)
            end,
          },
          {
            Title    = "Trocar Key",
            Icon     = "key-round",
            Variant  = "Secondary",
            Callback = function()
              pcall(function() delfile(KEY_FILE) end)
              buildKeyPrompt(proceedToLoad)
            end,
          },
        },
      })
      return
    end
    pcall(function() delfile(KEY_FILE) end)
    WindUI:Notify({ Title="Key expirada", Content="Sua key expirou. Obtenha uma nova.", Icon="clock", Duration=4 })
  end

  buildKeyPrompt(proceedToLoad)
end)
