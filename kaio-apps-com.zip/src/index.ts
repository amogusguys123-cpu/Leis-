import app from "./app";
import { logger } from "./lib/logger";

// Prevent unhandled rejections from crashing the process
process.on("unhandledRejection", (reason) => {
  logger.error({ reason }, "Unhandled promise rejection (caught — server stays up)");
});
process.on("uncaughtException", (err) => {
  logger.error({ err }, "Uncaught exception (caught — server stays up)");
});

const rawPort = process.env["PORT"] ?? "80";
const port = Number(rawPort);

if (Number.isNaN(port) || port <= 0) {
  throw new Error(`Invalid PORT value: "${rawPort}"`);
}

const HOST = "0.0.0.0";

app.listen(port, HOST, () => {
  logger.info(
    { port, host: HOST, env: process.env["NODE_ENV"] ?? "production" },
    "Server listening and ready for requests"
  );
});
